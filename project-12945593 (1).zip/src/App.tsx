import { BrowserRouter } from "react-router-dom";
import { Suspense } from "react";
import { AppRoutes } from "./router";
import { I18nextProvider } from "react-i18next";
import i18n from "./i18n";
import { EditModeProvider } from "./contexts/EditModeContext";
import PageTransition from "./components/feature/PageTransition";
import PageLoader from "./components/feature/PageLoader";

function App() {
  return (
    <I18nextProvider i18n={i18n}>
      <BrowserRouter basename={__BASE_PATH__}>
        <EditModeProvider>
          <PageTransition>
            <Suspense fallback={<PageLoader />}>
              <AppRoutes />
            </Suspense>
          </PageTransition>
        </EditModeProvider>
      </BrowserRouter>
    </I18nextProvider>
  );
}

export default App;
