import { useEffect, useState, useRef } from 'react';
import { supabase } from '@/lib/supabase';

interface Portal {
  id: string;
  client_name: string;
  brand_name: string;
  slug: string;
  description: string;
  status: string;
  accent_color: string;
  login_keyword: string;
  created_at: string;
  drive_url?: string;
  recipient_email?: string;
  staff_label?: string;
  client_label?: string;
}
interface Project {
  id: string;
  portal_id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  category: string;
  progress: number;
  start_date: string;
  end_date: string;
}
interface Task {
  id: string;
  project_id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  due_date: string;
  assigned_to: string;
}
interface Approval {
  id: string;
  project_id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
}
interface Report {
  id: string;
  title: string;
  type: string;
  status: string;
  period_start: string;
  period_end: string;
  highlights: any;
  metrics: any;
  published_at: string;
}
interface Agenda {
  id: string;
  portal_id: string;
  week_start: string;
  week_end: string;
  title: string;
  notes: string;
  action_items: string[];
  status: string;
  created_at: string;
}

const ADMIN_PIN = '5565';

function generateKeyword(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let result = '';
  for (let i = 0; i < 10; i++) result += chars[Math.floor(Math.random() * chars.length)];
  return result;
}

const statusOptions = ['working_on', 'pending', 'upcoming', 'concluded'];
const priorityOptions = ['low', 'medium', 'high', 'urgent'];
const categoryOptions = ['branding', 'marketing', 'web', 'strategy', 'other'];
const taskStatusOptions = ['todo', 'in_progress', 'review', 'completed'];
const reportTypes = ['weekly', 'monthly', 'quarterly'];

const badgeColors: Record<string, string> = {
  urgent: 'bg-red-500/10 text-red-400 border-red-500/20',
  high: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  medium: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
  low: 'bg-white/5 text-white/30 border-white/10',
};

const taskStatusColors: Record<string, string> = {
  todo: 'bg-white/5 text-white/30',
  in_progress: 'bg-sky-500/10 text-sky-400',
  review: 'bg-amber-500/10 text-amber-400',
  completed: 'bg-emerald-500/10 text-emerald-400',
};

export default function AdminPortals() {
  const [pin, setPin] = useState(['', '', '', '']);
  const [pinError, setPinError] = useState(false);
  const [pinShake, setPinShake] = useState(false);
  const pinRefs = [
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
  ];

  const [authenticated, setAuthenticated] = useState(false);
  const [portals, setPortals] = useState<Portal[]>([]);
  const [selectedPortal, setSelectedPortal] = useState<Portal | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [approvals, setApprovals] = useState<Approval[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');
  const [msgType, setMsgType] = useState<'success' | 'error'>('success');
  const [savedId, setSavedId] = useState<string | null>(null);
  const [tab, setTab] = useState<'clients' | 'projects' | 'tasks' | 'approvals' | 'reports' | 'agendas'>('clients');
  const [agendas, setAgendas] = useState<Agenda[]>([]);
  const [editProgressId, setEditProgressId] = useState<string | null>(null);
  const [editProgressVal, setEditProgressVal] = useState('');
  const [driveUrl, setDriveUrl] = useState('');
  const [editingDriveId, setEditingDriveId] = useState<string | null>(null);
  const [recipientEmail, setRecipientEmail] = useState('');
  const [editingEmailId, setEditingEmailId] = useState<string | null>(null);
  const [staffLabel, setStaffLabel] = useState('');
  const [editingStaffLabelId, setEditingStaffLabelId] = useState<string | null>(null);
  const [clientLabel, setClientLabel] = useState('');
  const [editingClientLabelId, setEditingClientLabelId] = useState<string | null>(null);

  // New portal form
  const [newPortal, setNewPortal] = useState({ client_name: '', brand_name: '', slug: '', description: '', accent_color: '#7C3AED', login_keyword: '', staff_label: 'BrandStack Staff', client_label: 'Client Staff' });
  // New project form
  const [newProject, setNewProject] = useState({ title: '', description: '', status: 'working_on', priority: 'medium', category: 'branding', progress: 0, start_date: '', end_date: '' });
  // New task form
  const [newTask, setNewTask] = useState({ title: '', description: '', status: 'todo', priority: 'medium', due_date: '', assigned_to: '' });
  // New approval form
  const [newApproval, setNewApproval] = useState({ title: '', description: '', status: 'pending', priority: 'medium' });
  // New report form
  const [newReport, setNewReport] = useState({ title: '', type: 'weekly', period_start: '', period_end: '' });
  // New agenda form
  const [newAgenda, setNewAgenda] = useState({ title: '', week_start: '', week_end: '', notes: '', action_items: [''] });
  // Edit keyword
  const [editKeywordId, setEditKeywordId] = useState<string | null>(null);
  const [editKeyword, setEditKeyword] = useState('');

  const handlePinInput = (index: number, value: string) => {
    if (!/^\d?$/.test(value)) return;
    const newPin = [...pin];
    newPin[index] = value;
    setPin(newPin);
    setPinError(false);

    if (value && index < 3) {
      pinRefs[index + 1].current?.focus();
    }

    if (newPin.every((d) => d !== '') && newPin.join('').length === 4) {
      const entered = newPin.join('');
      if (entered === ADMIN_PIN) {
        setAuthenticated(true);
        loadPortals();
      } else {
        setPinError(true);
        setPinShake(true);
        setTimeout(() => {
          setPin(['', '', '', '']);
          setPinShake(false);
          pinRefs[0].current?.focus();
        }, 600);
      }
    }
  };

  const handlePinKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !pin[index] && index > 0) {
      pinRefs[index - 1].current?.focus();
    }
  };

  const loadPortals = async () => {
    setLoading(true);
    const { data } = await supabase.from('client_portals').select('*').order('created_at', { ascending: false });
    if (data) setPortals(data);
    setLoading(false);
  };

  const loadProjects = async (portalId: string) => {
    setLoading(true);
    const { data } = await supabase.from('portal_projects').select('*').eq('portal_id', portalId).order('created_at', { ascending: false });
    if (data) setProjects(data);
    setLoading(false);
  };

  const loadTasks = async (portalId: string, projectId?: string) => {
    setLoading(true);
    let q = supabase.from('portal_tasks').select('*').eq('portal_id', portalId).order('created_at', { ascending: true });
    if (projectId) q = q.eq('project_id', projectId);
    const { data } = await q;
    if (data) setTasks(data);
    setLoading(false);
  };

  const loadApprovals = async (portalId: string, projectId?: string) => {
    setLoading(true);
    let q = supabase.from('portal_approvals').select('*').eq('portal_id', portalId).order('requested_at', { ascending: false });
    if (projectId) q = q.eq('project_id', projectId);
    const { data } = await q;
    if (data) setApprovals(data);
    setLoading(false);
  };

  const loadReports = async (portalId: string) => {
    setLoading(true);
    const { data } = await supabase.from('portal_reports').select('*').eq('portal_id', portalId).order('created_at', { ascending: false });
    if (data) setReports(data);
    setLoading(false);
  };

  const loadAgendas = async (portalId: string) => {
    setLoading(true);
    const { data } = await supabase.from('portal_agendas').select('*').eq('portal_id', portalId).order('created_at', { ascending: false });
    if (data) setAgendas(data);
    setLoading(false);
  };

  const showMsg = (text: string, type: 'success' | 'error' = 'success') => {
    setMsg(text);
    setMsgType(type);
    setTimeout(() => setMsg(''), 4000);
  };

  const showSaved = (id: string) => {
    setSavedId(id);
    setTimeout(() => setSavedId(null), 2000);
  };

  const createPortal = async () => {
    if (!newPortal.client_name || !newPortal.brand_name || !newPortal.slug) return;
    const keyword = newPortal.login_keyword || generateKeyword();
    setLoading(true);
    const { error } = await supabase.from('client_portals').insert({
      client_name: newPortal.client_name, brand_name: newPortal.brand_name, slug: newPortal.slug.toLowerCase(),
      description: newPortal.description, accent_color: newPortal.accent_color, login_keyword: keyword, status: 'active',
      staff_label: newPortal.staff_label, client_label: newPortal.client_label,
    });
    setLoading(false);
    if (error) { showMsg('Error creating portal: ' + error.message, 'error'); return; }
    showMsg(`Portal created! Keyword: ${keyword}`);
    setNewPortal({ client_name: '', brand_name: '', slug: '', description: '', accent_color: '#7C3AED', login_keyword: '', staff_label: 'BrandStack Staff', client_label: 'Client Staff' });
    loadPortals();
  };

  const updateKeyword = async (id: string) => {
    if (!editKeyword.trim()) return;
    const { error } = await supabase.from('client_portals').update({ login_keyword: editKeyword.trim() }).eq('id', id);
    if (error) { showMsg('Error updating keyword: ' + error.message, 'error'); return; }
    showMsg('Keyword updated');
    setEditKeywordId(null);
    loadPortals();
  };

  const createProject = async () => {
    if (!selectedPortal || !newProject.title) return;
    const { error } = await supabase.from('portal_projects').insert({ portal_id: selectedPortal.id, ...newProject });
    if (error) { showMsg('Error adding project: ' + error.message, 'error'); return; }
    showMsg('Project added');
    setNewProject({ title: '', description: '', status: 'working_on', priority: 'medium', category: 'branding', progress: 0, start_date: '', end_date: '' });
    loadProjects(selectedPortal.id);
  };

  const updateProject = async (id: string, field: string, value: any) => {
    if (!selectedPortal) return;
    const { error } = await supabase.from('portal_projects').update({ [field]: value }).eq('id', id);
    if (error) { showMsg('Error saving: ' + error.message, 'error'); return; }
    showSaved(id);
    loadProjects(selectedPortal.id);
  };

  const deleteProject = async (id: string) => {
    if (!selectedPortal || !confirm('Delete this project and all its tasks/approvals?')) return;
    const { error } = await supabase.from('portal_projects').delete().eq('id', id);
    if (error) { showMsg('Error deleting project: ' + error.message, 'error'); return; }
    showMsg('Project deleted');
    loadProjects(selectedPortal.id);
  };

  const createTask = async () => {
    if (!selectedPortal || !selectedProject || !newTask.title) return;
    const { error } = await supabase.from('portal_tasks').insert({
      portal_id: selectedPortal.id, project_id: selectedProject.id,
      title: newTask.title, description: newTask.description, status: newTask.status,
      priority: newTask.priority, due_date: newTask.due_date || null, assigned_to: newTask.assigned_to || null,
    });
    if (error) { showMsg('Error adding task: ' + error.message, 'error'); return; }
    showMsg('Task added');
    setNewTask({ title: '', description: '', status: 'todo', priority: 'medium', due_date: '', assigned_to: '' });
    loadTasks(selectedPortal.id, selectedProject.id);
  };

  const updateTask = async (id: string, field: string, value: any) => {
    if (!selectedPortal) return;
    const updates: any = { [field]: value };
    if (field === 'status' && value === 'completed') updates.completed_at = new Date().toISOString();
    const { error } = await supabase.from('portal_tasks').update(updates).eq('id', id);
    if (error) { showMsg('Error saving task: ' + error.message, 'error'); return; }
    showSaved(id);
    loadTasks(selectedPortal.id, selectedProject?.id);
    if (field === 'status' && value === 'completed') {
      supabase.functions.invoke('portal-notifications', {
        body: { portal_id: selectedPortal.id, type: 'task_completed', title: 'Task Completed', message: 'A task has been marked as complete.', channel: 'both' },
      }).catch(() => {});
    }
  };

  const deleteTask = async (id: string) => {
    if (!confirm('Delete this task?')) return;
    const { error } = await supabase.from('portal_tasks').delete().eq('id', id);
    if (error) { showMsg('Error deleting task: ' + error.message, 'error'); return; }
    showMsg('Task deleted');
    if (selectedPortal) loadTasks(selectedPortal.id, selectedProject?.id);
  };

  const createApproval = async () => {
    if (!selectedPortal || !selectedProject || !newApproval.title) return;
    const { error } = await supabase.from('portal_approvals').insert({
      portal_id: selectedPortal.id, project_id: selectedProject.id,
      title: newApproval.title, description: newApproval.description,
      status: 'pending', priority: newApproval.priority,
    });
    if (error) { showMsg('Error creating approval: ' + error.message, 'error'); return; }
    showMsg('Approval created');
    setNewApproval({ title: '', description: '', status: 'pending', priority: 'medium' });
    loadApprovals(selectedPortal.id, selectedProject.id);
    supabase.functions.invoke('portal-notifications', {
      body: { portal_id: selectedPortal.id, type: 'approval_needed', title: newApproval.title, message: newApproval.description, channel: 'both' },
    }).catch(() => {});
  };

  const deleteApproval = async (id: string) => {
    if (!confirm('Delete this approval?')) return;
    const { error } = await supabase.from('portal_approvals').delete().eq('id', id);
    if (error) { showMsg('Error deleting approval: ' + error.message, 'error'); return; }
    showMsg('Approval deleted');
    if (selectedPortal) loadApprovals(selectedPortal.id, selectedProject?.id);
  };

  const createReport = async () => {
    if (!selectedPortal || !newReport.title) return;
    const { error } = await supabase.from('portal_reports').insert({
      portal_id: selectedPortal.id, title: newReport.title, type: newReport.type,
      status: 'published', period_start: newReport.period_start || new Date().toISOString().split('T')[0],
      period_end: newReport.period_end || new Date().toISOString().split('T')[0],
      highlights: [], metrics: {}, published_at: new Date().toISOString(),
    });
    if (error) { showMsg('Error publishing report: ' + error.message, 'error'); return; }
    showMsg('Report published');
    setNewReport({ title: '', type: 'weekly', period_start: '', period_end: '' });
    loadReports(selectedPortal.id);
    supabase.functions.invoke('portal-notifications', {
      body: { portal_id: selectedPortal.id, type: 'report_ready', title: newReport.title, message: `Your ${newReport.type} report is now available.`, channel: 'both' },
    }).catch(() => {});
  };

  const deleteReport = async (id: string) => {
    if (!confirm('Delete this report?')) return;
    const { error } = await supabase.from('portal_reports').delete().eq('id', id);
    if (error) { showMsg('Error deleting report: ' + error.message, 'error'); return; }
    showMsg('Report deleted');
    if (selectedPortal) loadReports(selectedPortal.id);
  };

  const createAgenda = async () => {
    if (!selectedPortal || !newAgenda.title) return;
    const cleanItems = newAgenda.action_items.filter((a: string) => a.trim() !== '');
    const { error } = await supabase.from('portal_agendas').insert({
      portal_id: selectedPortal.id, title: newAgenda.title,
      week_start: newAgenda.week_start || new Date().toISOString().split('T')[0],
      week_end: newAgenda.week_end || new Date().toISOString().split('T')[0],
      notes: newAgenda.notes, action_items: cleanItems, status: 'published',
    });
    if (error) { showMsg('Error creating agenda: ' + error.message, 'error'); return; }
    showMsg('Agenda published — client can now see it');
    setNewAgenda({ title: '', week_start: '', week_end: '', notes: '', action_items: [''] });
    loadAgendas(selectedPortal.id);
    supabase.functions.invoke('portal-notifications', {
      body: { portal_id: selectedPortal.id, type: 'agenda_ready', title: newAgenda.title, message: 'Weekly agenda is now available on your dashboard.', channel: 'both' },
    }).catch(() => {});
  };

  const updateAgenda = async (id: string, field: string, value: any) => {
    if (!selectedPortal) return;
    const { error } = await supabase.from('portal_agendas').update({ [field]: value }).eq('id', id);
    if (error) { showMsg('Error saving: ' + error.message, 'error'); return; }
    showSaved(id);
    loadAgendas(selectedPortal.id);
  };

  const deleteAgenda = async (id: string) => {
    if (!confirm('Delete this agenda?')) return;
    const { error } = await supabase.from('portal_agendas').delete().eq('id', id);
    if (error) { showMsg('Error deleting agenda: ' + error.message, 'error'); return; }
    showMsg('Agenda deleted');
    if (selectedPortal) loadAgendas(selectedPortal.id);
  };

  const saveDriveUrl = async (portalId: string, url: string) => {
    const { error } = await supabase.from('client_portals').update({ drive_url: url }).eq('id', portalId);
    if (error) { showMsg('Error saving drive URL: ' + error.message, 'error'); return; }
    showMsg('Drive URL saved');
    setEditingDriveId(null);
    loadPortals();
  };

  const saveRecipientEmail = async (portalId: string, email: string) => {
    const { error } = await supabase.from('client_portals').update({ recipient_email: email }).eq('id', portalId);
    if (error) { showMsg('Error saving email: ' + error.message, 'error'); return; }
    showMsg('Email saved — client will get reports sent here');
    setEditingEmailId(null);
    loadPortals();
  };

  const saveStaffLabel = async (portalId: string, label: string) => {
    const { error } = await supabase.from('client_portals').update({ staff_label: label || 'BrandStack Staff' }).eq('id', portalId);
    if (error) { showMsg('Error saving: ' + error.message, 'error'); return; }
    showMsg('Staff label saved');
    setEditingStaffLabelId(null);
    loadPortals();
  };

  const saveClientLabel = async (portalId: string, label: string) => {
    const { error } = await supabase.from('client_portals').update({ client_label: label || 'Client Staff' }).eq('id', portalId);
    if (error) { showMsg('Error saving: ' + error.message, 'error'); return; }
    showMsg('Client label saved');
    setEditingClientLabelId(null);
    loadPortals();
  };

  const downloadReport = (r: Report) => {
    const h = r.highlights && Array.isArray(r.highlights) ? r.highlights.map((hl: string) => `<li>${hl}</li>`).join('') : '';
    const m = r.metrics && typeof r.metrics === 'object' ? Object.entries(r.metrics).map(([k, v]: [string, any]) => `<div class="metric"><strong>${k}:</strong> ${v}</div>`).join('') : '';
    const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${r.title}</title><style>body{font-family:-apple-system,BlinkMacSystemFont,sans-serif;max-width:800px;margin:60px auto;padding:0 24px;color:#1a1a1a;background:#fff}h1{font-size:28px;margin-bottom:4px}.meta{color:#666;font-size:13px;margin-bottom:32px;border-bottom:1px solid #e5e5e5;padding-bottom:16px}.section{margin:28px 0}.section h3{font-size:16px;border-left:4px solid #7C3AED;padding-left:12px;margin-bottom:12px}.metric{display:inline-block;background:#f5f3ff;padding:8px 16px;border-radius:8px;margin:4px;font-size:14px}li{padding:8px 0;border-bottom:1px solid #f0f0f0;font-size:14px;line-height:1.5}.footer{margin-top:40px;color:#999;font-size:11px;border-top:1px solid #e5e5e5;padding-top:12px}</style></head><body><h1>${r.title}</h1><p class="meta">${r.type.toUpperCase()} Report &middot; ${r.period_start || 'N/A'} to ${r.period_end || 'N/A'} &middot; Published ${new Date(r.published_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>${m ? `<div class="section"><h3>Metrics</h3>${m}</div>` : ''}${h ? `<div class="section"><h3>Highlights</h3><ul>${h}</ul></div>` : ''}<p class="footer">Generated by Brandstack Portal &middot; ${new Date().toISOString().split('T')[0]}</p></body></html>`;
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${r.title.replace(/\s+/g, '_')}_${r.type}_report.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const openPortal = (p: Portal) => {
    setSelectedPortal(p);
    setSelectedProject(null);
    setTasks([]);
    setApprovals([]);
    setReports([]);
    setAgendas([]);
    setDriveUrl(p.drive_url || '');
    loadProjects(p.id);
    setTab('projects');
  };

  const openProject = (p: Project) => {
    setSelectedProject(p);
    if (selectedPortal) {
      loadTasks(selectedPortal.id, p.id);
      loadApprovals(selectedPortal.id, p.id);
    }
    setTab('tasks');
  };

  if (!authenticated) {
    return (
      <div className="min-h-screen bg-[#0C0B11] flex items-center justify-center px-4">
        <div className="w-full max-w-sm">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#6b21a8] to-[#a855f7] flex items-center justify-center mx-auto mb-6">
            <i className="ri-shield-keyhole-line text-white text-3xl"></i>
          </div>
          <h1 className="font-editorial font-black text-white text-3xl text-center mb-2">Portal Manager</h1>
          <p className="text-white/40 text-sm text-center mb-10">Enter your 4-digit PIN to continue</p>
          <div className={`flex items-center justify-center gap-3 mb-6 ${pinShake ? 'animate-[shake_0.5s_ease-in-out]' : ''}`}>
            {pin.map((digit, i) => (
              <input
                key={i}
                ref={pinRefs[i]}
                type="password"
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={(e) => handlePinInput(i, e.target.value)}
                onKeyDown={(e) => handlePinKeyDown(i, e)}
                className={`w-14 h-14 text-center text-2xl font-bold rounded-xl border-2 bg-white/[0.05] text-white focus:outline-none transition-all duration-200 ${
                  pinError
                    ? 'border-red-500 bg-red-500/10'
                    : digit
                    ? 'border-[#7C3AED] bg-[#7C3AED]/10'
                    : 'border-white/10 focus:border-[#7C3AED]/60'
                }`}
                autoFocus={i === 0}
              />
            ))}
          </div>

          {pinError && (
            <p className="text-center text-red-400 text-sm animate-fadeIn">
              Incorrect PIN. Please try again.
            </p>
          )}

          <p className="text-center text-white/20 text-xs mt-8">
            Brandstack Portal Manager
          </p>
        </div>

        <style>{`
          @keyframes shake {
            0%, 100% { transform: translateX(0); }
            20% { transform: translateX(-8px); }
            40% { transform: translateX(8px); }
            60% { transform: translateX(-6px); }
            80% { transform: translateX(6px); }
          }
        `}</style>
      </div>
    );
  }

  const TabBtn = ({ t, label }: { t: typeof tab; label: string }) => (
    <button onClick={() => setTab(t)} className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap cursor-pointer ${tab === t ? 'bg-[#7C3AED] text-white' : 'text-white/30 hover:text-white/60'}`}>{label}</button>
  );

  return (
    <div className="min-h-screen bg-[#0C0B11]">
      <header className="sticky top-0 z-50 bg-[#0C0B11]/80 backdrop-blur-xl border-b border-white/[0.04]">
        <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-16 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-white font-editorial font-bold text-lg">Portal Manager</span>
            <span className="text-[10px] font-semibold text-[#a855f7] bg-[#7C3AED]/10 px-2 py-0.5 rounded-md">ADMIN</span>
          </div>
          <div className="flex items-center gap-1">
            <TabBtn t="clients" label="Clients" />
            {selectedPortal && <TabBtn t="projects" label="Projects" />}
            {selectedPortal && <TabBtn t="tasks" label="Tasks" />}
            {selectedPortal && <TabBtn t="approvals" label="Approvals" />}
            {selectedPortal && <TabBtn t="reports" label="Reports" />}
            {selectedPortal && <TabBtn t="agendas" label="Agendas" />}
          </div>
        </div>
      </header>

      {msg && (
        <div className={`fixed top-20 left-1/2 -translate-x-1/2 z-50 px-5 py-3 border rounded-xl text-white text-xs font-semibold backdrop-blur-xl flex items-center gap-2 ${
          msgType === 'error'
            ? 'bg-red-500/20 border-red-500/30 text-red-200'
            : 'bg-[#7C3AED]/20 border-[#7C3AED]/30'
        }`}>
          {msgType === 'error' ? <i className="ri-error-warning-line" /> : <i className="ri-check-line" />}
          {msg}
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-16 py-8">
        {loading && (
          <div className="flex justify-center py-20"><div className="w-8 h-8 border-2 border-[#7C3AED] border-t-transparent rounded-full animate-spin" /></div>
        )}

        {/* CLIENTS TAB */}
        {tab === 'clients' && !loading && (
          <div>
            <div className="bg-white/[0.02] border border-white/[0.05] rounded-2xl p-5 mb-6">
              <h2 className="font-editorial font-bold text-white text-lg mb-1">Create Client Portal</h2>
              <p className="text-white/30 text-xs mb-4">Clients log in with their keyword. Leave the keyword blank and one will be auto-generated.</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-3">
                <input value={newPortal.client_name} onChange={(e) => setNewPortal(p => ({ ...p, client_name: e.target.value }))} placeholder="Client / Company name" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50" />
                <input value={newPortal.brand_name} onChange={(e) => setNewPortal(p => ({ ...p, brand_name: e.target.value }))} placeholder="Brand name" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50" />
                <input value={newPortal.slug} onChange={(e) => setNewPortal(p => ({ ...p, slug: e.target.value }))} placeholder="URL slug (e.g. tonivia)" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50" />
              </div>
              <div className="flex flex-wrap gap-3 items-end">
                <input value={newPortal.login_keyword} onChange={(e) => setNewPortal(p => ({ ...p, login_keyword: e.target.value.toUpperCase() }))} placeholder="Login keyword (or leave blank)" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50 w-48" />
                <input value={newPortal.description} onChange={(e) => setNewPortal(p => ({ ...p, description: e.target.value }))} placeholder="Description" className="flex-1 px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50 min-w-[200px]" />
                <button onClick={createPortal} className="px-5 py-2 text-white text-xs font-semibold rounded-xl bg-[#7C3AED] hover:bg-[#6b21a8] transition-all whitespace-nowrap cursor-pointer">
                  <i className="ri-add-line mr-1" />Create Portal
                </button>
              </div>
              <div className="flex flex-wrap gap-3 items-end mt-3">
                <input value={newPortal.staff_label} onChange={(e) => setNewPortal(p => ({ ...p, staff_label: e.target.value }))} placeholder="Staff role label (e.g. BrandStack Staff)" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50 w-56" />
                <input value={newPortal.client_label} onChange={(e) => setNewPortal(p => ({ ...p, client_label: e.target.value }))} placeholder="Client role label (e.g. Client Staff)" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-emerald-500/30 w-56" />
                <span className="text-white/15 text-[10px]">These appear on the role selector page when clients visit their link.</span>
              </div>
            </div>

            <div className="space-y-2">
              {portals.map((p) => (
                <div key={p.id} className="flex flex-wrap items-center justify-between gap-3 bg-white/[0.02] border border-white/[0.05] rounded-xl px-5 py-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-white text-sm font-semibold">{p.client_name}</p>
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${p.status === 'active' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-white/5 text-white/30'}`}>{p.status}</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-3 text-xs">
                      <span className="text-white/30">{p.brand_name} &middot; /{p.slug}</span>
                      {editKeywordId === p.id ? (
                        <div className="flex items-center gap-1">
                          <input value={editKeyword} onChange={(e) => setEditKeyword(e.target.value.toUpperCase())} className="w-32 px-2 py-1 bg-white/[0.06] border border-[#7C3AED]/30 rounded-lg text-white text-[11px] focus:outline-none" autoFocus onKeyDown={(e) => { if (e.key === 'Enter') updateKeyword(p.id); if (e.key === 'Escape') setEditKeywordId(null); }} />
                          <button onClick={() => updateKeyword(p.id)} className="text-emerald-400 text-[10px] hover:underline cursor-pointer">Save</button>
                          <button onClick={() => setEditKeywordId(null)} className="text-white/30 text-[10px] hover:underline cursor-pointer">Cancel</button>
                        </div>
                      ) : (
                        <span className="text-white/15 font-mono text-[11px]">
                          Keyword: {p.login_keyword || <span className="text-red-400/50 italic">not set</span>}
                          <button onClick={() => { setEditKeywordId(p.id); setEditKeyword(p.login_keyword || ''); }} className="ml-2 text-white/25 hover:text-[#a855f7] transition-colors cursor-pointer">
                            <i className="ri-edit-line text-[10px]" />
                          </button>
                        </span>
                      )}
                    </div>
                    {editingDriveId === p.id ? (
                      <div className="flex items-center gap-1 mt-1">
                        <i className="ri-folder-shared-line text-white/20 text-xs" />
                        <input value={driveUrl} onChange={(e) => setDriveUrl(e.target.value)} placeholder="Google Drive folder URL" className="w-56 px-2 py-1 bg-white/[0.06] border border-[#7C3AED]/30 rounded-lg text-white text-[11px] placeholder:text-white/15 focus:outline-none" autoFocus onKeyDown={(e) => { if (e.key === 'Enter') saveDriveUrl(p.id, driveUrl); if (e.key === 'Escape') { setEditingDriveId(null); setDriveUrl(p.drive_url || ''); } }} />
                        <button onClick={() => saveDriveUrl(p.id, driveUrl)} className="text-emerald-400 text-[10px] hover:underline cursor-pointer whitespace-nowrap">Save</button>
                        <button onClick={() => { setEditingDriveId(null); setDriveUrl(p.drive_url || ''); }} className="text-white/30 text-[10px] hover:underline cursor-pointer">Cancel</button>
                      </div>
                    ) : (
                      <span className="text-white/15 text-[11px] mt-1 flex items-center gap-1">
                        <i className="ri-folder-shared-line text-white/20 text-xs" />
                        {p.drive_url ? (
                          <>
                            <a href={p.drive_url} target="_blank" rel="noopener noreferrer" className="text-[#a855f7]/70 hover:text-[#a855f7] underline transition-colors truncate max-w-[300px]">{p.drive_url}</a>
                            <button onClick={(e) => { e.stopPropagation(); setEditingDriveId(p.id); setDriveUrl(p.drive_url || ''); }} className="text-white/20 hover:text-[#a855f7] transition-colors cursor-pointer ml-1"><i className="ri-edit-line text-[10px]" /></button>
                          </>
                        ) : (
                          <button onClick={() => { setEditingDriveId(p.id); setDriveUrl(''); }} className="text-white/20 hover:text-[#a855f7] transition-colors cursor-pointer">+ Add Drive link</button>
                        )}
                      </span>
                    )}
                    {editingEmailId === p.id ? (
                      <div className="flex items-center gap-1 mt-1">
                        <i className="ri-mail-line text-white/20 text-xs" />
                        <input value={recipientEmail} onChange={(e) => setRecipientEmail(e.target.value)} placeholder="client@example.com" className="w-56 px-2 py-1 bg-white/[0.06] border border-[#7C3AED]/30 rounded-lg text-white text-[11px] placeholder:text-white/15 focus:outline-none" autoFocus onKeyDown={(e) => { if (e.key === 'Enter') saveRecipientEmail(p.id, recipientEmail); if (e.key === 'Escape') { setEditingEmailId(null); setRecipientEmail(p.recipient_email || ''); } }} />
                        <button onClick={() => saveRecipientEmail(p.id, recipientEmail)} className="text-emerald-400 text-[10px] hover:underline cursor-pointer whitespace-nowrap">Save</button>
                        <button onClick={() => { setEditingEmailId(null); setRecipientEmail(p.recipient_email || ''); }} className="text-white/30 text-[10px] hover:underline cursor-pointer">Cancel</button>
                      </div>
                    ) : (
                      <span className="text-white/15 text-[11px] mt-1 flex items-center gap-1">
                        <i className="ri-mail-line text-white/20 text-xs" />
                        {p.recipient_email ? (
                          <>
                            <span className="text-emerald-400/60">{p.recipient_email}</span>
                            <button onClick={(e) => { e.stopPropagation(); setEditingEmailId(p.id); setRecipientEmail(p.recipient_email || ''); }} className="text-white/20 hover:text-[#a855f7] transition-colors cursor-pointer ml-1"><i className="ri-edit-line text-[10px]" /></button>
                          </>
                        ) : (
                          <button onClick={() => { setEditingEmailId(p.id); setRecipientEmail(''); }} className="text-white/20 hover:text-emerald-400 transition-colors cursor-pointer">+ Add client email</button>
                        )}
                      </span>
                    )}
                    {/* Shareable link */}
                    <span className="text-white/15 text-[11px] mt-1 flex items-center gap-1">
                      <i className="ri-link text-white/20 text-xs" />
                      <span className="text-[#a855f7]/50">portal/</span>
                      <span className="text-[#a855f7]/80 font-mono">{p.slug}</span>
                      <button
                        onClick={() => {
                          const basePath = (window as any).__BASE_PATH__ || '';
                          const link = `${window.location.origin}${basePath}/portal/${p.slug}`;
                          navigator.clipboard.writeText(link).then(() => showMsg('Link copied!'));
                        }}
                        className="text-white/20 hover:text-[#a855f7] transition-colors cursor-pointer ml-1"
                        title="Copy shareable link"
                      >
                        <i className="ri-file-copy-line text-[10px]" />
                      </button>
                    </span>
                    {/* Role labels */}
                    <span className="text-white/15 text-[11px] mt-1 flex items-center gap-2 flex-wrap">
                      <span className="flex items-center gap-1">
                        <i className="ri-building-4-line text-white/15 text-[10px]" />
                        {editingStaffLabelId === p.id ? (
                          <span className="flex items-center gap-1">
                            <input value={staffLabel} onChange={(e) => setStaffLabel(e.target.value)} placeholder="BrandStack Staff" className="w-32 px-2 py-0.5 bg-white/[0.06] border border-[#7C3AED]/30 rounded-lg text-white text-[10px] placeholder:text-white/10 focus:outline-none" autoFocus onKeyDown={(e) => { if (e.key === 'Enter') saveStaffLabel(p.id, staffLabel); if (e.key === 'Escape') setEditingStaffLabelId(null); }} />
                            <button onClick={() => saveStaffLabel(p.id, staffLabel)} className="text-emerald-400 text-[9px] hover:underline cursor-pointer">Save</button>
                            <button onClick={() => setEditingStaffLabelId(null)} className="text-white/20 text-[9px] hover:underline cursor-pointer">Cancel</button>
                          </span>
                        ) : (
                          <>
                            <span className="text-white/30">{p.staff_label || 'BrandStack Staff'}</span>
                            <button onClick={() => { setEditingStaffLabelId(p.id); setStaffLabel(p.staff_label || 'BrandStack Staff'); }} className="text-white/15 hover:text-[#a855f7] transition-colors cursor-pointer"><i className="ri-edit-line text-[9px]" /></button>
                          </>
                        )}
                      </span>
                      <span className="text-white/10">|</span>
                      <span className="flex items-center gap-1">
                        <i className="ri-team-line text-white/15 text-[10px]" />
                        {editingClientLabelId === p.id ? (
                          <span className="flex items-center gap-1">
                            <input value={clientLabel} onChange={(e) => setClientLabel(e.target.value)} placeholder="Client Staff" className="w-32 px-2 py-0.5 bg-white/[0.06] border border-emerald-500/30 rounded-lg text-white text-[10px] placeholder:text-white/10 focus:outline-none" autoFocus onKeyDown={(e) => { if (e.key === 'Enter') saveClientLabel(p.id, clientLabel); if (e.key === 'Escape') setEditingClientLabelId(null); }} />
                            <button onClick={() => saveClientLabel(p.id, clientLabel)} className="text-emerald-400 text-[9px] hover:underline cursor-pointer">Save</button>
                            <button onClick={() => setEditingClientLabelId(null)} className="text-white/20 text-[9px] hover:underline cursor-pointer">Cancel</button>
                          </span>
                        ) : (
                          <>
                            <span className="text-white/30">{p.client_label || 'Client Staff'}</span>
                            <button onClick={() => { setEditingClientLabelId(p.id); setClientLabel(p.client_label || 'Client Staff'); }} className="text-white/15 hover:text-emerald-400 transition-colors cursor-pointer"><i className="ri-edit-line text-[9px]" /></button>
                          </>
                        )}
                      </span>
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => { const kw = generateKeyword(); setEditKeywordId(p.id); setEditKeyword(kw); updateKeyword(p.id); }} className="px-3 py-1.5 text-[10px] font-semibold text-white/40 bg-white/[0.04] border border-white/[0.06] rounded-lg hover:text-white/70 transition-all whitespace-nowrap cursor-pointer">
                      <i className="ri-refresh-line mr-1" />Regen
                    </button>
                    <button onClick={() => openPortal(p)} className="px-3 py-1.5 text-xs font-semibold text-[#a855f7] bg-[#7C3AED]/10 rounded-lg hover:bg-[#7C3AED]/20 transition-all cursor-pointer">Open</button>
                  </div>
                </div>
              ))}
              {portals.length === 0 && <p className="text-white/20 text-sm text-center py-12">No clients yet. Create one above.</p>}
            </div>
          </div>
        )}

        {/* PROJECTS TAB */}
        {tab === 'projects' && selectedPortal && !loading && (
          <div>
            <div className="flex items-center gap-2 mb-6">
              <button onClick={() => { setSelectedPortal(null); setSelectedProject(null); setTab('clients'); }} className="text-white/40 hover:text-white/70 transition-colors cursor-pointer">
                <i className="ri-arrow-left-line" /><span className="text-xs font-semibold ml-1">Clients</span>
              </button>
              <span className="text-white/10">/</span>
              <span className="text-white text-sm font-semibold">{selectedPortal.client_name}</span>
            </div>

            <div className="bg-white/[0.02] border border-white/[0.05] rounded-2xl p-5 mb-6">
              <h3 className="font-editorial font-bold text-white text-sm mb-3">Add Project</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-3">
                <input value={newProject.title} onChange={(e) => setNewProject(p => ({ ...p, title: e.target.value }))} placeholder="Project title" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50" />
                <input value={newProject.description} onChange={(e) => setNewProject(p => ({ ...p, description: e.target.value }))} placeholder="Description" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50" />
                <select value={newProject.status} onChange={(e) => setNewProject(p => ({ ...p, status: e.target.value }))} className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs focus:outline-none focus:border-[#7C3AED]/50">
                  {statusOptions.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
                </select>
                <input value={newProject.progress} onChange={(e) => setNewProject(p => ({ ...p, progress: Math.min(100, Math.max(0, Number(e.target.value) || 0)) }))} type="number" min="0" max="100" placeholder="Progress %" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50" />
              </div>
              <div className="flex flex-wrap gap-3 items-center">
                <select value={newProject.priority} onChange={(e) => setNewProject(p => ({ ...p, priority: e.target.value }))} className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs focus:outline-none focus:border-[#7C3AED]/50">
                  {priorityOptions.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
                <select value={newProject.category} onChange={(e) => setNewProject(p => ({ ...p, category: e.target.value }))} className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs focus:outline-none focus:border-[#7C3AED]/50">
                  {categoryOptions.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
                <button onClick={createProject} className="px-5 py-2 text-white text-xs font-semibold rounded-xl bg-[#7C3AED] hover:bg-[#6b21a8] transition-all whitespace-nowrap cursor-pointer">Add Project</button>
              </div>
            </div>

            <div className="space-y-3">
              {projects.map((proj) => (
                <div key={proj.id} className="bg-white/[0.02] border border-white/[0.05] rounded-2xl p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${badgeColors[proj.priority] || badgeColors.medium}`}>{proj.priority}</span>
                        <select value={proj.status} onChange={(e) => updateProject(proj.id, 'status', e.target.value)} className="text-[10px] font-semibold bg-white/[0.04] border border-white/[0.06] rounded-md text-white/50 px-1.5 py-0.5 focus:outline-none cursor-pointer">
                          {statusOptions.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
                        </select>
                        <span className="text-white/15 text-[10px] ml-1">{proj.category}</span>
                      </div>
                      <h3 className="font-editorial font-bold text-white">{proj.title}</h3>
                    </div>
                    <div className="flex items-center gap-2">
                      {editProgressId === proj.id ? (
                        <input
                          value={editProgressVal}
                          onChange={(e) => setEditProgressVal(e.target.value)}
                          onBlur={() => {
                            const val = Math.min(100, Math.max(0, Number(editProgressVal) || 0));
                            updateProject(proj.id, 'progress', val);
                            setEditProgressId(null);
                          }}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              const val = Math.min(100, Math.max(0, Number(editProgressVal) || 0));
                              updateProject(proj.id, 'progress', val);
                              setEditProgressId(null);
                            }
                            if (e.key === 'Escape') setEditProgressId(null);
                          }}
                          type="number" min="0" max="100"
                          className="w-[52px] text-center px-1 py-1 bg-white/[0.06] border border-[#7C3AED]/40 rounded-lg text-white text-xs font-bold focus:outline-none"
                          autoFocus
                        />
                      ) : (
                        <span
                          onClick={() => { setEditProgressId(proj.id); setEditProgressVal(String(proj.progress)); }}
                          className="text-white/25 text-xs font-bold cursor-pointer hover:text-[#a855f7] transition-colors select-none"
                          title="Click to edit progress"
                        >{proj.progress}%</span>
                      )}
                      <button onClick={() => deleteProject(proj.id)} className="text-white/15 hover:text-red-400 transition-colors cursor-pointer"><i className="ri-delete-bin-line text-sm" /></button>
                      {savedId === proj.id && <span className="text-emerald-400 text-[10px] font-semibold">Saved ✓</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="flex-1 h-1.5 bg-white/[0.05] rounded-full overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${proj.progress}%`, background: 'linear-gradient(90deg, #7C3AED, #a855f7)' }} />
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button onClick={() => openProject(proj)} className="px-3 py-1.5 text-[11px] font-semibold text-[#a855f7] bg-[#7C3AED]/10 border border-[#7C3AED]/20 rounded-lg hover:bg-[#7C3AED]/20 transition-all whitespace-nowrap cursor-pointer">
                      <i className="ri-list-check mr-1" />Tasks & Approvals
                    </button>
                    <button onClick={() => { setSelectedProject(proj); setNewTask({ ...newTask, title: '' }); setTab('tasks'); if (selectedPortal) { loadTasks(selectedPortal.id, proj.id); loadApprovals(selectedPortal.id, proj.id); } }} className="px-3 py-1.5 text-[11px] font-semibold text-white/40 bg-white/[0.04] border border-white/[0.06] rounded-lg hover:text-white/70 transition-all whitespace-nowrap cursor-pointer">
                      <i className="ri-add-line mr-1" />Quick Add Task
                    </button>
                  </div>
                </div>
              ))}
              {projects.length === 0 && <p className="text-white/20 text-sm text-center py-12">No projects yet.</p>}
            </div>
          </div>
        )}

        {/* TASKS TAB */}
        {tab === 'tasks' && selectedPortal && !loading && (
          <div>
            <div className="flex items-center gap-2 mb-6">
              <button onClick={() => { setSelectedProject(null); setTab('projects'); }} className="text-white/40 hover:text-white/70 transition-colors cursor-pointer">
                <i className="ri-arrow-left-line" /><span className="text-xs font-semibold ml-1">Projects</span>
              </button>
              {selectedProject && <><span className="text-white/10">/</span><span className="text-white text-sm font-semibold">{selectedProject.title}</span></>}
            </div>

            {selectedProject && (
              <div className="bg-white/[0.02] border border-white/[0.05] rounded-2xl p-5 mb-6">
                <h3 className="font-editorial font-bold text-white text-sm mb-3">Add Task to {selectedProject.title}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-3">
                  <input value={newTask.title} onChange={(e) => setNewTask(t => ({ ...t, title: e.target.value }))} placeholder="Task title" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50" />
                  <input value={newTask.assigned_to} onChange={(e) => setNewTask(t => ({ ...t, assigned_to: e.target.value }))} placeholder="Assigned to" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50" />
                  <input value={newTask.due_date} onChange={(e) => setNewTask(t => ({ ...t, due_date: e.target.value }))} type="date" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs focus:outline-none focus:border-[#7C3AED]/50" />
                </div>
                <div className="flex flex-wrap gap-3 items-center">
                  <select value={newTask.status} onChange={(e) => setNewTask(t => ({ ...t, status: e.target.value }))} className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs focus:outline-none focus:border-[#7C3AED]/50">
                    {taskStatusOptions.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
                  </select>
                  <select value={newTask.priority} onChange={(e) => setNewTask(t => ({ ...t, priority: e.target.value }))} className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs focus:outline-none focus:border-[#7C3AED]/50">
                    {priorityOptions.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                  <button onClick={createTask} className="px-5 py-2 text-white text-xs font-semibold rounded-xl bg-[#7C3AED] hover:bg-[#6b21a8] transition-all whitespace-nowrap cursor-pointer">Add Task</button>
                </div>
              </div>
            )}

            {!selectedProject && (
              <div className="bg-white/[0.02] border border-white/[0.05] rounded-2xl p-5 mb-6">
                <p className="text-white/25 text-xs">Select a project from the Projects tab first to manage its tasks.</p>
              </div>
            )}

            <div className="space-y-1.5">
              {tasks.map((task) => (
                <div key={task.id} className="flex flex-wrap items-center gap-3 bg-white/[0.02] border border-white/[0.05] rounded-xl px-4 py-3">
                  <select value={task.status} onChange={(e) => updateTask(task.id, 'status', e.target.value)} className="text-[10px] font-semibold bg-white/[0.04] border border-white/[0.06] rounded-md px-1.5 py-0.5 focus:outline-none cursor-pointer" style={{ color: task.status === 'completed' ? '#4ade80' : task.status === 'in_progress' ? '#38bdf8' : task.status === 'review' ? '#fbbf24' : 'rgba(255,255,255,0.3)' }}>
                    {taskStatusOptions.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
                  </select>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm ${task.status === 'completed' ? 'text-white/25 line-through' : 'text-white'}`}>{task.title}</p>
                    <div className="flex items-center gap-3 mt-0.5">
                      {task.due_date && <span className="text-white/20 text-[10px]">Due {new Date(task.due_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>}
                      {task.assigned_to && <span className="text-white/15 text-[10px]">{task.assigned_to}</span>}
                      {savedId === task.id && <span className="text-emerald-400 text-[10px] font-semibold">Saved ✓</span>}
                    </div>
                  </div>
                  <span className={`text-[10px] font-semibold px-2 py-1 rounded-md ${badgeColors[task.priority] || badgeColors.medium}`}>{task.priority}</span>
                  <button onClick={() => deleteTask(task.id)} className="text-white/10 hover:text-red-400 transition-colors cursor-pointer"><i className="ri-close-line" /></button>
                </div>
              ))}
              {tasks.length === 0 && <p className="text-white/20 text-sm text-center py-12">{selectedProject ? 'No tasks yet for this project.' : 'Select a project to view tasks.'}</p>}
            </div>
          </div>
        )}

        {/* APPROVALS TAB */}
        {tab === 'approvals' && selectedPortal && !loading && (
          <div>
            <div className="flex items-center gap-2 mb-6">
              <button onClick={() => { setSelectedProject(null); setTab('projects'); }} className="text-white/40 hover:text-white/70 transition-colors cursor-pointer">
                <i className="ri-arrow-left-line" /><span className="text-xs font-semibold ml-1">Projects</span>
              </button>
            </div>

            {selectedProject && (
              <div className="bg-white/[0.02] border border-white/[0.05] rounded-2xl p-5 mb-6">
                <h3 className="font-editorial font-bold text-white text-sm mb-3">Add Approval to {selectedProject.title}</h3>
                <div className="flex flex-wrap gap-3 items-end">
                  <input value={newApproval.title} onChange={(e) => setNewApproval(a => ({ ...a, title: e.target.value }))} placeholder="Approval title" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50 flex-1 min-w-[200px]" />
                  <input value={newApproval.description} onChange={(e) => setNewApproval(a => ({ ...a, description: e.target.value }))} placeholder="Description" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50 flex-1 min-w-[200px]" />
                  <select value={newApproval.priority} onChange={(e) => setNewApproval(a => ({ ...a, priority: e.target.value }))} className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs focus:outline-none focus:border-[#7C3AED]/50">
                    {priorityOptions.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                  <button onClick={createApproval} className="px-5 py-2 text-white text-xs font-semibold rounded-xl bg-[#7C3AED] hover:bg-[#6b21a8] transition-all whitespace-nowrap cursor-pointer">Add & Notify</button>
                </div>
              </div>
            )}

            <div className="space-y-3">
              {approvals.map((app) => (
                <div key={app.id} className="bg-white/[0.02] border border-white/[0.05] rounded-2xl p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${app.status === 'pending' ? 'bg-amber-500/10 text-amber-400' : app.status === 'approved' ? 'bg-emerald-500/10 text-emerald-400' : app.status === 'rejected' ? 'bg-red-500/10 text-red-400' : 'bg-sky-500/10 text-sky-400'}`}>{app.status.replace('_', ' ')}</span>
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${badgeColors[app.priority] || badgeColors.medium}`}>{app.priority}</span>
                      </div>
                      <h3 className="font-editorial font-bold text-white text-sm">{app.title}</h3>
                      <p className="text-white/35 text-xs mt-1">{app.description}</p>
                    </div>
                    <button onClick={() => deleteApproval(app.id)} className="text-white/10 hover:text-red-400 transition-colors cursor-pointer"><i className="ri-delete-bin-line" /></button>
                  </div>
                </div>
              ))}
              {approvals.length === 0 && <p className="text-white/20 text-sm text-center py-12">{selectedProject ? 'No approvals yet for this project.' : 'Select a project to view approvals.'}</p>}
            </div>
          </div>
        )}

        {/* REPORTS TAB */}
        {tab === 'reports' && selectedPortal && !loading && (
          <div>
            <div className="flex items-center gap-2 mb-6">
              <button onClick={() => { setSelectedProject(null); setTab('projects'); }} className="text-white/40 hover:text-white/70 transition-colors cursor-pointer">
                <i className="ri-arrow-left-line" /><span className="text-xs font-semibold ml-1">Projects</span>
              </button>
              <span className="text-white/10">/</span>
              <span className="text-white text-sm font-semibold">{selectedPortal.client_name} Reports</span>
            </div>

            <div className="bg-white/[0.02] border border-white/[0.05] rounded-2xl p-5 mb-6">
              <h3 className="font-editorial font-bold text-white text-sm mb-3">Publish Report</h3>
              <div className="flex flex-wrap gap-3 items-end">
                <input value={newReport.title} onChange={(e) => setNewReport(r => ({ ...r, title: e.target.value }))} placeholder="Report title" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50 flex-1 min-w-[200px]" />
                <select value={newReport.type} onChange={(e) => setNewReport(r => ({ ...r, type: e.target.value }))} className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs focus:outline-none focus:border-[#7C3AED]/50">
                  {reportTypes.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
                <input value={newReport.period_start} onChange={(e) => setNewReport(r => ({ ...r, period_start: e.target.value }))} type="date" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs focus:outline-none focus:border-[#7C3AED]/50" />
                <input value={newReport.period_end} onChange={(e) => setNewReport(r => ({ ...r, period_end: e.target.value }))} type="date" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs focus:outline-none focus:border-[#7C3AED]/50" />
                <button onClick={createReport} className="px-5 py-2 text-white text-xs font-semibold rounded-xl bg-[#7C3AED] hover:bg-[#6b21a8] transition-all whitespace-nowrap cursor-pointer">
                  <i className="ri-send-plane-line mr-1" />Publish & Notify
                </button>
              </div>
            </div>

            <div className="space-y-3">
              {reports.map((r) => (
                <div key={r.id} className="bg-white/[0.02] border border-white/[0.05] rounded-2xl p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] font-semibold uppercase text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded-md">{r.type}</span>
                        {r.status === 'published' && <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md">Published</span>}
                      </div>
                      <h3 className="font-editorial font-bold text-white text-sm">{r.title}</h3>
                      <p className="text-white/20 text-xs mt-0.5">
                        {r.period_start && new Date(r.period_start).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                        {r.period_end && ` — ${new Date(r.period_end).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`}
                      </p>
                    </div>
                    <button onClick={() => deleteReport(r.id)} className="text-white/10 hover:text-red-400 transition-colors cursor-pointer"><i className="ri-delete-bin-line" /></button>
                    <button onClick={() => downloadReport(r)} className="text-white/30 hover:text-[#a855f7] transition-colors cursor-pointer ml-1" title="Download report"><i className="ri-download-line" /></button>
                  </div>
                </div>
              ))}
              {reports.length === 0 && <p className="text-white/20 text-sm text-center py-12">No reports yet.</p>}
            </div>
          </div>
        )}

        {/* AGENDAS TAB */}
        {tab === 'agendas' && selectedPortal && !loading && (
          <div>
            <div className="flex items-center gap-2 mb-6">
              <button onClick={() => setTab('projects')} className="text-white/40 hover:text-white/70 transition-colors cursor-pointer">
                <i className="ri-arrow-left-line" /><span className="text-xs font-semibold ml-1">Projects</span>
              </button>
              <span className="text-white/10">/</span>
              <span className="text-white text-sm font-semibold">{selectedPortal.client_name} Agendas</span>
            </div>

            <div className="bg-white/[0.02] border border-white/[0.05] rounded-2xl p-5 mb-6">
              <h3 className="font-editorial font-bold text-white text-sm mb-1">Push Weekly Agenda</h3>
              <p className="text-white/30 text-xs mb-4">This will appear on the client's dashboard immediately. Add notes and action items for their week.</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-3">
                <input value={newAgenda.title} onChange={(e) => setNewAgenda(a => ({ ...a, title: e.target.value }))} placeholder="Agenda title (e.g. Week of July 28)" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50" />
                <input value={newAgenda.week_start} onChange={(e) => setNewAgenda(a => ({ ...a, week_start: e.target.value }))} type="date" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs focus:outline-none focus:border-[#7C3AED]/50" />
                <input value={newAgenda.week_end} onChange={(e) => setNewAgenda(a => ({ ...a, week_end: e.target.value }))} type="date" className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs focus:outline-none focus:border-[#7C3AED]/50" />
              </div>
              <textarea value={newAgenda.notes} onChange={(e) => setNewAgenda(a => ({ ...a, notes: e.target.value }))} placeholder="Meeting notes & context..." rows={3} className="w-full px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50 mb-3 resize-none" />
              <div className="mb-3">
                <p className="text-white/25 text-[10px] font-semibold uppercase tracking-wider mb-2">Action Items</p>
                {newAgenda.action_items.map((item: string, i: number) => (
                  <div key={i} className="flex items-center gap-2 mb-1.5">
                    <input
                      value={item}
                      onChange={(e) => {
                        const items = [...newAgenda.action_items];
                        items[i] = e.target.value;
                        setNewAgenda(a => ({ ...a, action_items: items }));
                      }}
                      placeholder={`Action item ${i + 1}`}
                      className="flex-1 px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50"
                    />
                    {newAgenda.action_items.length > 1 && (
                      <button onClick={() => setNewAgenda(a => ({ ...a, action_items: a.action_items.filter((_: string, j: number) => j !== i) }))} className="text-white/15 hover:text-red-400 cursor-pointer"><i className="ri-close-line" /></button>
                    )}
                  </div>
                ))}
                <button onClick={() => setNewAgenda(a => ({ ...a, action_items: [...a.action_items, ''] }))} className="text-[#a855f7]/60 hover:text-[#a855f7] text-[10px] font-semibold cursor-pointer transition-colors mt-1">
                  <i className="ri-add-line mr-1" />Add action item
                </button>
              </div>
              <button onClick={createAgenda} className="px-5 py-2 text-white text-xs font-semibold rounded-xl bg-[#7C3AED] hover:bg-[#6b21a8] transition-all whitespace-nowrap cursor-pointer">
                <i className="ri-send-plane-line mr-1" />Publish Agenda
              </button>
            </div>

            <div className="space-y-3">
              {agendas.map((ag) => (
                <div key={ag.id} className="bg-white/[0.02] border border-white/[0.05] rounded-2xl p-5">
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div>
                      <h3 className="font-editorial font-bold text-white text-sm">{ag.title}</h3>
                      <p className="text-white/20 text-xs mt-0.5">
                        {ag.week_start && new Date(ag.week_start).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                        {ag.week_end && ` — ${new Date(ag.week_end).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`}
                      </p>
                    </div>
                    <div className="flex items-center gap-1">
                      {savedId === ag.id && <span className="text-emerald-400 text-[10px] font-semibold mr-1">Saved ✓</span>}
                      <button onClick={() => deleteAgenda(ag.id)} className="text-white/10 hover:text-red-400 transition-colors cursor-pointer"><i className="ri-delete-bin-line" /></button>
                    </div>
                  </div>
                  {ag.notes && (
                    <textarea
                      defaultValue={ag.notes}
                      onBlur={(e) => { if (e.target.value !== ag.notes) updateAgenda(ag.id, 'notes', e.target.value); }}
                      rows={2}
                      className="w-full px-3 py-2 bg-white/[0.02] border border-white/[0.06] rounded-xl text-white/60 text-xs focus:outline-none focus:border-[#7C3AED]/30 resize-none mb-3 cursor-text"
                    />
                  )}
                  {ag.action_items && Array.isArray(ag.action_items) && ag.action_items.length > 0 && (
                    <div className="space-y-1">
                      {ag.action_items.map((item: string, i: number) => (
                        <div key={i} className="flex items-start gap-2">
                          <div className="w-1.5 h-1.5 rounded-full bg-[#a855f7]/60 mt-1.5 flex-shrink-0" />
                          <p className="text-white/35 text-xs leading-relaxed">{item}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              {agendas.length === 0 && <p className="text-white/20 text-sm text-center py-12">No agendas yet. Push one above.</p>}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}