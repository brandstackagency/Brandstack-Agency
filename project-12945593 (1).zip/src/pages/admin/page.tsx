import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';

const ADMIN_PIN = '2222';

// ─── Section data for all pages ─────────────────────────────────────────────
const PAGES = [
  { id: 'home', label: 'Home', icon: 'ri-home-4-line', path: '/' },
  { id: 'pricing', label: 'Services', icon: 'ri-service-line', path: '/pricing' },
  { id: 'about', label: 'About', icon: 'ri-information-line', path: '/about' },
  { id: 'projects', label: 'Projects', icon: 'ri-folder-image-line', path: '/projects' },
  { id: 'contact', label: 'Contact', icon: 'ri-mail-send-line', path: '/contact' },
];

const CONTENT_KEYS: Record<string, { label: string; key: string; type: 'text' | 'textarea' | 'image' }[]> = {
  home: [
    { label: 'Hero Headline', key: 'hero-headline', type: 'text' },
    { label: 'Hero Subtext', key: 'hero-subtext', type: 'textarea' },
    { label: 'Services Section Title', key: 'services-title', type: 'text' },
    { label: 'Services Section Subtitle', key: 'services-subtitle', type: 'textarea' },
    { label: 'Philosophy Headline Line 1', key: 'philosophy-line-1', type: 'text' },
    { label: 'Philosophy Headline Line 2', key: 'philosophy-line-2', type: 'text' },
    { label: 'Philosophy Subtext', key: 'philosophy-subtext', type: 'textarea' },
    { label: 'Philosophy Quote', key: 'philosophy-quote', type: 'textarea' },
    { label: 'Pillar 1 Title', key: 'pillar-1-title', type: 'text' },
    { label: 'Pillar 1 Text', key: 'pillar-1-text', type: 'textarea' },
    { label: 'Pillar 2 Title', key: 'pillar-2-title', type: 'text' },
    { label: 'Pillar 2 Text', key: 'pillar-2-text', type: 'textarea' },
    { label: 'Pillar 3 Title', key: 'pillar-3-title', type: 'text' },
    { label: 'Pillar 3 Text', key: 'pillar-3-text', type: 'textarea' },
  ],
  services: [
    { label: 'Page Hero Title', key: 'services-page-title', type: 'text' },
    { label: 'Page Hero Subtitle', key: 'services-page-subtitle', type: 'textarea' },
    { label: 'GTM Service Title', key: 'gtm-title', type: 'text' },
    { label: 'GTM Description', key: 'gtm-description', type: 'textarea' },
    { label: 'SEG Service Title', key: 'seg-title', type: 'text' },
    { label: 'SEG Description', key: 'seg-description', type: 'textarea' },
    { label: 'Performance Title', key: 'performance-title', type: 'text' },
    { label: 'Performance Description', key: 'performance-description', type: 'textarea' },
    { label: 'Audit Title', key: 'audit-title', type: 'text' },
    { label: 'Audit Description', key: 'audit-description', type: 'textarea' },
  ],
  about: [
    { label: 'Hero Headline', key: 'about-hero-headline', type: 'text' },
    { label: 'Hero Subtext', key: 'about-hero-subtext', type: 'textarea' },
    { label: 'Mission Title', key: 'about-mission-title', type: 'text' },
    { label: 'Mission Text 1', key: 'about-mission-text-1', type: 'textarea' },
    { label: 'Mission Text 2', key: 'about-mission-text-2', type: 'textarea' },
    { label: 'CTA Headline', key: 'about-cta-headline', type: 'text' },
    { label: 'CTA Subtext', key: 'about-cta-subtext', type: 'textarea' },
  ],
  projects: [
    { label: 'Page Header Title', key: 'projects-header-title', type: 'text' },
    { label: 'Page Header Subtitle', key: 'projects-header-subtitle', type: 'textarea' },
    { label: 'Bottom CTA Headline', key: 'projects-cta-headline', type: 'text' },
    { label: 'Bottom CTA Subtext', key: 'projects-cta-subtext', type: 'textarea' },
  ],
  contact: [
    { label: 'Hero Headline', key: 'contact-hero-headline', type: 'text' },
    { label: 'Hero Subtext', key: 'contact-hero-subtext', type: 'textarea' },
    { label: 'Email Address', key: 'contact-email', type: 'text' },
    { label: 'Phone Number', key: 'contact-phone', type: 'text' },
    { label: 'Location', key: 'contact-location', type: 'text' },
  ],
};

const STORAGE_KEY = 'brandstack_editable_content';
const LOGO_KEY = 'brandstack_logo';

function loadContent(): Record<string, string> {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : {};
  } catch {
    return {};
  }
}

function saveContent(data: Record<string, string>) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // ignore
  }
}

// ─── PIN Screen ──────────────────────────────────────────────────────────────
function PinScreen({ onSuccess }: { onSuccess: () => void }) {
  const [pin, setPin] = useState(['', '', '', '']);
  const [error, setError] = useState(false);
  const [shake, setShake] = useState(false);
  const inputRefs = [
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
  ];

  const handleInput = (index: number, value: string) => {
    if (!/^\d?$/.test(value)) return;
    const newPin = [...pin];
    newPin[index] = value;
    setPin(newPin);
    setError(false);

    if (value && index < 3) {
      inputRefs[index + 1].current?.focus();
    }

    if (newPin.every((d) => d !== '') && newPin.join('').length === 4) {
      const entered = newPin.join('');
      if (entered === ADMIN_PIN) {
        onSuccess();
      } else {
        setError(true);
        setShake(true);
        setTimeout(() => {
          setPin(['', '', '', '']);
          setShake(false);
          inputRefs[0].current?.focus();
        }, 600);
      }
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !pin[index] && index > 0) {
      inputRefs[index - 1].current?.focus();
    }
  };

  return (
    <div className="min-h-screen bg-[#0C0B11] flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <div className="text-center mb-10">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#6b21a8] to-[#a855f7] flex items-center justify-center mx-auto mb-6">
            <i className="ri-shield-keyhole-line text-white text-3xl"></i>
          </div>
          <h1 className="font-editorial font-black text-white text-3xl mb-2">Admin Access</h1>
          <p className="text-white/40 text-sm">Enter your 4-digit PIN to continue</p>
        </div>

        <div className={`flex items-center justify-center gap-4 mb-6 ${shake ? 'animate-[shake_0.5s_ease-in-out]' : ''}`}>
          {pin.map((digit, i) => (
            <input
              key={i}
              ref={inputRefs[i]}
              type="password"
              inputMode="numeric"
              maxLength={1}
              value={digit}
              onChange={(e) => handleInput(i, e.target.value)}
              onKeyDown={(e) => handleKeyDown(i, e)}
              className={`w-14 h-14 text-center text-2xl font-bold rounded-xl border-2 bg-white/[0.05] text-white focus:outline-none transition-all duration-200 ${
                error
                  ? 'border-red-500 bg-red-500/10'
                  : digit
                  ? 'border-[#7C3AED] bg-[#7C3AED]/10'
                  : 'border-white/10 focus:border-[#7C3AED]/60'
              }`}
              autoFocus={i === 0}
            />
          ))}
        </div>

        {error && (
          <p className="text-center text-red-400 text-sm animate-fadeIn">
            Incorrect PIN. Please try again.
          </p>
        )}

        <p className="text-center text-white/20 text-xs mt-8">
          Brandstack Agency Admin Panel
        </p>
      </div>

      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          20% { transform: translateX(-8px); }
          40% { transform: translateX(8px); }
          60% { transform: translateX(-6px); }
          80% { transform: translateX(6px); }
        }
      `}</style>
    </div>
  );
}

// ─── Content Editor ──────────────────────────────────────────────────────────
function ContentEditor() {
  const navigate = useNavigate();
  const [activePage, setActivePage] = useState('home');
  const [content, setContent] = useState<Record<string, string>>(loadContent);
  const [saved, setSaved] = useState(false);
  const [logoUrl, setLogoUrl] = useState<string>(() => {
    try { return localStorage.getItem(LOGO_KEY) || ''; } catch { return ''; }
  });
  const logoInputRef = useRef<HTMLInputElement>(null);
  const [activeTab, setActiveTab] = useState<'content' | 'images' | 'sections'>('content');

  const fields = CONTENT_KEYS[activePage] || [];

  const handleChange = (key: string, value: string) => {
    setContent((prev) => ({ ...prev, [key]: value }));
    setSaved(false);
  };

  const handleSave = () => {
    saveContent(content);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const url = ev.target?.result as string;
      setLogoUrl(url);
      try { localStorage.setItem(LOGO_KEY, url); } catch { /* ignore */ }
    };
    reader.readAsDataURL(file);
  };

  const handleClearLogo = () => {
    setLogoUrl('');
    try { localStorage.removeItem(LOGO_KEY); } catch { /* ignore */ }
  };

  const getValue = (key: string, fallback = '') => content[key] ?? fallback;

  return (
    <div className="min-h-screen bg-[#0C0B11] flex">
      {/* Sidebar */}
      <aside className="w-64 bg-[#08080C] border-r border-white/[0.06] flex flex-col fixed top-0 left-0 bottom-0 z-30">
        <div className="p-6 border-b border-white/[0.06]">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#6b21a8] to-[#a855f7] flex items-center justify-center flex-shrink-0">
              <i className="ri-settings-3-line text-white text-sm"></i>
            </div>
            <span
              style={{
                fontFamily: "'League Spartan', sans-serif",
                fontWeight: 700,
                letterSpacing: '0.04em',
                textTransform: 'lowercase',
                background: 'linear-gradient(135deg, #9333ea 0%, #a855f7 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                fontSize: '1.1rem',
              }}
            >
              brandstack
            </span>
          </div>
          <p className="text-white/30 text-xs mt-1 ml-11">Admin Dashboard</p>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          <p className="text-white/20 text-[10px] uppercase tracking-widest font-semibold px-3 mb-3">Pages</p>
          {PAGES.map((page) => (
            <button
              key={page.id}
              onClick={() => setActivePage(page.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 cursor-pointer text-left ${
                activePage === page.id
                  ? 'bg-[#7C3AED]/20 text-[#a855f7] border border-[#7C3AED]/30'
                  : 'text-white/40 hover:text-white/70 hover:bg-white/[0.04]'
              }`}
            >
              <i className={`${page.icon} text-base`}></i>
              {page.label}
            </button>
          ))}

          <div className="pt-4 mt-4 border-t border-white/[0.06]">
            <p className="text-white/20 text-[10px] uppercase tracking-widest font-semibold px-3 mb-3">Quick Links</p>
            <button
              onClick={() => navigate('/')}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-white/40 hover:text-white/70 hover:bg-white/[0.04] transition-all cursor-pointer text-left"
            >
              <i className="ri-eye-line text-base"></i>
              Preview Site
            </button>
          </div>
        </nav>

        <div className="p-4 border-t border-white/[0.06]">
          <button
            onClick={() => navigate('/')}
            className="w-full flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium text-white/30 hover:text-white/60 hover:bg-white/[0.04] transition-all cursor-pointer"
          >
            <i className="ri-logout-box-line text-base"></i>
            Exit Admin
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 ml-64 min-h-screen">
        {/* Top Bar */}
        <header className="sticky top-0 z-20 bg-[#0C0B11]/95 backdrop-blur-md border-b border-white/[0.06] px-8 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-white font-bold text-lg">
              {PAGES.find((p) => p.id === activePage)?.label} Page
            </h1>
            <p className="text-white/30 text-xs mt-0.5">Edit content, images, and sections</p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate(PAGES.find((p) => p.id === activePage)?.path || '/')}
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-white/40 hover:text-white/70 border border-white/[0.08] hover:border-white/20 transition-all cursor-pointer whitespace-nowrap"
            >
              <i className="ri-external-link-line text-sm"></i>
              View Page
            </button>
            <button
              onClick={handleSave}
              className={`flex items-center gap-2 px-5 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer whitespace-nowrap ${
                saved
                  ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                  : 'bg-gradient-to-r from-[#6b21a8] to-[#a855f7] text-white hover:opacity-90'
              }`}
            >
              <i className={`${saved ? 'ri-check-line' : 'ri-save-line'} text-sm`}></i>
              {saved ? 'Saved!' : 'Save Changes'}
            </button>
          </div>
        </header>

        {/* Tab Bar */}
        <div className="px-8 pt-6 pb-0 border-b border-white/[0.06]">
          <div className="flex gap-1 bg-white/[0.04] rounded-xl p-1 w-fit">
            {[
              { id: 'content', label: 'Text Content', icon: 'ri-text' },
              { id: 'images', label: 'Images & Logo', icon: 'ri-image-line' },
              { id: 'sections', label: 'Sections', icon: 'ri-layout-line' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-[#7C3AED] text-white'
                    : 'text-white/40 hover:text-white/70'
                }`}
              >
                <i className={`${tab.icon} text-sm`}></i>
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="p-8">
          {/* Content Tab */}
          {activeTab === 'content' && (
            <div className="space-y-6 max-w-3xl">
              <div className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-5 mb-6">
                <div className="flex items-start gap-3">
                  <i className="ri-information-line text-[#a855f7] text-lg mt-0.5"></i>
                  <p className="text-white/50 text-sm leading-relaxed">
                    Changes made here are saved to your browser and reflected live on the site. Click "Save Changes" to persist them.
                  </p>
                </div>
              </div>

              {fields.map((field) => (
                <div key={field.key} className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-5 hover:border-white/[0.1] transition-all">
                  <label className="block text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">
                    {field.label}
                  </label>
                  {field.type === 'textarea' ? (
                    <textarea
                      value={getValue(field.key)}
                      onChange={(e) => handleChange(field.key, e.target.value)}
                      rows={3}
                      maxLength={500}
                      className="w-full px-4 py-3 text-sm bg-white/[0.04] border border-white/[0.08] rounded-lg text-white placeholder-white/20 focus:outline-none focus:ring-2 focus:ring-[#7C3AED]/40 focus:border-[#7C3AED]/50 transition-all resize-none"
                      placeholder={`Enter ${field.label.toLowerCase()}...`}
                    />
                  ) : (
                    <input
                      type="text"
                      value={getValue(field.key)}
                      onChange={(e) => handleChange(field.key, e.target.value)}
                      className="w-full px-4 py-3 text-sm bg-white/[0.04] border border-white/[0.08] rounded-lg text-white placeholder-white/20 focus:outline-none focus:ring-2 focus:ring-[#7C3AED]/40 focus:border-[#7C3AED]/50 transition-all"
                      placeholder={`Enter ${field.label.toLowerCase()}...`}
                    />
                  )}
                </div>
              ))}

              {fields.length === 0 && (
                <div className="text-center py-16 text-white/30">
                  <i className="ri-file-text-line text-4xl mb-3 block"></i>
                  <p className="text-sm">No editable text fields for this page yet.</p>
                </div>
              )}
            </div>
          )}

          {/* Images Tab */}
          {activeTab === 'images' && (
            <div className="space-y-6 max-w-3xl">
              {/* Logo */}
              <div className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-6">
                <h3 className="text-white font-semibold text-base mb-1">Site Logo</h3>
                <p className="text-white/35 text-sm mb-5">Upload a custom logo to replace the text logo across all pages.</p>

                <div className="flex items-start gap-6">
                  <div className="w-40 h-20 rounded-xl border border-white/[0.08] bg-white/[0.04] flex items-center justify-center overflow-hidden flex-shrink-0">
                    {logoUrl ? (
                      <img src={logoUrl} alt="Current logo" className="max-w-full max-h-full object-contain" />
                    ) : (
                      <span
                        style={{
                          fontFamily: "'League Spartan', sans-serif",
                          fontWeight: 700,
                          letterSpacing: '0.04em',
                          textTransform: 'lowercase',
                          background: 'linear-gradient(135deg, #9333ea 0%, #a855f7 100%)',
                          WebkitBackgroundClip: 'text',
                          WebkitTextFillColor: 'transparent',
                          fontSize: '1.2rem',
                        }}
                      >
                        brandstack
                      </span>
                    )}
                  </div>
                  <div className="flex flex-col gap-3">
                    <button
                      onClick={() => logoInputRef.current?.click()}
                      className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold bg-[#7C3AED]/20 text-[#a855f7] border border-[#7C3AED]/30 hover:bg-[#7C3AED]/30 transition-all cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-upload-line text-sm"></i>
                      Upload Logo
                    </button>
                    {logoUrl && (
                      <button
                        onClick={handleClearLogo}
                        className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20 transition-all cursor-pointer whitespace-nowrap"
                      >
                        <i className="ri-delete-bin-line text-sm"></i>
                        Remove Logo
                      </button>
                    )}
                    <p className="text-white/25 text-xs">PNG, JPG, SVG or WebP. Max 2MB.</p>
                  </div>
                </div>
                <input
                  ref={logoInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/jpg,image/webp,image/svg+xml"
                  onChange={handleLogoUpload}
                  className="hidden"
                />
              </div>

              {/* Project Images Note */}
              <div className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-6">
                <h3 className="text-white font-semibold text-base mb-1">Project Images</h3>
                <p className="text-white/35 text-sm mb-4">
                  To update project images and brand logos, visit the Projects page directly. Each project card has image upload controls.
                </p>
                <button
                  onClick={() => navigate('/projects')}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold bg-white/[0.05] text-white/60 border border-white/[0.08] hover:border-white/20 hover:text-white transition-all cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-folder-image-line text-sm"></i>
                  Go to Projects Page
                </button>
              </div>
            </div>
          )}

          {/* Sections Tab */}
          {activeTab === 'sections' && (
            <div className="space-y-6 max-w-3xl">
              <div className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-5 mb-2">
                <div className="flex items-start gap-3">
                  <i className="ri-information-line text-[#a855f7] text-lg mt-0.5"></i>
                  <p className="text-white/50 text-sm leading-relaxed">
                    Section visibility and ordering for the <strong className="text-white/70">{PAGES.find((p) => p.id === activePage)?.label}</strong> page. Toggle sections on/off or reorder them.
                  </p>
                </div>
              </div>

              <SectionManager pageId={activePage} />
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

// ─── Section Manager ─────────────────────────────────────────────────────────
const PAGE_SECTIONS: Record<string, { id: string; label: string; icon: string }[]> = {
  home: [
    { id: 'hero', label: 'Hero', icon: 'ri-layout-top-line' },
    { id: 'marquee', label: 'Marquee Ticker', icon: 'ri-text-wrap' },
    { id: 'services', label: 'Services', icon: 'ri-service-line' },
    { id: 'philosophy', label: 'The Thinking', icon: 'ri-lightbulb-line' },
    { id: 'how-it-works', label: 'How It Works', icon: 'ri-flow-chart' },
    { id: 'featured-projects', label: 'Featured Projects', icon: 'ri-folder-image-line' },
    { id: 'client-logos', label: 'Client Logos', icon: 'ri-building-line' },
    { id: 'cta', label: 'CTA Banner', icon: 'ri-megaphone-line' },
    { id: 'booking-form', label: 'Booking Form', icon: 'ri-calendar-line' },
  ],
  services: [
    { id: 'hero', label: 'Hero', icon: 'ri-layout-top-line' },
    { id: 'services-list', label: 'Services List', icon: 'ri-list-check' },
    { id: 'bottom-cta', label: 'Bottom CTA', icon: 'ri-megaphone-line' },
  ],
  about: [
    { id: 'hero', label: 'Hero', icon: 'ri-layout-top-line' },
    { id: 'mission', label: 'Mission Statement', icon: 'ri-focus-3-line' },
    { id: 'core-beliefs', label: 'Core Beliefs', icon: 'ri-heart-line' },
    { id: 'who-we-work-with', label: 'Who We Work With', icon: 'ri-team-line' },
    { id: 'our-approach', label: 'Our Approach', icon: 'ri-compass-3-line' },
    { id: 'cta', label: 'CTA', icon: 'ri-megaphone-line' },
  ],
  projects: [
    { id: 'header', label: 'Page Header', icon: 'ri-layout-top-line' },
    { id: 'filter-bar', label: 'Filter Bar', icon: 'ri-filter-line' },
    { id: 'projects-grid', label: 'Projects Grid', icon: 'ri-grid-line' },
    { id: 'bottom-cta', label: 'Bottom CTA', icon: 'ri-megaphone-line' },
  ],
  contact: [
    { id: 'hero', label: 'Hero', icon: 'ri-layout-top-line' },
    { id: 'form', label: 'Contact Form', icon: 'ri-mail-send-line' },
  ],
};

const SECTION_VISIBILITY_KEY = 'brandstack_section_visibility';

function SectionManager({ pageId }: { pageId: string }) {
  const sections = PAGE_SECTIONS[pageId] || [];

  const [visibility, setVisibility] = useState<Record<string, boolean>>(() => {
    try {
      const stored = localStorage.getItem(SECTION_VISIBILITY_KEY);
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  });

  const [order, setOrder] = useState<string[]>(() => sections.map((s) => s.id));
  const [dragId, setDragId] = useState<string | null>(null);

  const isVisible = (id: string) => visibility[`${pageId}-${id}`] !== false;

  const toggleVisibility = (id: string) => {
    const key = `${pageId}-${id}`;
    const updated = { ...visibility, [key]: !isVisible(id) };
    setVisibility(updated);
    try { localStorage.setItem(SECTION_VISIBILITY_KEY, JSON.stringify(updated)); } catch { /* ignore */ }
  };

  const handleDragStart = (id: string) => setDragId(id);
  const handleDragOver = (e: React.DragEvent, targetId: string) => {
    e.preventDefault();
    if (!dragId || dragId === targetId) return;
    const newOrder = [...order];
    const fromIdx = newOrder.indexOf(dragId);
    const toIdx = newOrder.indexOf(targetId);
    newOrder.splice(fromIdx, 1);
    newOrder.splice(toIdx, 0, dragId);
    setOrder(newOrder);
  };
  const handleDragEnd = () => setDragId(null);

  const orderedSections = order
    .map((id) => sections.find((s) => s.id === id))
    .filter(Boolean) as typeof sections;

  return (
    <div className="space-y-3">
      {orderedSections.map((section) => (
        <div
          key={section.id}
          draggable
          onDragStart={() => handleDragStart(section.id)}
          onDragOver={(e) => handleDragOver(e, section.id)}
          onDragEnd={handleDragEnd}
          className={`flex items-center gap-4 p-4 rounded-xl border transition-all duration-200 cursor-grab active:cursor-grabbing ${
            dragId === section.id
              ? 'border-[#7C3AED]/50 bg-[#7C3AED]/10 opacity-70'
              : 'border-white/[0.06] bg-white/[0.03] hover:border-white/[0.1]'
          }`}
        >
          <i className="ri-drag-move-line text-white/20 text-lg flex-shrink-0"></i>
          <div className="w-8 h-8 rounded-lg bg-white/[0.05] flex items-center justify-center flex-shrink-0">
            <i className={`${section.icon} text-[#a855f7] text-sm`}></i>
          </div>
          <span className={`flex-1 text-sm font-medium ${isVisible(section.id) ? 'text-white/80' : 'text-white/30 line-through'}`}>
            {section.label}
          </span>
          <button
            onClick={() => toggleVisibility(section.id)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
              isVisible(section.id)
                ? 'bg-green-500/10 text-green-400 border border-green-500/20 hover:bg-green-500/20'
                : 'bg-white/[0.05] text-white/30 border border-white/[0.08] hover:border-white/20'
            }`}
          >
            <i className={`${isVisible(section.id) ? 'ri-eye-line' : 'ri-eye-off-line'} text-xs`}></i>
            {isVisible(section.id) ? 'Visible' : 'Hidden'}
          </button>
        </div>
      ))}

      <div className="pt-4">
        <button className="flex items-center gap-2 px-4 py-3 rounded-xl border border-dashed border-white/[0.1] text-white/30 hover:border-[#7C3AED]/40 hover:text-[#a855f7] transition-all cursor-pointer w-full justify-center text-sm font-medium">
          <i className="ri-add-line text-base"></i>
          Add New Section
        </button>
      </div>
    </div>
  );
}

// ─── Main Export ─────────────────────────────────────────────────────────────
export default function AdminPage() {
  const [authenticated, setAuthenticated] = useState(false);

  if (!authenticated) {
    return <PinScreen onSuccess={() => setAuthenticated(true)} />;
  }

  return <ContentEditor />;
}
