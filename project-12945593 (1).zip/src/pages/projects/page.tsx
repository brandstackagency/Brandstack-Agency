import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../home/components/Navbar';
import Footer from '../home/components/Footer';
import GridBackground from '../../components/feature/GridBackground';
import ProjectGallery from '../../components/feature/ProjectGallery';
import VideoGallery from '../../components/feature/VideoGallery';
import { EditableProjectField, EditableProjectImage, EditableProjectMetrics } from '../../components/feature/EditableProject';
import { useEditMode } from '../../contexts/EditModeContext';
import { defaultProjects } from '../../data/projects';

interface Project {
  id: number;
  title: string;
  category: string;
  tagline: string;
  description: string;
  challenge: string;
  solution: string;
  advantageGained: string;
  image: string;
  coverImage: string;
  tags: string[];
  metrics: Array<{ label: string; value: string }>;
  year: string;
  color: string;
  slug: string;
  website?: string;
  services: string[];
}

const SERVICE_MAP: Record<string, { label: string; icon: string; slug: string }> = {
  gtm: { label: 'Go-To-Market Launchpad', icon: 'ri-rocket-line', slug: 'gtm-launchpad' },
  seg: { label: 'SEG Framework', icon: 'ri-line-chart-line', slug: 'seg-framework' },
  performance: { label: 'Performance Marketing', icon: 'ri-bar-chart-box-line', slug: 'performance-marketing' },
  audit: { label: 'Marketing Audit', icon: 'ri-search-line', slug: 'marketing-audit' },
};

const COVER_STORAGE_KEY = 'brandstack_project_covers';

// ─── Editable Brand Logo Component ──────────────────────────────────────────
function EditableBrandLogo({
  projectSlug,
  brandName,
  className = '',
}: {
  projectSlug: string;
  brandName: string;
  className?: string;
}) {
  const { isEditMode } = useEditMode();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [currentLogo, setCurrentLogo] = useState<string>(() => {
    try {
      const stored = localStorage.getItem(`brand-logo-${projectSlug}`);
      return stored || '';
    } catch {
      return '';
    }
  });

  const handleClick = () => {
    if (isEditMode) fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const url = ev.target?.result as string;
      try {
        localStorage.setItem(`brand-logo-${projectSlug}`, url);
      } catch (err) {
        console.warn('Could not save brand logo to storage:', err);
      }
      setCurrentLogo(url);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="relative group">
      <div
        onClick={handleClick}
        className={`${className} ${
          isEditMode ? 'cursor-pointer hover:ring-4 hover:ring-[#5B2DFF]/30 transition-all' : ''
        } bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6 flex items-center justify-center overflow-hidden`}
      >
        {currentLogo ? (
          <img
            src={currentLogo}
            alt={`${brandName} logo`}
            loading="lazy"
            className="max-w-full max-h-full w-auto h-auto object-contain"
          />
        ) : (
          <div className="text-center">
            <i className="ri-image-add-line text-4xl text-white/30 mb-2 block"></i>
            <p className="text-white/40 text-sm font-semibold">
              {isEditMode ? 'Click to Upload Brand Logo' : brandName}
            </p>
          </div>
        )}
      </div>
      {isEditMode && (
        <>
          <div className="absolute top-2 right-2 z-20 flex items-center gap-1 px-2 py-1 bg-[#5B2DFF] text-white text-xs font-bold rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
            <i className="ri-upload-line"></i>
            Upload
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/png,image/jpeg,image/jpg,image/webp,image/svg+xml"
            onChange={handleFileChange}
            className="hidden"
          />
        </>
      )}
    </div>
  );
}

// ─── Editable Cover Image ────────────────────────────────────────────────────
function EditableCoverImage({
  projectId,
  defaultImage,
  alt,
  className = '',
}: {
  projectId: number;
  defaultImage: string;
  alt: string;
  className?: string;
}) {
  const { isEditMode } = useEditMode();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [currentImage, setCurrentImage] = useState<string>(() => {
    try {
      const stored = localStorage.getItem(COVER_STORAGE_KEY);
      const data = stored ? JSON.parse(stored) : {};
      return data[projectId] ?? defaultImage;
    } catch {
      return defaultImage;
    }
  });

  const handleClick = () => {
    if (isEditMode) fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const url = ev.target?.result as string;
      try {
        const stored = localStorage.getItem(COVER_STORAGE_KEY);
        const data = stored ? JSON.parse(stored) : {};
        data[projectId] = url;
        localStorage.setItem(COVER_STORAGE_KEY, JSON.stringify(data));
      } catch (err) {
        console.warn('Could not save cover image to storage:', err);
      }
      setCurrentImage(url);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="relative w-full h-full group">
      <img src={currentImage} alt={alt} className={className} />
      {isEditMode && (
        <>
          <button
            onClick={handleClick}
            className="absolute bottom-4 right-4 z-20 flex items-center gap-2 px-4 py-2 bg-black/70 hover:bg-black/90 text-white text-xs font-bold rounded-full backdrop-blur-sm border border-white/20 transition-all cursor-pointer whitespace-nowrap"
          >
            <i className="ri-image-edit-line text-sm"></i>
            Change Cover
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/png,image/jpeg,image/jpg,image/webp"
            onChange={handleFileChange}
            className="hidden"
          />
        </>
      )}
    </div>
  );
}

// ─── Services Used Badge Strip ───────────────────────────────────────────────
function ServicesBadges({
  services,
  color,
  onNavigate,
}: {
  services: string[];
  color: string;
  onNavigate: (slug: string) => void;
}) {
  return (
    <section className="py-10 bg-white border-b border-black/[0.06]">
      <div className="max-w-5xl mx-auto px-8 lg:px-16">
        <div className="flex flex-wrap items-center gap-4">
          <span className="text-xs font-bold uppercase tracking-widest text-black/40 mr-2">
            Services Used
          </span>
          {services.map((key) => {
            const svc = SERVICE_MAP[key];
            if (!svc) return null;
            return (
              <button
                key={key}
                onClick={() => onNavigate(svc.slug)}
                className="flex items-center gap-2 px-4 py-2 rounded-full border text-sm font-semibold transition-all hover:scale-105 cursor-pointer whitespace-nowrap"
                style={{
                  borderColor: `${color}40`,
                  color: color,
                  background: `${color}10`,
                }}
              >
                <i className={`${svc.icon} text-base`}></i>
                {svc.label}
                <i className="ri-arrow-right-up-line text-xs opacity-60"></i>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// ─── Main Component ──────────────────────────────────────────────────────────
export default function ProjectsPage() {
  const navigate = useNavigate();
  const { isEditMode } = useEditMode();
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const selectedProject = selectedId !== null ? defaultProjects.find((p: Project) => p.id === selectedId) : null;

  if (selectedProject) {
    return (
      <div className="min-h-screen bg-[#0C0B11]">
        <Navbar />

        {/* Top Bar - Below Navbar */}
        <div className="fixed top-20 md:top-24 left-0 right-0 z-40 bg-[#0C0B11]/90 backdrop-blur-md border-b border-white/[0.06]">
          <div className="max-w-5xl mx-auto px-8 lg:px-16 h-16 flex items-center justify-between">
            <button
              onClick={() => setSelectedId(null)}
              className="flex items-center gap-2 text-sm font-semibold text-white/50 hover:text-white transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-arrow-left-line text-lg"></i>
              Back to Projects
            </button>
            <div className="flex items-center gap-3">
              {selectedProject.website && (
                <a
                  href={selectedProject.website}
                  target="_blank"
                  rel="nofollow noopener noreferrer"
                  className="flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-full border border-black/10 text-black/50 hover:text-black hover:border-black/30 transition-all whitespace-nowrap"
                >
                  <i className="ri-external-link-line"></i>
                  Visit Site
                </a>
              )}
              {isEditMode && (
                <span className="text-xs font-semibold px-3 py-1 rounded-full border"
                  style={{ color: selectedProject.color, background: `${selectedProject.color}15`, borderColor: `${selectedProject.color}30` }}>
                  <i className="ri-edit-line mr-1"></i>
                  Edit Mode Active
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Hero Cover - Adjusted padding for navbar + top bar */}
        <section className="relative pt-36 md:pt-40 h-[72vh] overflow-hidden">
          <EditableCoverImage
            projectId={selectedProject.id}
            defaultImage={selectedProject.coverImage}
            alt={selectedProject.title}
            className="w-full h-full object-cover object-top"
          />
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: 'linear-gradient(to bottom, rgba(0,0,0,0.08) 0%, rgba(0,0,0,0.72) 100%)',
            }}
          />
          <div className="absolute bottom-0 left-0 right-0 p-10 lg:p-16 max-w-5xl mx-auto">
            <div className="flex items-center gap-3 mb-4">
              <span
                className="text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full"
                style={{
                  background: `${selectedProject.color}35`,
                  color: selectedProject.color,
                  border: `1px solid ${selectedProject.color}55`,
                }}
              >
                {selectedProject.category}
              </span>
              <span className="text-white/50 text-xs font-semibold">{selectedProject.year}</span>
            </div>
            <EditableProjectField
              projectId={selectedProject.id}
              field="title"
              defaultValue={selectedProject.title}
              as="h1"
              className="font-editorial font-black text-white text-5xl lg:text-7xl mb-4 leading-none"
            />
            <EditableProjectField
              projectId={selectedProject.id}
              field="tagline"
              defaultValue={selectedProject.tagline}
              as="p"
              className="text-white/80 text-xl lg:text-2xl max-w-2xl leading-relaxed"
            />
          </div>
        </section>

        {/* Services Used */}
        <ServicesBadges
          services={selectedProject.services}
          color={selectedProject.color}
          onNavigate={(slug) => navigate('/pricing')}
        />

        {/* Brand Logo Section */}
        <section
          className="py-12 relative overflow-hidden"
          style={{ background: `linear-gradient(135deg, ${selectedProject.color}15 0%, ${selectedProject.color}08 100%)` }}
        >
          <div className="relative z-10 max-w-5xl mx-auto px-8 lg:px-16">
            <div className="flex items-center gap-3 mb-6">
              <div
                className="w-10 h-10 flex items-center justify-center rounded-xl border"
                style={{ background: `${selectedProject.color}20`, borderColor: `${selectedProject.color}40` }}
              >
                <i className="ri-building-line text-xl" style={{ color: selectedProject.color }}></i>
              </div>
              <h2 className="font-editorial font-bold text-[#0D0D0D] text-2xl">Brand Identity</h2>
            </div>
            <div className="max-w-md">
              <EditableBrandLogo
                projectSlug={selectedProject.slug}
                brandName={selectedProject.title}
                className="h-32"
              />
              {isEditMode && (
                <p className="mt-3 text-sm text-black/40 italic">
                  <i className="ri-information-line mr-1"></i>
                  Upload the brand logo here. It will appear on the homepage "Brands That Trust Us" section
                </p>
              )}
            </div>
          </div>
        </section>

        {/* Metrics Strip */}
        <section
          className="py-12 relative overflow-hidden"
          style={{ background: `linear-gradient(135deg, ${selectedProject.color} 0%, ${selectedProject.color}CC 100%)` }}
        >
          <div className="relative z-10 max-w-5xl mx-auto px-8 lg:px-16">
            <EditableProjectMetrics
              projectId={selectedProject.id}
              defaultMetrics={selectedProject.metrics}
            />
          </div>
        </section>

        {/* Overview */}
        <section className="py-14 bg-white relative overflow-hidden">
          <GridBackground variant="light" />
          <div className="relative z-10 max-w-5xl mx-auto px-8 lg:px-16">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
              <div>
                <div className="flex items-center gap-3 mb-6">
                  <div
                    className="w-10 h-10 flex items-center justify-center rounded-xl border"
                    style={{ background: `${selectedProject.color}15`, borderColor: `${selectedProject.color}30` }}
                  >
                    <i className="ri-file-text-line text-xl" style={{ color: selectedProject.color }}></i>
                  </div>
                  <h2 className="font-editorial font-bold text-[#0D0D0D] text-2xl">Project Overview</h2>
                </div>
                <EditableProjectField
                  projectId={selectedProject.id}
                  field="description"
                  defaultValue={selectedProject.description}
                  as="p"
                  className="text-black/60 leading-relaxed text-lg"
                  multiline
                />
              </div>
              <div className="relative rounded-2xl overflow-hidden shadow-xl">
                <EditableProjectImage
                  projectId={selectedProject.id}
                  defaultImage={selectedProject.image}
                  alt={selectedProject.title}
                  className="w-full h-72 object-cover object-top"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Challenge */}
        <section className="py-14 bg-[#F8F7F4] relative overflow-hidden">
          <GridBackground variant="light" />
          <div className="relative z-10 max-w-5xl mx-auto px-8 lg:px-16">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 flex items-center justify-center bg-red-500/10 rounded-xl border border-red-500/20">
                <i className="ri-error-warning-line text-xl text-red-500"></i>
              </div>
              <h2 className="font-editorial font-bold text-[#0D0D0D] text-2xl">The Challenge</h2>
            </div>
            <div className="bg-white p-8 rounded-xl border-l-4 border-red-400 shadow-sm">
              <EditableProjectField
                projectId={selectedProject.id}
                field="challenge"
                defaultValue={selectedProject.challenge}
                as="p"
                className="text-black/60 leading-relaxed text-lg"
                multiline
              />
            </div>
          </div>
        </section>

        {/* Solution */}
        <section className="py-14 bg-white relative overflow-hidden">
          <GridBackground variant="light" />
          <div className="relative z-10 max-w-5xl mx-auto px-8 lg:px-16">
            <div className="flex items-center gap-3 mb-8">
              <div
                className="w-10 h-10 flex items-center justify-center rounded-xl border"
                style={{ background: `${selectedProject.color}15`, borderColor: `${selectedProject.color}30` }}
              >
                <i className="ri-lightbulb-line text-xl" style={{ color: selectedProject.color }}></i>
              </div>
              <h2 className="font-editorial font-bold text-[#0D0D0D] text-2xl">Our Solution</h2>
            </div>
            <div
              className="bg-white p-8 rounded-xl border-l-4 shadow-sm"
              style={{ borderColor: selectedProject.color }}
            >
              <EditableProjectField
                projectId={selectedProject.id}
                field="solution"
                defaultValue={selectedProject.solution}
                as="p"
                className="text-black/60 leading-relaxed text-lg"
                multiline
              />
            </div>
          </div>
        </section>

        {/* Advantage Gained */}
        <section className="py-14 bg-[#F8F7F4] relative overflow-hidden">
          <GridBackground variant="light" />
          <div className="relative z-10 max-w-5xl mx-auto px-8 lg:px-16">
            <div className="flex items-center gap-3 mb-8">
              <div
                className="w-10 h-10 flex items-center justify-center rounded-xl border"
                style={{ background: `${selectedProject.color}15`, borderColor: `${selectedProject.color}30` }}
              >
                <i className="ri-vip-crown-line text-xl" style={{ color: selectedProject.color }}></i>
              </div>
              <h2 className="font-editorial font-bold text-[#0D0D0D] text-2xl">The Advantage Gained</h2>
            </div>
            <div
              className="bg-white p-8 rounded-xl border-l-4 shadow-sm"
              style={{ borderColor: selectedProject.color }}
            >
              <EditableProjectField
                projectId={selectedProject.id}
                field="advantageGained"
                defaultValue={selectedProject.advantageGained}
                as="p"
                className="text-black/55 leading-relaxed text-lg italic"
                multiline
              />
            </div>
            <div className="mt-10 flex items-center justify-center gap-4">
              <div className="w-20 h-px" style={{ background: `${selectedProject.color}50` }}></div>
              <i className="ri-focus-3-line text-2xl" style={{ color: selectedProject.color }}></i>
              <div className="w-20 h-px" style={{ background: `${selectedProject.color}50` }}></div>
            </div>
          </div>
        </section>

        {/* Photo Gallery */}
        <ProjectGallery projectId={selectedProject.id} />

        {/* Video Gallery */}
        <VideoGallery projectId={String(selectedProject.id)} />

        {/* CTA */}
        <section
          className="py-20 relative overflow-hidden"
          style={{ background: `linear-gradient(135deg, ${selectedProject.color} 0%, ${selectedProject.color}CC 100%)` }}
        >
          <div
            className="absolute inset-0 pointer-events-none opacity-10"
            style={{
              backgroundImage:
                'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)',
              backgroundSize: '52px 52px',
            }}
          />
          <div className="relative z-10 max-w-3xl mx-auto px-8 text-center">
            <h2 className="font-editorial font-black text-white text-4xl lg:text-5xl mb-4 leading-tight">
              Ready to build your brand?
            </h2>
            <p className="text-white/70 text-lg mb-8 leading-relaxed">
              Let&apos;s create something that moves markets. Tell us about your project.
            </p>
            <button
              onClick={() => navigate('/contact')}
              className="inline-flex items-center gap-3 px-8 py-4 bg-white font-bold text-base rounded-full hover:bg-white/90 transition-all duration-300 shadow-xl cursor-pointer whitespace-nowrap"
              style={{ color: selectedProject.color }}
            >
              Book Us For This
              <i className="ri-arrow-right-line text-lg"></i>
            </button>
          </div>
        </section>

        <Footer />
      </div>
    );
  }

  // ─── Projects List ───────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-[#0C0B11]">
      <Navbar />

      {/* Hero */}
      <section className="relative pt-44 md:pt-48 pb-12 overflow-hidden">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              'radial-gradient(ellipse 80% 60% at 50% 0%, rgba(124,58,237,0.22) 0%, transparent 70%)',
          }}
        />
        <div className="relative z-10 max-w-5xl mx-auto px-8 lg:px-16 text-center">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-10 h-px bg-[#7C3AED]" />
            <span className="text-[#7C3AED] text-xs font-semibold uppercase tracking-[0.2em]">
              Our Work
            </span>
            <div className="w-10 h-px bg-[#7C3AED]" />
          </div>
          <h1
            className="font-editorial font-black text-white mb-6 leading-none"
            style={{ fontSize: 'clamp(2.5rem, 7vw, 6rem)' }}
          >
            Projects That{' '}
            <span
              className="italic"
              style={{
                background: 'linear-gradient(135deg, #a855f7 0%, #7C3AED 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              Move Markets
            </span>
          </h1>
          <p className="text-white/50 text-base md:text-lg max-w-2xl mx-auto leading-relaxed mb-8">
            Every brand we build is a strategic weapon. Here&apos;s proof.
          </p>
        </div>
      </section>

      {/* Work In Progress: IG CTA */}
      <section className="min-h-[60vh] flex items-center justify-center bg-[#0C0B11] relative overflow-hidden pb-24">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              'radial-gradient(ellipse 60% 50% at 50% 40%, rgba(124,58,237,0.15) 0%, transparent 70%)',
          }}
        />
        <div className="relative z-10 max-w-2xl mx-auto px-8 text-center">
          <div className="mb-8 flex justify-center">
            <div className="relative">
              <div className="w-24 h-24 md:w-28 md:h-28 flex items-center justify-center rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-sm">
                <i className="ri-hammer-line text-5xl md:text-6xl text-[#7C3AED]/60" />
              </div>
              <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#a855f7] animate-pulse" />
            </div>
          </div>

          <h2 className="font-editorial font-black text-white text-3xl md:text-4xl lg:text-5xl mb-5 leading-tight">
            We're in the Lab rn
          </h2>

          <p className="text-white/40 text-base md:text-lg leading-relaxed mb-4">
            Right now we're deep in the trenches building some seriously cool stuff for our current clients. New brands, fresh campaigns, big moves.
          </p>

          <p className="text-white/30 text-sm md:text-base leading-relaxed mb-10">
            Our polished case studies are getting a glow up behind the scenes. While we wrap those up, catch us in real time, see what we're up to day to day, and peep past work on the gram.
          </p>

          <a
            href="https://instagram.com/brandstackagency"
            target="_blank"
            rel="nofollow noopener noreferrer"
            className="inline-flex items-center gap-3 px-8 py-4 text-white font-bold text-base rounded-full hover:opacity-90 transition-all duration-300 hover:scale-105 whitespace-nowrap cursor-pointer"
            style={{
              background: 'linear-gradient(135deg, #6b21a8 0%, #7C3AED 60%, #a855f7 100%)',
              boxShadow: '0 4px 24px rgba(124,58,237,0.35)',
            }}
          >
            <i className="ri-instagram-line text-xl" />
            <span>@brandstackagency</span>
            <i className="ri-arrow-right-up-line text-lg" />
          </a>

          <p className="text-white/20 mt-8 text-sm">
            Fresh case studies incoming. Stay tuned.
          </p>
        </div>
      </section>

      <Footer />
    </div>
  );
}
