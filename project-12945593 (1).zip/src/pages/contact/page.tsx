import { useState, FormEvent } from 'react';
import Navbar from '../home/components/Navbar';
import Footer from '../home/components/Footer';
import GridBackground from '../../components/feature/GridBackground';
import ScrollReveal from '../../components/feature/ScrollReveal';
import { useEffect, useRef } from 'react';

export default function ContactPage() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    revenueStage: '',
    serviceInterest: '',
    budgetRange: '',
    message: ''
  });

  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animFrame: number;
    let t = 0;

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const blobs = [
      { x: 0.15, y: 0.25, r: 0.35, color: 'rgba(91,45,255,0.08)' },
      { x: 0.82, y: 0.18, r: 0.28, color: 'rgba(0,210,200,0.06)' },
      { x: 0.50, y: 0.75, r: 0.30, color: 'rgba(220,60,180,0.05)' },
    ];

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      blobs.forEach((b, i) => {
        const ox = Math.sin(t * 0.0004 + i * 1.3) * 0.06;
        const oy = Math.cos(t * 0.0003 + i * 0.9) * 0.05;
        const gx = (b.x + ox) * canvas.width;
        const gy = (b.y + oy) * canvas.height;
        const gr = b.r * Math.max(canvas.width, canvas.height);
        const grad = ctx.createRadialGradient(gx, gy, 0, gx, gy, gr);
        grad.addColorStop(0, b.color);
        grad.addColorStop(1, 'transparent');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(gx, gy, gr, 0, Math.PI * 2);
        ctx.fill();
      });
      t++;
      animFrame = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animFrame);
      window.removeEventListener('resize', resize);
    };
  }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    setErrorMessage('');

    try {
      const response = await fetch('https://readdy.ai/api/form/d6gk77b7ks76vrd3kung', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          name: formData.name,
          email: formData.email,
          company: formData.company,
          phone: formData.phone,
          revenueStage: formData.revenueStage,
          serviceInterest: formData.serviceInterest,
          budgetRange: formData.budgetRange,
          message: formData.message
        }).toString()
      });

      if (response.ok) {
        setStatus('success');
        setFormData({
          name: '',
          email: '',
          company: '',
          phone: '',
          revenueStage: '',
          serviceInterest: '',
          budgetRange: '',
          message: ''
        });
      } else {
        setStatus('error');
        setErrorMessage('Failed to submit. Please try again.');
      }
    } catch (error) {
      setStatus('error');
      setErrorMessage('Network error. Please check your connection and try again.');
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className="min-h-screen bg-[#0C0B11]">
      <Navbar />

      {/* Aurora canvas */}
      <canvas
        ref={canvasRef}
        className="fixed inset-0 w-full h-full pointer-events-none z-0"
        style={{ filter: 'blur(80px)', opacity: 0.6 }}
      />

      {/* Grain overlay */}
      <div
        className="fixed inset-0 opacity-[0.03] pointer-events-none z-10"
        style={{
          backgroundImage:
            'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 512 512\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'n\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.75\' numOctaves=\'4\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23n)\'/%3E%3C/svg%3E")',
          backgroundRepeat: 'repeat',
          backgroundSize: '200px 200px',
          mixBlendMode: 'multiply',
        }}
      />

      <GridBackground variant="light" className="z-10" />

      {/* Hero Section */}
      <section className="relative pt-40 pb-16 overflow-hidden">
        <div className="max-w-7xl mx-auto px-8 lg:px-16 relative z-20">
          <ScrollReveal direction="up" delay={0}>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-px bg-[#5B2DFF]" />
              <span className="text-[#5B2DFF] text-xs font-semibold uppercase tracking-[0.2em]">
                Let's Connect
              </span>
            </div>
          </ScrollReveal>

          <ScrollReveal direction="up" delay={80}>
            <h1
              className="font-editorial font-black text-white leading-[0.95] tracking-tight mb-6"
              style={{ fontSize: 'clamp(3rem, 6vw, 6rem)' }}
            >
              Ready to Make<br />
              <span className="italic" style={{ background: 'linear-gradient(135deg, #9333ea 0%, #a855f7 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Your Move?</span>
            </h1>
          </ScrollReveal>

          <ScrollReveal direction="up" delay={160}>
            <p className="text-white/40 text-lg leading-relaxed max-w-2xl">
              Book a 30-minute discovery call. We'll assess your current position, identify growth opportunities, and map out the best strategic path forward.
            </p>
          </ScrollReveal>
        </div>
      </section>

      {/* Two-Column Form Section */}
      <section id="contact" className="relative py-20 overflow-hidden">
        <div className="max-w-7xl mx-auto px-8 lg:px-16 relative z-20">
          <div className="grid grid-cols-1 lg:grid-cols-[400px_1fr] gap-12 lg:gap-16">
            {/* Left Column - Sticky Info */}
            <div className="lg:sticky lg:top-32 lg:self-start">
              <ScrollReveal direction="left" delay={0}>
                <div className="space-y-8">
                  {/* Benefits */}
                  <div>
                    <h3 className="font-editorial font-bold text-white text-2xl mb-5">
                      What You'll Get
                    </h3>
                    <ul className="space-y-4">
                      {[
                        { icon: 'ri-time-line', text: '30-minute strategy session' },
                        { icon: 'ri-lightbulb-line', text: 'Free marketing insights' },
                        { icon: 'ri-shield-check-line', text: 'No commitment required' },
                        { icon: 'ri-mail-check-line', text: '24-hour response time' },
                      ].map((item, i) => (
                        <li key={i} className="flex items-start gap-3">
                          <div className="w-8 h-8 flex items-center justify-center bg-[#5B2DFF]/10 rounded-full flex-shrink-0 mt-0.5">
                            <i className={`${item.icon} text-[#5B2DFF] text-sm`} />
                          </div>
                          <span className="text-white/50 text-sm leading-relaxed pt-1">{item.text}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Contact Cards */}
                  <div className="space-y-4 pt-4">
                    <div className="bg-white/60 backdrop-blur-sm p-5 rounded-xl border border-black/[0.08] hover:border-[#5B2DFF]/30 transition-all duration-300">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 flex items-center justify-center bg-[#5B2DFF]/10 rounded-full">
                          <i className="ri-mail-line text-[#5B2DFF] text-sm" />
                        </div>
                        <span className="text-black/40 text-xs uppercase tracking-wider font-semibold">Email</span>
                      </div>
                      <a
                        href="mailto:brandstackagency@gmail.com"
                        className="text-[#0D0D0D] font-semibold hover:text-[#5B2DFF] transition-colors cursor-pointer text-sm"
                      >
                        brandstackagency@gmail.com
                      </a>
                    </div>

                    <div className="bg-white/60 backdrop-blur-sm p-5 rounded-xl border border-black/[0.08]">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 flex items-center justify-center bg-[#5B2DFF]/10 rounded-full">
                          <i className="ri-time-line text-[#5B2DFF] text-sm" />
                        </div>
                        <span className="text-black/40 text-xs uppercase tracking-wider font-semibold">Response Time</span>
                      </div>
                      <p className="text-white/70 font-semibold text-sm">Within 24 hours</p>
                    </div>

                    <div className="bg-white/60 backdrop-blur-sm p-5 rounded-xl border border-black/[0.08]">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 flex items-center justify-center bg-[#5B2DFF]/10 rounded-full">
                          <i className="ri-map-pin-line text-[#5B2DFF] text-sm" />
                        </div>
                        <span className="text-black/40 text-xs uppercase tracking-wider font-semibold">Location</span>
                      </div>
                      <p className="text-white/70 font-semibold text-sm">Lagos, Nigeria</p>
                      <p className="text-white/30 text-xs mt-1">Serving brands across Africa</p>
                    </div>
                  </div>
                </div>
              </ScrollReveal>
            </div>

            {/* Right Column - Form */}
            <ScrollReveal direction="right" delay={100}>
              <form
                id="discovery-call-form"
                onSubmit={handleSubmit}
                className="bg-white/[0.04] backdrop-blur-sm p-8 lg:p-10 rounded-2xl border border-white/[0.08]"
                data-readdy-form
              >
                <h3 className="font-editorial font-bold text-white text-2xl mb-8">
                  Book Your Discovery Call
                </h3>

                {/* Form Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
                  {/* Full Name */}
                  <div>
                    <label htmlFor="name" className="block text-sm font-semibold text-white/40 mb-2">
                      Full Name <span className="text-[#5B2DFF]">*</span>
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-white/[0.05] border border-white/[0.08] rounded-lg text-white placeholder-white/20 focus:outline-none focus:border-[#7C3AED]/50 focus:ring-2 focus:ring-[#7C3AED]/20 transition-all text-sm"
                      placeholder="John Doe"
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label htmlFor="email" className="block text-sm font-semibold text-white/40 mb-2">
                      Email Address <span className="text-[#5B2DFF]">*</span>
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-white/[0.05] border border-white/[0.08] rounded-lg text-white placeholder-white/20 focus:outline-none focus:border-[#7C3AED]/50 focus:ring-2 focus:ring-[#7C3AED]/20 transition-all text-sm"
                      placeholder="john@company.com"
                    />
                  </div>

                  {/* Company Name */}
                  <div>
                    <label htmlFor="company" className="block text-sm font-semibold text-white/40 mb-2">
                      Company Name <span className="text-[#5B2DFF]">*</span>
                    </label>
                    <input
                      type="text"
                      id="company"
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-white/[0.05] border border-white/[0.08] rounded-lg text-white placeholder-white/20 focus:outline-none focus:border-[#7C3AED]/50 focus:ring-2 focus:ring-[#7C3AED]/20 transition-all text-sm"
                      placeholder="Your Company"
                    />
                  </div>

                  {/* Phone */}
                  <div>
                    <label htmlFor="phone" className="block text-sm font-semibold text-white/40 mb-2">
                      Phone Number <span className="text-[#5B2DFF]">*</span>
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-white/[0.05] border border-white/[0.08] rounded-lg text-white placeholder-white/20 focus:outline-none focus:border-[#7C3AED]/50 focus:ring-2 focus:ring-[#7C3AED]/20 transition-all text-sm"
                      placeholder="+234 800 000 0000"
                    />
                  </div>

                  {/* Revenue Stage */}
                  <div>
                    <label htmlFor="revenueStage" className="block text-sm font-semibold text-white/40 mb-2">
                      Revenue Stage <span className="text-[#5B2DFF]">*</span>
                    </label>
                    <select
                      id="revenueStage"
                      name="revenueStage"
                      value={formData.revenueStage}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-[#0C0B11] border border-white/[0.08] rounded-lg text-white/70 focus:outline-none focus:border-[#7C3AED]/50 focus:ring-2 focus:ring-[#7C3AED]/20 transition-all cursor-pointer text-sm"
                    >
                      <option value="">Select revenue stage</option>
                      <option value="Pre-revenue">Pre-revenue</option>
                      <option value="$0 - $100K">$0 - $100K</option>
                      <option value="$100K - $500K">$100K - $500K</option>
                      <option value="$500K - $1M">$500K - $1M</option>
                      <option value="$1M - $5M">$1M - $5M</option>
                      <option value="$5M - $10M">$5M - $10M</option>
                      <option value="$10M+">$10M+</option>
                    </select>
                  </div>

                  {/* Service Interest */}
                  <div>
                    <label htmlFor="serviceInterest" className="block text-sm font-semibold text-white/40 mb-2">
                      Service Interest <span className="text-[#5B2DFF]">*</span>
                    </label>
                    <select
                      id="serviceInterest"
                      name="serviceInterest"
                      value={formData.serviceInterest}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-[#0C0B11] border border-white/[0.08] rounded-lg text-white/70 focus:outline-none focus:border-[#7C3AED]/50 focus:ring-2 focus:ring-[#7C3AED]/20 transition-all cursor-pointer text-sm"
                    >
                      <option value="">Select service</option>
                      <option value="GTM Launchpad">GTM Launchpad</option>
                      <option value="SEG Framework">SEG Framework</option>
                      <option value="Performance Marketing">Performance Marketing</option>
                      <option value="Marketing Audit">Marketing Audit</option>
                      <option value="Not Sure - Need Consultation">Not Sure - Need Consultation</option>
                    </select>
                  </div>
                </div>

                {/* Budget Range - Full Width */}
                <div className="mb-5">
                  <label htmlFor="budgetRange" className="block text-sm font-semibold text-white/40 mb-2">
                    Budget Range <span className="text-[#5B2DFF]">*</span>
                  </label>
                  <select
                    id="budgetRange"
                    name="budgetRange"
                    value={formData.budgetRange}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-[#0C0B11] border border-white/[0.08] rounded-lg text-white/70 focus:outline-none focus:border-[#7C3AED]/50 focus:ring-2 focus:ring-[#7C3AED]/20 transition-all cursor-pointer text-sm"
                  >
                    <option value="">Select budget range</option>
                    <option value="Under $5,000">Under $5,000</option>
                    <option value="$5,000 - $10,000">$5,000 - $10,000</option>
                    <option value="$10,000 - $25,000">$10,000 - $25,000</option>
                    <option value="$25,000 - $50,000">$25,000 - $50,000</option>
                    <option value="$50,000 - $100,000">$50,000 - $100,000</option>
                    <option value="$100,000+">$100,000+</option>
                  </select>
                </div>

                {/* Message */}
                <div className="mb-6">
                  <label htmlFor="message" className="block text-sm font-semibold text-white/40 mb-2">
                    Tell Us About Your Goals <span className="text-[#5B2DFF]">*</span>
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    maxLength={500}
                    rows={5}
                    className="w-full px-4 py-3 bg-white/[0.05] border border-white/[0.08] rounded-lg text-white placeholder-white/20 focus:outline-none focus:border-[#7C3AED]/50 focus:ring-2 focus:ring-[#7C3AED]/20 transition-all resize-none text-sm"
                    placeholder="What challenges are you facing? What are your growth goals?"
                  />
                  <div className="text-right text-xs text-white/25 mt-2">
                    {formData.message.length}/500 characters
                  </div>
                </div>

                {/* Status Messages */}
                {status === 'success' && (
                  <div className="mb-6 p-4 bg-green-500/10 border border-green-500/30 rounded-lg flex items-center gap-3">
                    <i className="ri-checkbox-circle-line text-2xl text-green-600"></i>
                    <div>
                      <p className="text-green-700 font-semibold text-sm">Request Submitted Successfully!</p>
                      <p className="text-green-600 text-xs mt-0.5">We'll get back to you within 24 hours.</p>
                    </div>
                  </div>
                )}

                {status === 'error' && (
                  <div className="mb-6 p-4 bg-red-500/10 border border-red-500/30 rounded-lg flex items-center gap-3">
                    <i className="ri-error-warning-line text-2xl text-red-600"></i>
                    <div>
                      <p className="text-red-700 font-semibold text-sm">Submission Failed</p>
                      <p className="text-red-600 text-xs mt-0.5">{errorMessage}</p>
                    </div>
                  </div>
                )}

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={status === 'submitting'}
                  className="w-full px-8 py-4 text-white font-semibold rounded-full transition-all duration-300 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap cursor-pointer text-base"
                  style={{
                    background: 'linear-gradient(135deg, #6b21a8 0%, #7C3AED 60%, #a855f7 100%)',
                    boxShadow: '0 4px 24px rgba(124,58,237,0.35)',
                  }}
                >
                  {status === 'submitting' ? (
                    <span className="flex items-center justify-center gap-2">
                      <i className="ri-loader-4-line animate-spin"></i>
                      Submitting Request...
                    </span>
                  ) : (
                    <span className="flex items-center justify-center gap-2">
                      Book Discovery Call
                      <i className="ri-arrow-right-line"></i>
                    </span>
                  )}
                </button>
              </form>
            </ScrollReveal>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
