import { useEffect, useState } from 'react';
import PortalProvider, { usePortalData } from '@/hooks/usePortalData';
import { supabase } from '@/lib/supabase';

interface Report {
  id: string;
  title: string;
  type: string;
  status: string;
  period_start: string;
  period_end: string;
  highlights: any;
  metrics: any;
  published_at: string;
  created_at: string;
}

function ReportsContent() {
  const { portal, logout } = usePortalData();
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState<'all' | 'weekly' | 'monthly'>('all');
  const [toast, setToast] = useState<{ type: string; msg: string } | null>(null);
  const [emailingId, setEmailingId] = useState<string | null>(null);

  useEffect(() => {
    if (!portal) return;
    let cancelled = false;

    supabase.from('portal_reports')
      .select('*')
      .eq('portal_id', portal.id)
      .order('created_at', { ascending: false })
      .then(({ data, error }) => {
        if (cancelled) return;
        if (!error) setReports(data || []);
        setLoading(false);
      });

    return () => { cancelled = true; };
  }, [portal]);

  const flash = (type: string, msg: string) => {
    setToast({ type, msg });
    setTimeout(() => setToast(null), 3000);
  };

  const emailReport = async (r: Report) => {
    if (!portal) return;
    setEmailingId(r.id);

    const h = r.highlights && Array.isArray(r.highlights) ? r.highlights.map((hl: string) => `<li style="padding:6px 0;font-size:13px;border-bottom:1px solid #f0f0f0;">${hl}</li>`).join('') : '';
    const m = r.metrics && typeof r.metrics === 'object' ? Object.entries(r.metrics).map(([k, v]: [string, any]) => `<div style="display:inline-block;background:#f5f3ff;padding:8px 14px;border-radius:8px;margin:4px;font-size:13px;"><strong>${k}:</strong> ${v}</div>`).join('') : '';
    const reportHtml = `
      <div style="margin-bottom:20px;">
        <p style="color:#666;font-size:13px;margin:0 0 8px;">${r.type.toUpperCase()} Report · ${r.period_start || 'N/A'} to ${r.period_end || 'N/A'} · Published ${new Date(r.published_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
      </div>
      ${m ? `<div style="margin-bottom:20px;"><h3 style="font-size:15px;border-left:3px solid #7C3AED;padding-left:10px;margin:0 0 12px;">Metrics</h3>${m}</div>` : ''}
      ${h ? `<div style="margin-bottom:20px;"><h3 style="font-size:15px;border-left:3px solid #7C3AED;padding-left:10px;margin:0 0 12px;">Highlights</h3><ul style="padding:0;list-style:none;">${h}</ul></div>` : ''}
    `;

    try {
      await fetch(
        `${import.meta.env.VITE_PUBLIC_SUPABASE_URL}/functions/v1/portal-notifications`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'apikey': import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY },
          body: JSON.stringify({
            portal_id: portal.id,
            type: 'report_emailed',
            title: r.title,
            message: `Here's your ${r.type} report for ${portal.brand_name}.`,
            channel: 'email',
            report_html: reportHtml,
          }),
        }
      );
      flash('success', `Report emailed to ${portal.recipient_email || 'your email'}!`);
    } catch {
      flash('error', 'Failed to send email');
    }
    setEmailingId(null);
  };

  const navigateTo = (path: string) => {
    const basePath = (window as any).__BASE_PATH__ || '';
    window.location.href = `${basePath}${path}`;
  };

  const downloadReport = (r: Report) => {
    const h = r.highlights && Array.isArray(r.highlights) ? r.highlights.map((hl: string) => `<li>${hl}</li>`).join('') : '';
    const m = r.metrics && typeof r.metrics === 'object' ? Object.entries(r.metrics).map(([k, v]: [string, any]) => `<div class="metric"><strong>${k}:</strong> ${v}</div>`).join('') : '';
    const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${r.title}</title><style>body{font-family:-apple-system,BlinkMacSystemFont,sans-serif;max-width:800px;margin:60px auto;padding:0 24px;color:#1a1a1a;background:#fff}h1{font-size:28px;margin-bottom:4px}.meta{color:#666;font-size:13px;margin-bottom:32px;border-bottom:1px solid #e5e5e5;padding-bottom:16px}.section{margin:28px 0}.section h3{font-size:16px;border-left:4px solid #7C3AED;padding-left:12px;margin-bottom:12px}.metric{display:inline-block;background:#f5f3ff;padding:8px 16px;border-radius:8px;margin:4px;font-size:14px}li{padding:8px 0;border-bottom:1px solid #f0f0f0;font-size:14px;line-height:1.5}.footer{margin-top:40px;color:#999;font-size:11px;border-top:1px solid #e5e5e5;padding-top:12px}</style></head><body><h1>${r.title}</h1><p class="meta">${r.type.toUpperCase()} Report &middot; ${r.period_start || 'N/A'} to ${r.period_end || 'N/A'} &middot; Published ${new Date(r.published_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>${m ? `<div class="section"><h3>Metrics</h3>${m}</div>` : ''}${h ? `<div class="section"><h3>Highlights</h3><ul>${h}</ul></div>` : ''}<p class="footer">Generated by Brandstack Portal &middot; ${new Date().toISOString().split('T')[0]}</p></body></html>`;
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${r.title.replace(/\s+/g, '_')}_${r.type}_report.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const filtered = activeFilter === 'all' ? reports : reports.filter(r => r.type === activeFilter);

  const typeColors: Record<string, string> = {
    weekly: 'bg-sky-500/10 text-sky-400',
    monthly: 'bg-emerald-500/10 text-emerald-400',
    quarterly: 'bg-[#7C3AED]/10 text-[#a855f7]',
    custom: 'bg-white/5 text-white/30',
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0C0B11] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#7C3AED] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0C0B11]">
      {/* Toast */}
      {toast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[100] animate-in fade-in slide-in-from-top-2">
          <div className={`px-5 py-3 rounded-xl text-xs font-semibold ${toast.type === 'success' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-red-500/20 text-red-400 border border-red-500/30'} backdrop-blur-md`}>
            {toast.msg}
          </div>
        </div>
      )}

      <header className="sticky top-0 z-50 bg-[#0C0B11]/80 backdrop-blur-xl border-b border-white/[0.04]">
        <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-16 h-16 flex items-center justify-between">
          <button onClick={() => navigateTo('/portal/dashboard')} className="flex items-center gap-2 text-white/40 hover:text-white/70 transition-colors cursor-pointer">
            <i className="ri-arrow-left-line" />
            <span className="text-xs font-semibold">Dashboard</span>
          </button>
          <div className="flex items-center gap-3">
            <span className="text-white/20 text-xs font-semibold">{portal?.brand_name}</span>
            <button onClick={logout} className="px-3 py-1.5 text-white/25 text-xs font-semibold rounded-lg hover:text-red-400 hover:bg-red-500/5 transition-all whitespace-nowrap cursor-pointer">
              <i className="ri-logout-box-line" />
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-16 py-8 md:py-12">
        <div className="mb-8">
          <h1 className="font-editorial font-black text-white text-3xl md:text-4xl mb-2">Reports</h1>
          <p className="text-white/35 text-sm">Performance summaries and progress snapshots for {portal?.brand_name}</p>
        </div>

        {/* Filter */}
        <div className="flex items-center gap-2 mb-8">
          {(['all', 'weekly', 'monthly'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`px-4 py-2 text-xs font-semibold rounded-full capitalize transition-all whitespace-nowrap cursor-pointer ${activeFilter === f ? 'bg-[#7C3AED] text-white' : 'text-white/30 bg-white/[0.02] border border-white/[0.04] hover:text-white/60'}`}
            >
              {f}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-white/[0.03] border border-white/[0.05] flex items-center justify-center">
              <i className="ri-file-chart-line text-2xl text-white/15" />
            </div>
            <p className="text-white/30 text-sm">No reports yet</p>
            <p className="text-white/15 text-xs mt-1">Reports will appear here once your agency publishes them</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((report) => (
              <div key={report.id} className="bg-white/[0.02] border border-white/[0.05] rounded-2xl p-5 hover:border-[#7C3AED]/20 transition-all duration-300">
                <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-[10px] font-semibold uppercase px-2 py-0.5 rounded-md ${typeColors[report.type] || typeColors.custom}`}>
                        {report.type}
                      </span>
                      {report.status === 'published' && (
                        <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md">Published</span>
                      )}
                      {report.status === 'draft' && (
                        <span className="text-[10px] font-semibold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md">Draft</span>
                      )}
                    </div>
                    <h3 className="font-editorial font-bold text-white text-lg">{report.title}</h3>
                  </div>
                  <span className="text-white/20 text-xs">
                    {report.period_start && new Date(report.period_start).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    {report.period_end && ` - ${new Date(report.period_end).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => downloadReport(report)}
                      className="px-3 py-1.5 text-[11px] font-semibold text-[#a855f7] bg-[#7C3AED]/10 border border-[#7C3AED]/20 rounded-lg hover:bg-[#7C3AED]/20 transition-all whitespace-nowrap cursor-pointer"
                    >
                      <i className="ri-download-line mr-1" />Download
                    </button>
                    <button
                      onClick={() => emailReport(report)}
                      disabled={emailingId === report.id}
                      className="px-3 py-1.5 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-lg hover:bg-emerald-500/20 disabled:opacity-50 transition-all whitespace-nowrap cursor-pointer"
                    >
                      {emailingId === report.id ? (
                        <><div className="w-3 h-3 border-2 border-emerald-400/30 border-t-emerald-400 rounded-full animate-spin mr-1" />Sending...</>
                      ) : (
                        <><i className="ri-mail-send-line mr-1" />Email</>
                      )}
                    </button>
                  </div>
                </div>

                {report.metrics && typeof report.metrics === 'object' && Object.keys(report.metrics).length > 0 && (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                    {Object.entries(report.metrics).map(([key, value]: [string, any]) => (
                      <div key={key} className="bg-white/[0.02] border border-white/[0.04] rounded-xl p-3">
                        <p className="text-white/25 text-[10px] font-semibold uppercase tracking-wider mb-1">{key}</p>
                        <p className="font-editorial font-bold text-white text-lg">{value}</p>
                      </div>
                    ))}
                  </div>
                )}

                {report.highlights && Array.isArray(report.highlights) && report.highlights.length > 0 && (
                  <div className="space-y-1.5">
                    {report.highlights.map((h: string, i: number) => (
                      <div key={i} className="flex items-start gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-[#7C3AED] mt-1.5 flex-shrink-0" />
                        <p className="text-white/40 text-xs leading-relaxed">{h}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function Reports() {
  return (
    <PortalProvider>
      <ReportsContent />
    </PortalProvider>
  );
}