import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';

interface PortalInfo {
  id: string;
  client_name: string;
  brand_name: string;
  slug: string;
  staff_label: string;
  client_label: string;
  accent_color: string | null;
  logo_url: string | null;
}

export default function PortalEntry() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [portal, setPortal] = useState<PortalInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedRole, setSelectedRole] = useState<string | null>(null);

  useEffect(() => {
    const fetchPortal = async () => {
      if (!slug) {
        setError('No portal specified.');
        setLoading(false);
        return;
      }

      try {
        const { data, error: dbErr } = await supabase
          .from('client_portals')
          .select('id, client_name, brand_name, slug, staff_label, client_label, accent_color, logo_url')
          .eq('slug', slug)
          .eq('status', 'active')
          .maybeSingle();

        if (dbErr || !data) {
          setError('Portal not found. Please check your link and try again.');
          setLoading(false);
          return;
        }

        setPortal(data);
        setLoading(false);
      } catch {
        setError('Something went wrong. Please try again.');
        setLoading(false);
      }
    };

    fetchPortal();
  }, [slug]);

  const handleRoleSelect = (role: 'staff' | 'client') => {
    if (!portal) return;
    setSelectedRole(role);

    sessionStorage.setItem('portal_id', portal.id);
    sessionStorage.setItem('portal_client_name', portal.client_name);
    sessionStorage.setItem('portal_brand_name', portal.brand_name);
    sessionStorage.setItem('portal_slug', portal.slug);
    sessionStorage.setItem('portal_role', role);

    // Small delay for the click animation before navigating
    setTimeout(() => {
      const basePath = (window as any).__BASE_PATH__ || '';
      window.location.href = `${basePath}/portal/dashboard`;
    }, 400);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0C0B11] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-8 h-8 border-2 border-white/15 border-t-white/60 rounded-full animate-spin" />
          <p className="text-white/20 text-sm">Loading portal...</p>
        </div>
      </div>
    );
  }

  if (error || !portal) {
    return (
      <div className="min-h-screen bg-[#0C0B11] flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-white/[0.03] border border-white/[0.06] flex items-center justify-center">
            <i className="ri-error-warning-line text-white/20 text-2xl" />
          </div>
          <h1 className="text-white text-xl font-bold mb-2">Portal Not Found</h1>
          <p className="text-white/30 text-sm mb-6">{error}</p>
          <a
            href="/portal"
            className="inline-flex items-center gap-2 px-6 py-3 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white/50 text-sm hover:text-white/80 hover:bg-white/[0.06] transition-all whitespace-nowrap"
          >
            <i className="ri-arrow-left-line" />
            Try keyword access
          </a>
        </div>
      </div>
    );
  }

  const accentStyle = portal.accent_color
    ? { backgroundColor: portal.accent_color, borderColor: portal.accent_color }
    : {};

  return (
    <div className="min-h-screen bg-[#0C0B11] flex items-center justify-center px-4 relative overflow-hidden">
      {/* Ambient glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full" style={{ background: 'radial-gradient(circle, rgba(124,58,237,0.06) 0%, transparent 70%)' }} />

      <div className="relative z-10 w-full max-w-lg">
        {/* Portal branding */}
        <div className="text-center mb-10">
          {portal.logo_url ? (
            <img
              src={portal.logo_url}
              alt={portal.client_name}
              className="h-12 mx-auto mb-6 object-contain"
            />
          ) : (
            <div className="w-14 h-14 mx-auto mb-6 rounded-2xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #6b21a8 0%, #7C3AED 100%)' }}>
              <i className="ri-stack-line text-white text-xl" />
            </div>
          )}
          <h1 className="text-white text-2xl font-bold mb-2">
            {portal.brand_name} <span className="text-white/15 font-normal mx-1">&times;</span> {portal.client_name}
          </h1>
          <p className="text-white/25 text-sm">Select your role to continue</p>
        </div>

        {/* Role selector */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Staff button */}
          <button
            onClick={() => handleRoleSelect('staff')}
            disabled={selectedRole !== null}
            className={`group relative p-6 rounded-2xl border transition-all duration-300 cursor-pointer flex flex-col items-center gap-3 ${
              selectedRole === 'staff'
                ? 'border-white/20 bg-white/[0.06] scale-[0.98]'
                : 'border-white/[0.06] bg-white/[0.02] hover:bg-white/[0.05] hover:border-white/[0.12]'
            } ${selectedRole !== null && selectedRole !== 'staff' ? 'opacity-40' : ''}`}
          >
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all duration-300 ${
              selectedRole === 'staff' ? 'bg-[#7C3AED]' : 'bg-white/[0.04] group-hover:bg-white/[0.08]'
            }`}>
              <i className={`text-xl ${selectedRole === 'staff' ? 'ri-building-4-line text-white' : 'ri-building-4-line text-white/30 group-hover:text-white/50'}`} />
            </div>
            <div className="text-center">
              <p className={`text-sm font-bold transition-colors ${
                selectedRole === 'staff' ? 'text-white' : 'text-white/50 group-hover:text-white/70'
              }`}>
                {portal.staff_label || 'BrandStack Staff'}
              </p>
              <p className="text-white/15 text-[11px] mt-1">Agency &amp; team members</p>
            </div>
            {selectedRole === 'staff' && (
              <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-[#7C3AED] flex items-center justify-center">
                <i className="ri-check-line text-white text-[10px]" />
              </div>
            )}
          </button>

          {/* Client button */}
          <button
            onClick={() => handleRoleSelect('client')}
            disabled={selectedRole !== null}
            className={`group relative p-6 rounded-2xl border transition-all duration-300 cursor-pointer flex flex-col items-center gap-3 ${
              selectedRole === 'client'
                ? 'border-white/20 bg-white/[0.06] scale-[0.98]'
                : 'border-white/[0.06] bg-white/[0.02] hover:bg-white/[0.05] hover:border-white/[0.12]'
            } ${selectedRole !== null && selectedRole !== 'client' ? 'opacity-40' : ''}`}
          >
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all duration-300 ${
              selectedRole === 'client' ? 'bg-emerald-600' : 'bg-white/[0.04] group-hover:bg-white/[0.08]'
            }`}>
              <i className={`text-xl ${selectedRole === 'client' ? 'ri-team-line text-white' : 'ri-team-line text-white/30 group-hover:text-white/50'}`} />
            </div>
            <div className="text-center">
              <p className={`text-sm font-bold transition-colors ${
                selectedRole === 'client' ? 'text-white' : 'text-white/50 group-hover:text-white/70'
              }`}>
                {portal.client_label || 'Client Staff'}
              </p>
              <p className="text-white/15 text-[11px] mt-1">{portal.client_name} team</p>
            </div>
            {selectedRole === 'client' && (
              <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-emerald-600 flex items-center justify-center">
                <i className="ri-check-line text-white text-[10px]" />
              </div>
            )}
          </button>
        </div>

        <p className="text-center text-white/10 text-[11px] mt-10">
          Having trouble? Contact your agency representative.
        </p>
      </div>
    </div>
  );
}