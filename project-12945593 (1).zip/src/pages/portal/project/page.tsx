import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import PortalProvider, { usePortalData } from '@/hooks/usePortalData';
import { supabase } from '@/lib/supabase';

interface Project {
  id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  category: string;
  start_date: string;
  end_date: string;
  deliverables: any;
  notes: string;
  progress: number;
  image_url?: string;
  flagged: boolean;
}
interface Task {
  id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  due_date: string;
  completed_at: string;
  flagged: boolean;
  sort_order: number;
}
interface Approval {
  id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  requested_at: string;
  responded_at: string;
}
interface Comment {
  id: string;
  author_name: string;
  content: string;
  is_admin: boolean;
  created_at: string;
}

function ProjectContent() {
  const { id: projectId } = useParams<{ id: string }>();
  const { portal, logout } = usePortalData();
  const [project, setProject] = useState<Project | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [approvals, setApprovals] = useState<Approval[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(true);
  const [commenting, setCommenting] = useState(false);
  const [toast, setToast] = useState<{ type: string; msg: string } | null>(null);

  // Add task state
  const [showAddTask, setShowAddTask] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState('medium');
  const [addingTask, setAddingTask] = useState(false);

  useEffect(() => {
    if (!portal || !projectId) return;
    let cancelled = false;

    const load = async () => {
      try {
        setLoading(true);
        const [projRes, taskRes, appRes, commRes] = await Promise.all([
          supabase.from('portal_projects').select('*').eq('id', projectId).eq('portal_id', portal.id).maybeSingle(),
          supabase.from('portal_tasks').select('*').eq('project_id', projectId).eq('portal_id', portal.id).order('sort_order', { ascending: true }).order('created_at', { ascending: true }),
          supabase.from('portal_approvals').select('*').eq('project_id', projectId).eq('portal_id', portal.id).order('requested_at', { ascending: false }),
          supabase.from('portal_comments').select('*').eq('project_id', projectId).eq('portal_id', portal.id).order('created_at', { ascending: true }),
        ]);

        if (cancelled) return;
        if (!projRes.error) setProject(projRes.data);
        if (!taskRes.error) setTasks(taskRes.data || []);
        if (!appRes.error) setApprovals(appRes.data || []);
        if (!commRes.error) setComments(commRes.data || []);
      } catch (e) {
        console.error('Project load error:', e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    load();
    return () => { cancelled = true; };
  }, [portal, projectId]);

  const flash = (type: string, msg: string) => {
    setToast({ type, msg });
    setTimeout(() => setToast(null), 3000);
  };

  const sendNotification = async (nType: string, nTitle: string, nMsg: string) => {
    if (!portal) return;
    try {
      await fetch(
        `${import.meta.env.VITE_PUBLIC_SUPABASE_URL}/functions/v1/portal-notifications`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'apikey': import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY },
          body: JSON.stringify({ portal_id: portal.id, type: nType, title: nTitle, message: nMsg, channel: 'email' }),
        }
      );
    } catch {
      // silent
    }
  };

  const addComment = async () => {
    if (!newComment.trim() || !portal || !projectId) return;
    setCommenting(true);
    await supabase.from('portal_comments').insert({
      portal_id: portal.id,
      project_id: projectId,
      author_name: portal.client_name,
      author_email: '',
      content: newComment.trim(),
      is_admin: false,
    });
    setNewComment('');
    setCommenting(false);
    const { data } = await supabase.from('portal_comments').select('*').eq('project_id', projectId).order('created_at', { ascending: true });
    if (data) setComments(data);
  };

  const addTask = async () => {
    if (!newTaskTitle.trim() || !portal || !projectId) return;
    setAddingTask(true);
    const maxSort = tasks.length > 0 ? Math.max(...tasks.map(t => t.sort_order || 0)) : 0;
    const { error } = await supabase.from('portal_tasks').insert({
      portal_id: portal.id,
      project_id: projectId,
      title: newTaskTitle.trim(),
      status: 'todo',
      priority: newTaskPriority,
      sort_order: maxSort + 1,
      flagged: false,
    });
    setAddingTask(false);
    if (error) { flash('error', 'Failed to add task'); return; }
    setNewTaskTitle('');
    setNewTaskPriority('medium');
    setShowAddTask(false);
    flash('success', 'Task added!');
    // Refresh
    const { data } = await supabase.from('portal_tasks').select('*').eq('project_id', projectId).order('sort_order', { ascending: true }).order('created_at', { ascending: true });
    if (data) setTasks(data);
  };

  const toggleFlag = async (taskId: string, current: boolean) => {
    await supabase.from('portal_tasks').update({ flagged: !current }).eq('id', taskId);
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, flagged: !current } : t));
    if (!current) {
      const task = tasks.find(t => t.id === taskId);
      if (task) {
        await sendNotification('task_flagged', `Task flagged: ${task.title}`, `${portal?.client_name} flagged the task "${task.title}" in project "${project?.title}".`);
      }
    }
    flash('success', current ? 'Flag removed' : 'Task flagged');
  };

  const changePriority = async (taskId: string, newPriority: string) => {
    await supabase.from('portal_tasks').update({ priority: newPriority }).eq('id', taskId);
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, priority: newPriority } : t));
    flash('success', `Priority set to ${newPriority}`);
  };

  const moveTask = async (taskId: string, direction: 'up' | 'down') => {
    const idx = tasks.findIndex(t => t.id === taskId);
    if (idx === -1) return;
    if (direction === 'up' && idx === 0) return;
    if (direction === 'down' && idx === tasks.length - 1) return;

    const otherIdx = direction === 'up' ? idx - 1 : idx + 1;
    const taskA = tasks[idx];
    const taskB = tasks[otherIdx];

    await Promise.all([
      supabase.from('portal_tasks').update({ sort_order: taskB.sort_order || 0 }).eq('id', taskA.id),
      supabase.from('portal_tasks').update({ sort_order: taskA.sort_order || 0 }).eq('id', taskB.id),
    ]);

    const updated = [...tasks];
    [updated[idx], updated[otherIdx]] = [updated[otherIdx], updated[idx]];
    setTasks(updated);
    flash('success', 'Task reordered');
  };

  const navigateTo = (path: string) => {
    const basePath = (window as any).__BASE_PATH__ || '';
    window.location.href = `${basePath}${path}`;
  };

  const statusColors: Record<string, { bg: string; text: string }> = {
    working_on: { bg: 'bg-emerald-500/10', text: 'text-emerald-400' },
    pending: { bg: 'bg-amber-500/10', text: 'text-amber-400' },
    upcoming: { bg: 'bg-sky-500/10', text: 'text-sky-400' },
    concluded: { bg: 'bg-white/5', text: 'text-white/30' },
  };

  const taskStatusColors: Record<string, string> = {
    todo: 'bg-white/5 text-white/30',
    in_progress: 'bg-sky-500/10 text-sky-400',
    review: 'bg-amber-500/10 text-amber-400',
    completed: 'bg-emerald-500/10 text-emerald-400 line-through',
  };

  const approvalStatusColors: Record<string, string> = {
    pending: 'bg-amber-500/10 text-amber-400',
    approved: 'bg-emerald-500/10 text-emerald-400',
    rejected: 'bg-red-500/10 text-red-400',
    changes_requested: 'bg-sky-500/10 text-sky-400',
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0C0B11] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#7C3AED] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-[#0C0B11] flex items-center justify-center">
        <div className="text-center">
          <p className="text-white/30 text-sm">Project not found</p>
          <button onClick={() => navigateTo('/portal/dashboard')} className="mt-4 text-[#a855f7] text-xs hover:underline cursor-pointer">Back to Dashboard</button>
        </div>
      </div>
    );
  }

  const sc = statusColors[project.status] || statusColors.upcoming;

  return (
    <div className="min-h-screen bg-[#0C0B11]">
      {/* Toast */}
      {toast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[100] animate-in fade-in slide-in-from-top-2">
          <div className={`px-5 py-3 rounded-xl text-xs font-semibold ${toast.type === 'success' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-red-500/20 text-red-400 border border-red-500/30'} backdrop-blur-md`}>
            {toast.msg}
          </div>
        </div>
      )}

      {/* Top bar */}
      <header className="sticky top-0 z-50 bg-[#0C0B11]/80 backdrop-blur-xl border-b border-white/[0.04]">
        <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-16 h-16 flex items-center justify-between">
          <button onClick={() => navigateTo('/portal/dashboard')} className="flex items-center gap-2 text-white/40 hover:text-white/70 transition-colors cursor-pointer">
            <i className="ri-arrow-left-line" />
            <span className="text-xs font-semibold">Dashboard</span>
          </button>
          <div className="flex items-center gap-3">
            <span className="text-white/20 text-xs font-semibold">{portal?.brand_name}</span>
            <button onClick={logout} className="px-3 py-1.5 text-white/25 text-xs font-semibold rounded-lg hover:text-red-400 hover:bg-red-500/5 transition-all whitespace-nowrap cursor-pointer">
              <i className="ri-logout-box-line" />
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-16 py-8 md:py-12">
        {/* Project header */}
        <div className="mb-10">
          <div className="flex flex-wrap items-center gap-3 mb-4">
            <span className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-1 rounded-md ${sc.bg} ${sc.text}`}>
              {project.status.replace('_', ' ')}
            </span>
            <span className="text-white/15 text-[10px] font-semibold uppercase tracking-wider">{project.category}</span>
            {project.priority === 'urgent' && (
              <span className="text-[10px] font-semibold uppercase text-red-400 bg-red-500/10 px-2 py-1 rounded-md">Urgent</span>
            )}
          </div>
          <div className="flex items-center gap-3">
            <h1 className="font-editorial font-black text-white text-3xl md:text-4xl mb-2">{project.title}</h1>
            <button
              onClick={async () => {
                await supabase.from('portal_projects').update({ flagged: !project.flagged }).eq('id', project.id);
                setProject({ ...project, flagged: !project.flagged });
                if (!project.flagged) {
                  await sendNotification('project_flagged', `Project flagged: ${project.title}`, `${portal?.client_name} flagged the project "${project.title}".`);
                }
              }}
              className={`p-1.5 rounded-lg transition-all cursor-pointer ${project.flagged ? 'text-amber-400 bg-amber-500/10' : 'text-white/15 hover:text-amber-400 hover:bg-amber-500/10'}`}
              title={project.flagged ? 'Unflag' : 'Flag this project'}
            >
              <i className={`text-lg ${project.flagged ? 'ri-flag-fill' : 'ri-flag-line'}`} />
            </button>
          </div>
          <p className="text-white/40 text-sm leading-relaxed max-w-2xl">{project.description}</p>

          {/* Progress bar */}
          <div className="mt-6 max-w-md">
            <div className="flex items-center justify-between mb-2">
              <span className="text-white/30 text-xs font-semibold">Progress</span>
              <span className="text-white/50 text-xs font-bold">{project.progress || 0}%</span>
            </div>
            <div className="h-2 bg-white/[0.05] rounded-full overflow-hidden">
              <div className="h-full rounded-full transition-all duration-700" style={{ width: `${project.progress || 0}%`, background: 'linear-gradient(90deg, #7C3AED, #a855f7)' }} />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left: Tasks + Approvals */}
          <div className="lg:col-span-2 space-y-8">
            {/* Tasks */}
            <section>
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-editorial font-bold text-white text-lg flex items-center gap-2">
                  <i className="ri-task-line text-[#a855f7]" /> Tasks
                </h2>
                <button
                  onClick={() => setShowAddTask(true)}
                  className="px-3 py-1.5 text-xs font-semibold text-[#a855f7] bg-[#7C3AED]/10 border border-[#7C3AED]/20 rounded-lg hover:bg-[#7C3AED]/20 transition-all whitespace-nowrap cursor-pointer"
                >
                  <i className="ri-add-line mr-1" />Add Task
                </button>
              </div>

              {/* Add Task inline form */}
              {showAddTask && (
                <div className="bg-white/[0.03] border border-[#7C3AED]/20 rounded-2xl p-4 mb-3 animate-in fade-in slide-in-from-top-2">
                  <div className="flex flex-col sm:flex-row gap-3">
                    <input
                      type="text"
                      value={newTaskTitle}
                      onChange={(e) => setNewTaskTitle(e.target.value)}
                      placeholder="What needs to be done?"
                      autoFocus
                      onKeyDown={(e) => { if (e.key === 'Enter') addTask(); }}
                      className="flex-1 px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-sm placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50 transition-colors"
                    />
                    <select
                      value={newTaskPriority}
                      onChange={(e) => setNewTaskPriority(e.target.value)}
                      className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white/50 text-sm focus:outline-none focus:border-[#7C3AED]/50 cursor-pointer"
                    >
                      <option value="low">Low</option>
                      <option value="medium">Medium</option>
                      <option value="high">High</option>
                      <option value="urgent">Urgent</option>
                    </select>
                    <div className="flex items-center gap-2">
                      <button onClick={addTask} disabled={addingTask || !newTaskTitle.trim()} className="px-4 py-2 text-xs font-semibold text-white bg-[#7C3AED] rounded-xl hover:bg-[#6b21a8] disabled:opacity-30 transition-all whitespace-nowrap cursor-pointer">
                        {addingTask ? 'Adding...' : 'Add'}
                      </button>
                      <button onClick={() => { setShowAddTask(false); setNewTaskTitle(''); }} className="px-3 py-2 text-xs text-white/30 hover:text-white/60 transition-all whitespace-nowrap cursor-pointer">
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {tasks.length === 0 && !showAddTask ? (
                <p className="text-white/20 text-sm py-6">No tasks yet — click "Add Task" to create one</p>
              ) : (
                <div className="space-y-2">
                  {tasks.map((task, idx) => (
                    <div key={task.id} className="flex items-center gap-3 bg-white/[0.02] border border-white/[0.05] rounded-xl px-4 py-3 group hover:border-white/[0.08] transition-all">
                      {/* Reorder */}
                      <div className="flex flex-col gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => moveTask(task.id, 'up')} disabled={idx === 0} className="w-4 h-4 flex items-center justify-center text-white/20 hover:text-white/60 disabled:opacity-20 transition-colors cursor-pointer">
                          <i className="ri-arrow-up-s-line text-[10px]" />
                        </button>
                        <button onClick={() => moveTask(task.id, 'down')} disabled={idx === tasks.length - 1} className="w-4 h-4 flex items-center justify-center text-white/20 hover:text-white/60 disabled:opacity-20 transition-colors cursor-pointer">
                          <i className="ri-arrow-down-s-line text-[10px]" />
                        </button>
                      </div>

                      {/* Checkbox */}
                      <button
                        onClick={async () => {
                          const newStatus = task.status === 'completed' ? 'todo' : 'completed';
                          const updates: any = { status: newStatus };
                          if (newStatus === 'completed') updates.completed_at = new Date().toISOString();
                          await supabase.from('portal_tasks').update(updates).eq('id', task.id);
                          setTasks(prev => prev.map(t => t.id === task.id ? { ...t, status: newStatus } : t));
                          flash('success', newStatus === 'completed' ? 'Task completed!' : 'Task reopened');
                        }}
                        className={`w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 transition-all cursor-pointer ${task.status === 'completed' ? 'bg-emerald-500 border-emerald-500' : 'border-white/15 hover:border-[#7C3AED]/50'}`}
                      >
                        {task.status === 'completed' && <i className="ri-check-line text-white text-[10px]" />}
                      </button>

                      <div className="flex-1 min-w-0">
                        <p className={`text-sm ${task.status === 'completed' ? 'text-white/25 line-through' : 'text-white'}`}>{task.title}</p>
                        {task.due_date && (
                          <p className="text-white/20 text-[11px] mt-0.5">
                            Due {new Date(task.due_date + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                          </p>
                        )}
                      </div>

                      {/* Flag */}
                      <button
                        onClick={() => toggleFlag(task.id, task.flagged)}
                        className={`p-1.5 rounded-lg transition-all cursor-pointer ${task.flagged ? 'text-amber-400 bg-amber-500/10' : 'text-white/10 hover:text-amber-400 hover:bg-amber-500/10'}`}
                        title={task.flagged ? 'Unflag' : 'Flag this task'}
                      >
                        <i className={`text-xs ${task.flagged ? 'ri-flag-fill' : 'ri-flag-line'}`} />
                      </button>

                      {/* Priority */}
                      <select
                        value={task.priority}
                        onChange={(e) => changePriority(task.id, e.target.value)}
                        className="text-[10px] font-semibold px-2 py-1 rounded-md bg-white/[0.03] border border-white/[0.06] text-white/50 focus:outline-none cursor-pointer appearance-none"
                        style={{ minWidth: '70px' }}
                      >
                        <option value="urgent">Urgent</option>
                        <option value="high">High</option>
                        <option value="medium">Medium</option>
                        <option value="low">Low</option>
                      </select>

                      <span className={`text-[10px] font-semibold px-2 py-1 rounded-md ${taskStatusColors[task.status] || ''}`}>
                        {task.status.replace('_', ' ')}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* Approvals */}
            <section>
              <h2 className="font-editorial font-bold text-white text-lg mb-4 flex items-center gap-2">
                <i className="ri-check-double-line text-[#a855f7]" /> Approvals
              </h2>
              {approvals.length === 0 ? (
                <p className="text-white/20 text-sm py-6">No approvals for this project</p>
              ) : (
                <div className="space-y-3">
                  {approvals.map((approval) => (
                    <div key={approval.id} className="bg-white/[0.02] border border-white/[0.05] rounded-xl p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-editorial font-bold text-white text-sm">{approval.title}</h3>
                        <span className={`text-[10px] font-semibold px-2 py-1 rounded-md ${approvalStatusColors[approval.status]}`}>
                          {approval.status.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-white/35 text-xs mb-3">{approval.description}</p>
                      {approval.status === 'pending' && (
                        <div className="flex items-center gap-2">
                          <button onClick={async () => {
                            await supabase.from('portal_approvals').update({ status: 'approved', responded_at: new Date().toISOString() }).eq('id', approval.id);
                            window.location.reload();
                          }} className="px-3 py-1.5 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-lg hover:bg-emerald-500/20 transition-all whitespace-nowrap cursor-pointer">
                            Approve
                          </button>
                          <button onClick={async () => {
                            await supabase.from('portal_approvals').update({ status: 'changes_requested', responded_at: new Date().toISOString() }).eq('id', approval.id);
                            window.location.reload();
                          }} className="px-3 py-1.5 text-[11px] font-semibold text-amber-400 bg-amber-500/10 border border-amber-500/20 rounded-lg hover:bg-amber-500/20 transition-all whitespace-nowrap cursor-pointer">
                            Changes
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </section>
          </div>

          {/* Right: Comments */}
          <div>
            <h2 className="font-editorial font-bold text-white text-lg mb-4 flex items-center gap-2">
              <i className="ri-chat-3-line text-[#a855f7]" /> Discussion
            </h2>
            <div className="bg-white/[0.02] border border-white/[0.05] rounded-2xl p-5">
              <div className="space-y-4 mb-4 max-h-[400px] overflow-y-auto">
                {comments.length === 0 ? (
                  <p className="text-white/20 text-xs text-center py-8">No comments yet. Start the conversation!</p>
                ) : (
                  comments.map((comment) => (
                    <div key={comment.id} className="flex items-start gap-3">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 ${comment.is_admin ? 'bg-[#7C3AED]/20' : 'bg-white/[0.04]'}`}>
                        <span className={`text-[10px] font-bold ${comment.is_admin ? 'text-[#a855f7]' : 'text-white/40'}`}>
                          {comment.author_name.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <span className="text-white/60 text-xs font-semibold">{comment.author_name}</span>
                          {comment.is_admin && <span className="text-[9px] font-semibold text-[#a855f7] bg-[#7C3AED]/10 px-1.5 py-0.5 rounded-md">AGENCY</span>}
                          <span className="text-white/15 text-[10px]">{new Date(comment.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                        </div>
                        <p className="text-white/40 text-xs leading-relaxed">{comment.content}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') addComment(); }}
                  placeholder="Add a comment..."
                  className="flex-1 px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-xs placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50 transition-colors"
                />
                <button
                  onClick={addComment}
                  disabled={commenting || !newComment.trim()}
                  className="px-4 py-2 text-xs font-semibold text-white rounded-xl bg-[#7C3AED] hover:bg-[#6b21a8] disabled:opacity-30 transition-all whitespace-nowrap cursor-pointer"
                >
                  Send
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ProjectDetail() {
  return (
    <PortalProvider>
      <ProjectContent />
    </PortalProvider>
  );
}