import { useEffect, useState } from 'react';
import PortalProvider, { usePortalData } from '@/hooks/usePortalData';
import { supabase } from '@/lib/supabase';

interface ProjectSummary {
  id: string;
  title: string;
  status: string;
  priority: string;
  progress: number;
  category: string;
  image_url?: string;
  flagged: boolean;
}
interface ApprovalItem {
  id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  project_id?: string;
  requested_at: string;
}
interface TaskItem {
  id: string;
  title: string;
  status: string;
  priority: string;
  due_date: string;
  project_id?: string;
  flagged: boolean;
  sort_order: number;
}
interface AgendaItem {
  id: string;
  title: string;
  week_start: string;
  week_end: string;
  notes: string;
  action_items: string[];
  created_at: string;
}

function DashboardContent() {
  const { portal, logout } = usePortalData();
  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [approvals, setApprovals] = useState<ApprovalItem[]>([]);
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [agendas, setAgendas] = useState<AgendaItem[]>([]);
  const [driveUrl, setDriveUrl] = useState('');
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'tasks' | 'approvals'>('overview');
  const [toast, setToast] = useState<{ type: string; msg: string } | null>(null);
  const [showReportRequest, setShowReportRequest] = useState(false);
  const [reportType, setReportType] = useState('weekly');
  const [reportNote, setReportNote] = useState('');
  const [requestingReport, setRequestingReport] = useState(false);
  const [showAddTask, setShowAddTask] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskProject, setNewTaskProject] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState('medium');
  const [addingTask, setAddingTask] = useState(false);
  const [sendingEmail, setSendingEmail] = useState(false);

  useEffect(() => {
    if (!portal) return;
    let cancelled = false;

    const load = async () => {
      try {
        setLoading(true);
        const [projRes, appRes, taskRes, agendaRes] = await Promise.all([
          supabase.from('portal_projects').select('id, title, status, priority, progress, category, image_url, flagged').eq('portal_id', portal.id).order('created_at', { ascending: false }),
          supabase.from('portal_approvals').select('id, title, description, status, priority, project_id, requested_at').eq('portal_id', portal.id).eq('status', 'pending').order('requested_at', { ascending: false }),
          supabase.from('portal_tasks').select('id, title, status, priority, due_date, project_id, flagged, sort_order').eq('portal_id', portal.id).in('status', ['todo', 'in_progress', 'review']).order('sort_order', { ascending: true }).order('due_date', { ascending: true }),
          supabase.from('portal_agendas').select('id, title, week_start, week_end, notes, action_items, created_at').eq('portal_id', portal.id).eq('status', 'published').order('created_at', { ascending: false }).limit(2),
        ]);

        if (cancelled) return;
        if (!projRes.error) setProjects(projRes.data || []);
        if (!appRes.error) setApprovals(appRes.data || []);
        if (!taskRes.error) setTasks(taskRes.data || []);
        if (!agendaRes.error) setAgendas(agendaRes.data || []);
        setDriveUrl(portal.drive_url || '');
      } catch (e) {
        console.error('Dashboard load error:', e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    load();
    return () => { cancelled = true; };
  }, [portal]);

  const flash = (type: string, msg: string) => {
    setToast({ type, msg });
    setTimeout(() => setToast(null), 3000);
  };

  const sendNotification = async (nType: string, nTitle: string, nMsg: string) => {
    if (!portal) return;
    try {
      await fetch(
        `${import.meta.env.VITE_PUBLIC_SUPABASE_URL}/functions/v1/portal-notifications`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'apikey': import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY },
          body: JSON.stringify({ portal_id: portal.id, type: nType, title: nTitle, message: nMsg, channel: 'email' }),
        }
      );
    } catch {
      // silent
    }
  };

  const requestReport = async () => {
    setRequestingReport(true);
    await sendNotification(
      'report_requested',
      `${portal?.client_name} requested a ${reportType} report`,
      reportNote || `${portal?.client_name} has requested a new ${reportType} report be generated for ${portal?.brand_name}.`
    );
    setRequestingReport(false);
    setShowReportRequest(false);
    setReportNote('');
    flash('success', `Report request sent! We'll notify you when it's ready.`);
  };

  const addTask = async () => {
    if (!newTaskTitle.trim() || !portal) return;
    setAddingTask(true);
    const maxSort = tasks.length > 0 ? Math.max(...tasks.map(t => t.sort_order || 0)) : 0;
    const { error } = await supabase.from('portal_tasks').insert({
      portal_id: portal.id,
      project_id: newTaskProject || null,
      title: newTaskTitle.trim(),
      status: 'todo',
      priority: newTaskPriority,
      sort_order: maxSort + 1,
      flagged: false,
    });
    setAddingTask(false);
    if (error) { flash('error', 'Failed to add task'); return; }
    setNewTaskTitle('');
    setNewTaskProject('');
    setNewTaskPriority('medium');
    setShowAddTask(false);
    flash('success', 'Task added!');
    // Refresh tasks
    const { data } = await supabase.from('portal_tasks').select('id, title, status, priority, due_date, project_id, flagged, sort_order').eq('portal_id', portal.id).in('status', ['todo', 'in_progress', 'review']).order('sort_order', { ascending: true }).order('due_date', { ascending: true });
    if (data) setTasks(data);
  };

  const toggleFlag = async (taskId: string, current: boolean) => {
    await supabase.from('portal_tasks').update({ flagged: !current }).eq('id', taskId);
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, flagged: !current } : t));
    if (!current) {
      const task = tasks.find(t => t.id === taskId);
      if (task) {
        await sendNotification('task_flagged', `Task flagged: ${task.title}`, `${portal?.client_name} flagged the task "${task.title}" in the ${portal?.brand_name} portal.`);
      }
    }
    flash('success', current ? 'Flag removed' : 'Task flagged');
  };

  const changePriority = async (taskId: string, newPriority: string) => {
    await supabase.from('portal_tasks').update({ priority: newPriority }).eq('id', taskId);
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, priority: newPriority } : t));
    flash('success', `Priority set to ${newPriority}`);
  };

  const moveTask = async (taskId: string, direction: 'up' | 'down') => {
    const idx = tasks.findIndex(t => t.id === taskId);
    if (idx === -1) return;
    if (direction === 'up' && idx === 0) return;
    if (direction === 'down' && idx === tasks.length - 1) return;

    const otherIdx = direction === 'up' ? idx - 1 : idx + 1;
    const taskA = tasks[idx];
    const taskB = tasks[otherIdx];

    const newOrderA = taskB.sort_order || 0;
    const newOrderB = taskA.sort_order || 0;

    await Promise.all([
      supabase.from('portal_tasks').update({ sort_order: newOrderA }).eq('id', taskA.id),
      supabase.from('portal_tasks').update({ sort_order: newOrderB }).eq('id', taskB.id),
    ]);

    const updated = [...tasks];
    [updated[idx], updated[otherIdx]] = [updated[otherIdx], updated[idx]];
    setTasks(updated);
    flash('success', 'Task reordered');
  };

  const emailQuickReport = async () => {
    if (!portal) return;
    setSendingEmail(true);

    const activeProjects = projects.filter(p => p.status === 'working_on' || p.status === 'pending');
    const completedTasks = tasks.filter(t => t.status === 'completed').length;
    const metricsHtml = `
      <div style="margin-bottom: 20px;">
        <h3 style="font-size:15px;margin:0 0 12px;border-left:3px solid #7C3AED;padding-left:10px;">Overview</h3>
        <div style="display:flex;flex-wrap:wrap;gap:8px;">
          <div style="background:#f5f3ff;padding:10px 16px;border-radius:10px;font-size:13px;"><strong>Active Projects:</strong> ${activeProjects.length}</div>
          <div style="background:#f5f3ff;padding:10px 16px;border-radius:10px;font-size:13px;"><strong>Open Tasks:</strong> ${tasks.length}</div>
          <div style="background:#f5f3ff;padding:10px 16px;border-radius:10px;font-size:13px;"><strong>Pending Approvals:</strong> ${approvals.length}</div>
        </div>
      </div>
      <div style="margin-bottom:20px;">
        <h3 style="font-size:15px;margin:0 0 12px;border-left:3px solid #7C3AED;padding-left:10px;">Projects</h3>
        ${activeProjects.map(p => `
          <div style="background:#f9f9f9;padding:12px 16px;border-radius:10px;margin-bottom:6px;font-size:13px;">
            <strong>${p.title}</strong> — ${p.progress || 0}% · ${p.status.replace('_', ' ')}
            <div style="background:#eee;height:4px;border-radius:2px;margin-top:6px;"><div style="background:#7C3AED;height:4px;border-radius:2px;width:${p.progress || 0}%;"></div></div>
          </div>
        `).join('')}
      </div>
    `;

    try {
      await fetch(
        `${import.meta.env.VITE_PUBLIC_SUPABASE_URL}/functions/v1/portal-notifications`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'apikey': import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY },
          body: JSON.stringify({
            portal_id: portal.id,
            type: 'report_emailed',
            title: `Quick Report — ${portal.brand_name}`,
            message: `Here's a snapshot of your project status as of ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}.`,
            channel: 'email',
            report_html: metricsHtml,
          }),
        }
      );
      flash('success', `Report emailed to ${portal.recipient_email || 'your email'}!`);
    } catch {
      flash('error', 'Failed to send report email');
    }
    setSendingEmail(false);
  };

  const statusCounts = {
    working_on: projects.filter(p => p.status === 'working_on').length,
    pending: projects.filter(p => p.status === 'pending').length,
    upcoming: projects.filter(p => p.status === 'upcoming').length,
    concluded: projects.filter(p => p.status === 'concluded').length,
  };

  const overallProgress = projects.length > 0
    ? Math.round(projects.reduce((sum, p) => sum + (p.progress || 0), 0) / projects.length)
    : 0;

  const statusColors: Record<string, { bg: string; text: string; dot: string }> = {
    working_on: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', dot: 'bg-emerald-400' },
    pending: { bg: 'bg-amber-500/10', text: 'text-amber-400', dot: 'bg-amber-400' },
    upcoming: { bg: 'bg-sky-500/10', text: 'text-sky-400', dot: 'bg-sky-400' },
    concluded: { bg: 'bg-white/5', text: 'text-white/30', dot: 'bg-white/30' },
  };

  const priorityColors: Record<string, string> = {
    urgent: 'bg-red-500/10 text-red-400 border-red-500/20',
    high: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    medium: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
    low: 'bg-white/5 text-white/30 border-white/10',
  };

  const taskStatusColors: Record<string, string> = {
    todo: 'bg-white/5 text-white/30',
    in_progress: 'bg-sky-500/10 text-sky-400',
    review: 'bg-amber-500/10 text-amber-400',
    completed: 'bg-emerald-500/10 text-emerald-400',
  };

  const navigateTo = (path: string) => {
    const basePath = (window as any).__BASE_PATH__ || '';
    window.location.href = `${basePath}${path}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0C0B11] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#7C3AED] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0C0B11]">
      {/* Toast */}
      {toast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[100] animate-in fade-in slide-in-from-top-2">
          <div className={`px-5 py-3 rounded-xl text-xs font-semibold ${toast.type === 'success' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-red-500/20 text-red-400 border border-red-500/30'} backdrop-blur-md`}>
            {toast.msg}
          </div>
        </div>
      )}

      {/* Top bar */}
      <header className="sticky top-0 z-50 bg-[#0C0B11]/80 backdrop-blur-xl border-b border-white/[0.04]">
        <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-16 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #6b21a8 0%, #7C3AED 100%)' }}>
              <i className="ri-stack-line text-white text-sm" />
            </div>
            <span className="text-white font-editorial font-bold text-lg hidden sm:block">{portal?.brand_name}</span>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowReportRequest(true)} className="px-3 py-2 text-white/40 text-xs font-semibold rounded-lg hover:text-[#a855f7] hover:bg-[#7C3AED]/10 transition-all whitespace-nowrap cursor-pointer">
              <i className="ri-file-add-line mr-1.5" />Request Report
            </button>
            <button onClick={() => navigateTo('/portal/reports')} className="px-3 py-2 text-white/40 text-xs font-semibold rounded-lg hover:text-white/70 hover:bg-white/[0.04] transition-all whitespace-nowrap cursor-pointer">
              <i className="ri-file-chart-line mr-1.5" />Reports
            </button>
            <button onClick={logout} className="px-3 py-2 text-white/25 text-xs font-semibold rounded-lg hover:text-red-400 hover:bg-red-500/5 transition-all whitespace-nowrap cursor-pointer">
              <i className="ri-logout-box-line mr-1" />Exit
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-16 py-8 md:py-12">
        {/* Greeting + progress */}
        <div className="mb-10">
          <p className="text-white/30 text-xs font-semibold uppercase tracking-wider mb-2">Welcome back</p>
          <h1 className="font-editorial font-black text-white text-3xl md:text-4xl mb-6">{portal?.client_name}</h1>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-white/[0.03] border border-white/[0.05] rounded-xl p-4">
              <p className="text-white/25 text-[10px] font-semibold uppercase tracking-wider mb-1">Overall Progress</p>
              <p className="font-editorial font-black text-white text-2xl">{overallProgress}%</p>
              <div className="mt-2 h-1.5 bg-white/[0.05] rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-700" style={{ width: `${overallProgress}%`, background: 'linear-gradient(90deg, #7C3AED, #a855f7)' }} />
              </div>
            </div>
            <div className="bg-white/[0.03] border border-white/[0.05] rounded-xl p-4">
              <p className="text-white/25 text-[10px] font-semibold uppercase tracking-wider mb-1">Active Projects</p>
              <p className="font-editorial font-black text-emerald-400 text-2xl">{statusCounts.working_on + statusCounts.pending}</p>
            </div>
            <div className="bg-white/[0.03] border border-white/[0.05] rounded-xl p-4">
              <p className="text-white/25 text-[10px] font-semibold uppercase tracking-wider mb-1">Pending Approvals</p>
              <p className={`font-editorial font-black text-2xl ${approvals.length > 0 ? 'text-amber-400' : 'text-white/40'}`}>{approvals.length}</p>
            </div>
            <div className="bg-white/[0.03] border border-white/[0.05] rounded-xl p-4">
              <p className="text-white/25 text-[10px] font-semibold uppercase tracking-wider mb-1">Open Tasks</p>
              <p className="font-editorial font-black text-sky-400 text-2xl">{tasks.length}</p>
            </div>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1 mb-8 bg-white/[0.02] rounded-full p-1 w-fit border border-white/[0.04]">
          {(['overview', 'tasks', 'approvals'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-5 py-2 text-xs font-semibold rounded-full transition-all capitalize whitespace-nowrap cursor-pointer ${activeTab === tab ? 'bg-[#7C3AED] text-white' : 'text-white/30 hover:text-white/60'}`}
            >
              {tab === 'overview' ? 'Projects' : tab}
            </button>
          ))}
        </div>

        {/* Overview tab: Projects */}
        {activeTab === 'overview' && (
          <div>
            {projects.length === 0 ? (
              <div className="text-center py-20">
                <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-white/[0.03] border border-white/[0.05] flex items-center justify-center">
                  <i className="ri-folder-line text-2xl text-white/15" />
                </div>
                <p className="text-white/30 text-sm">No projects yet</p>
                <p className="text-white/15 text-xs mt-1">Your agency will add projects here soon</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {projects.map((project) => {
                  const sc = statusColors[project.status] || statusColors.upcoming;
                  return (
                    <div
                      key={project.id}
                      className="group bg-white/[0.02] border border-white/[0.05] rounded-2xl p-5 hover:border-[#7C3AED]/30 transition-all duration-300"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className={`w-2.5 h-2.5 rounded-full ${sc.dot}`} />
                          <span className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-md ${sc.bg} ${sc.text}`}>
                            {project.status.replace('_', ' ')}
                          </span>
                        </div>
                        <div className="flex items-center gap-1">
                          {project.priority === 'urgent' && (
                            <span className="text-[9px] font-semibold uppercase text-red-400 bg-red-500/10 px-2 py-0.5 rounded-md">Urgent</span>
                          )}
                          <button
                            onClick={async (e) => { e.stopPropagation(); await supabase.from('portal_projects').update({ flagged: !project.flagged }).eq('id', project.id); setProjects(prev => prev.map(p => p.id === project.id ? { ...p, flagged: !project.flagged } : p)); }}
                            className={`p-1.5 rounded-lg transition-all cursor-pointer ${project.flagged ? 'text-amber-400 bg-amber-500/10' : 'text-white/15 hover:text-amber-400 hover:bg-amber-500/10'}`}
                            title={project.flagged ? 'Unflag' : 'Flag this project'}
                          >
                            <i className={`text-xs ${project.flagged ? 'ri-flag-fill' : 'ri-flag-line'}`} />
                          </button>
                        </div>
                      </div>
                      <h3
                        onClick={() => navigateTo(`/portal/project/${project.id}`)}
                        className="font-editorial font-bold text-white text-lg mb-2 hover:text-[#a855f7] transition-colors cursor-pointer"
                      >{project.title}</h3>
                      <div className="flex items-center gap-3">
                        <div className="flex-1 h-1 bg-white/[0.05] rounded-full overflow-hidden">
                          <div className="h-full rounded-full transition-all duration-700" style={{ width: `${project.progress || 0}%`, background: 'linear-gradient(90deg, #7C3AED, #a855f7)' }} />
                        </div>
                        <span className="text-white/30 text-xs font-semibold">{project.progress || 0}%</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tasks tab */}
        {activeTab === 'tasks' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <p className="text-white/25 text-[10px] font-semibold uppercase tracking-wider">
                {tasks.length} open task{tasks.length !== 1 ? 's' : ''}
              </p>
              <button
                onClick={() => setShowAddTask(true)}
                className="px-3 py-1.5 text-xs font-semibold text-[#a855f7] bg-[#7C3AED]/10 border border-[#7C3AED]/20 rounded-lg hover:bg-[#7C3AED]/20 transition-all whitespace-nowrap cursor-pointer"
              >
                <i className="ri-add-line mr-1" />Add Task
              </button>
            </div>

            {/* Add Task inline form */}
            {showAddTask && (
              <div className="bg-white/[0.03] border border-[#7C3AED]/20 rounded-2xl p-4 mb-4 animate-in fade-in slide-in-from-top-2">
                <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="text"
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                    placeholder="Task title..."
                    autoFocus
                    onKeyDown={(e) => { if (e.key === 'Enter') addTask(); }}
                    className="flex-1 px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-sm placeholder:text-white/20 focus:outline-none focus:border-[#7C3AED]/50 transition-colors"
                  />
                  <select
                    value={newTaskProject}
                    onChange={(e) => setNewTaskProject(e.target.value)}
                    className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white/50 text-sm focus:outline-none focus:border-[#7C3AED]/50 cursor-pointer"
                  >
                    <option value="">No project</option>
                    {projects.map(p => <option key={p.id} value={p.id}>{p.title}</option>)}
                  </select>
                  <select
                    value={newTaskPriority}
                    onChange={(e) => setNewTaskPriority(e.target.value)}
                    className="px-3 py-2 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white/50 text-sm focus:outline-none focus:border-[#7C3AED]/50 cursor-pointer"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </select>
                  <div className="flex items-center gap-2">
                    <button onClick={addTask} disabled={addingTask || !newTaskTitle.trim()} className="px-4 py-2 text-xs font-semibold text-white bg-[#7C3AED] rounded-xl hover:bg-[#6b21a8] disabled:opacity-30 transition-all whitespace-nowrap cursor-pointer">
                      {addingTask ? 'Adding...' : 'Add'}
                    </button>
                    <button onClick={() => { setShowAddTask(false); setNewTaskTitle(''); }} className="px-3 py-2 text-xs text-white/30 hover:text-white/60 transition-all whitespace-nowrap cursor-pointer">
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            )}

            {tasks.length === 0 && !showAddTask ? (
              <div className="text-center py-20">
                <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-white/[0.03] border border-white/[0.05] flex items-center justify-center">
                  <i className="ri-task-line text-2xl text-white/15" />
                </div>
                <p className="text-white/30 text-sm">No open tasks</p>
                <p className="text-white/15 text-xs mt-1">All caught up! Add a task to get started</p>
              </div>
            ) : (
              <div className="space-y-2">
                {tasks.map((task, idx) => (
                  <div key={task.id} className="flex items-center gap-3 bg-white/[0.02] border border-white/[0.05] rounded-xl px-4 py-3 group hover:border-white/[0.08] transition-all">
                    {/* Reorder buttons */}
                    <div className="flex flex-col gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => moveTask(task.id, 'up')} disabled={idx === 0} className="w-4 h-4 flex items-center justify-center text-white/20 hover:text-white/60 disabled:opacity-20 transition-colors cursor-pointer">
                        <i className="ri-arrow-up-s-line text-[10px]" />
                      </button>
                      <button onClick={() => moveTask(task.id, 'down')} disabled={idx === tasks.length - 1} className="w-4 h-4 flex items-center justify-center text-white/20 hover:text-white/60 disabled:opacity-20 transition-colors cursor-pointer">
                        <i className="ri-arrow-down-s-line text-[10px]" />
                      </button>
                    </div>

                    <div className={`w-2 h-2 rounded-full flex-shrink-0 ${task.status === 'in_progress' ? 'bg-sky-400' : task.status === 'review' ? 'bg-amber-400' : 'bg-white/20'}`} />

                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm truncate">{task.title}</p>
                      <p className="text-white/25 text-[11px] mt-0.5">
                        {task.due_date ? `Due ${new Date(task.due_date + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}` : 'No due date'}
                      </p>
                    </div>

                    {/* Flag */}
                    <button
                      onClick={() => toggleFlag(task.id, task.flagged)}
                      className={`p-1.5 rounded-lg transition-all cursor-pointer ${task.flagged ? 'text-amber-400 bg-amber-500/10' : 'text-white/10 hover:text-amber-400 hover:bg-amber-500/10'}`}
                      title={task.flagged ? 'Unflag' : 'Flag this task'}
                    >
                      <i className={`text-xs ${task.flagged ? 'ri-flag-fill' : 'ri-flag-line'}`} />
                    </button>

                    {/* Priority dropdown */}
                    <select
                      value={task.priority}
                      onChange={(e) => changePriority(task.id, e.target.value)}
                      className="text-[10px] font-semibold px-2 py-1 rounded-md bg-white/[0.03] border border-white/[0.06] text-white/50 focus:outline-none cursor-pointer appearance-none"
                      style={{ minWidth: '70px' }}
                    >
                      <option value="urgent">Urgent</option>
                      <option value="high">High</option>
                      <option value="medium">Medium</option>
                      <option value="low">Low</option>
                    </select>

                    <span className={`text-[10px] font-semibold px-2 py-1 rounded-md ${taskStatusColors[task.status] || ''}`}>
                      {task.status.replace('_', ' ')}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Approvals tab */}
        {activeTab === 'approvals' && (
          <div>
            {approvals.length === 0 ? (
              <div className="text-center py-20">
                <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-white/[0.03] border border-white/[0.05] flex items-center justify-center">
                  <i className="ri-check-double-line text-2xl text-white/15" />
                </div>
                <p className="text-white/30 text-sm">Nothing waiting for approval</p>
                <p className="text-white/15 text-xs mt-1">Pending approvals will show up here</p>
              </div>
            ) : (
              <div className="space-y-3">
                {approvals.map((approval) => (
                  <div key={approval.id} className="bg-white/[0.02] border border-white/[0.05] rounded-2xl p-5">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-editorial font-bold text-white text-base">{approval.title}</h3>
                      <span className={`text-[10px] font-semibold px-2 py-1 rounded-md ${priorityColors[approval.priority] || priorityColors.medium}`}>
                        {approval.priority}
                      </span>
                    </div>
                    <p className="text-white/40 text-sm mb-4">{approval.description}</p>
                    <div className="flex items-center gap-3">
                      <button onClick={async () => {
                        await supabase.from('portal_approvals').update({ status: 'approved', responded_at: new Date().toISOString() }).eq('id', approval.id);
                        window.location.reload();
                      }} className="px-4 py-2 text-xs font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-lg hover:bg-emerald-500/20 transition-all whitespace-nowrap cursor-pointer">
                        <i className="ri-check-line mr-1" />Approve
                      </button>
                      <button onClick={async () => {
                        await supabase.from('portal_approvals').update({ status: 'changes_requested', responded_at: new Date().toISOString() }).eq('id', approval.id);
                        window.location.reload();
                      }} className="px-4 py-2 text-xs font-semibold text-amber-400 bg-amber-500/10 border border-amber-500/20 rounded-lg hover:bg-amber-500/20 transition-all whitespace-nowrap cursor-pointer">
                        <i className="ri-edit-line mr-1" />Request Changes
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Agenda & Drive Section */}
        <div className="mt-12 grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Latest Agenda */}
          <div className="lg:col-span-2 bg-white/[0.02] border border-white/[0.05] rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-5">
              <div className="w-8 h-8 rounded-lg bg-[#7C3AED]/10 flex items-center justify-center">
                <i className="ri-calendar-event-line text-sm text-[#a855f7]" />
              </div>
              <h2 className="font-editorial font-bold text-white text-lg">This Week's Agenda</h2>
            </div>
            {agendas.length === 0 ? (
              <div className="text-center py-8">
                <i className="ri-calendar-line text-2xl text-white/10 mb-3 block" />
                <p className="text-white/25 text-sm">No agenda published yet</p>
                <p className="text-white/15 text-xs mt-1">Your agency will push weekly agendas here</p>
              </div>
            ) : (
              agendas.slice(0, 1).map((ag) => (
                <div key={ag.id}>
                  <div className="flex flex-wrap items-center gap-3 mb-4">
                    <h3 className="font-editorial font-bold text-white text-base">{ag.title}</h3>
                    <span className="text-white/20 text-xs">
                      {ag.week_start && new Date(ag.week_start + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      {ag.week_end && ` — ${new Date(ag.week_end + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`}
                    </span>
                  </div>
                  {ag.notes && (
                    <div className="bg-white/[0.03] border border-white/[0.04] rounded-xl p-4 mb-4">
                      <p className="text-white/50 text-xs leading-relaxed whitespace-pre-wrap">{ag.notes}</p>
                    </div>
                  )}
                  {ag.action_items && Array.isArray(ag.action_items) && ag.action_items.length > 0 && (
                    <div className="space-y-2">
                      <p className="text-white/25 text-[10px] font-semibold uppercase tracking-wider">Action Items</p>
                      {ag.action_items.map((item: string, i: number) => (
                        <div key={i} className="flex items-start gap-3 p-3 bg-white/[0.02] border border-white/[0.04] rounded-xl">
                          <span className="w-5 h-5 rounded-md bg-[#7C3AED]/15 text-[#a855f7] text-[10px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">{i + 1}</span>
                          <p className="text-white/55 text-xs leading-relaxed">{item}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>

          {/* Drive Link + Quick Report */}
          <div className="space-y-4">
            <div className="bg-white/[0.02] border border-white/[0.05] rounded-2xl p-6">
              <div className="flex items-center gap-2 mb-5">
                <div className="w-8 h-8 rounded-lg bg-white/[0.04] flex items-center justify-center">
                  <i className="ri-folder-shared-line text-sm text-white/30" />
                </div>
                <h2 className="font-editorial font-bold text-white text-lg">Shared Drive</h2>
              </div>
              {driveUrl ? (
                <div>
                  <p className="text-white/25 text-xs mb-3">Access all project files and assets</p>
                  <a
                    href={driveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-[#7C3AED] hover:bg-[#6b21a8] rounded-xl transition-all whitespace-nowrap cursor-pointer"
                  >
                    <i className="ri-external-link-line" />Open Drive Folder
                  </a>
                </div>
              ) : (
                <div className="text-center py-6">
                  <i className="ri-folder-line text-2xl text-white/10 mb-3 block" />
                  <p className="text-white/20 text-xs">No drive link set yet</p>
                </div>
              )}
            </div>

            {/* Quick Report Email */}
            <div className="bg-white/[0.02] border border-white/[0.05] rounded-2xl p-6">
              <div className="flex items-center gap-2 mb-5">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                  <i className="ri-mail-send-line text-sm text-emerald-400" />
                </div>
                <h2 className="font-editorial font-bold text-white text-lg">Quick Report</h2>
              </div>
              <p className="text-white/25 text-xs mb-4">Get a snapshot of all your active projects emailed to you instantly.</p>
              <button
                onClick={emailQuickReport}
                disabled={sendingEmail}
                className="w-full px-4 py-2.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 rounded-xl transition-all whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
              >
                {sendingEmail ? (
                  <><div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />Sending...</>
                ) : (
                  <><i className="ri-mail-line" />Email Me My Report</>
                )}
              </button>
              {portal?.recipient_email && (
                <p className="text-white/20 text-[10px] mt-2 text-center">Will send to {portal.recipient_email}</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Report Request Modal */}
      {showReportRequest && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowReportRequest(false)} />
          <div className="relative bg-[#14131A] border border-white/[0.08] rounded-2xl p-6 w-full max-w-md animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-editorial font-bold text-white text-lg">Request Report</h3>
              <button onClick={() => setShowReportRequest(false)} className="w-8 h-8 rounded-lg bg-white/[0.04] flex items-center justify-center text-white/30 hover:text-white/70 transition-colors cursor-pointer">
                <i className="ri-close-line" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-white/30 text-[10px] font-semibold uppercase tracking-wider mb-2">Report Type</label>
                <div className="flex gap-2">
                  {(['weekly', 'monthly', 'quarterly'] as const).map((t) => (
                    <button
                      key={t}
                      onClick={() => setReportType(t)}
                      className={`px-4 py-2 text-xs font-semibold rounded-lg capitalize transition-all whitespace-nowrap cursor-pointer ${reportType === t ? 'bg-[#7C3AED] text-white' : 'text-white/30 bg-white/[0.02] border border-white/[0.04] hover:text-white/60'}`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-white/30 text-[10px] font-semibold uppercase tracking-wider mb-2">Note (optional)</label>
                <textarea
                  value={reportNote}
                  onChange={(e) => setReportNote(e.target.value)}
                  placeholder="Any specific areas you'd like covered..."
                  maxLength={500}
                  className="w-full px-3 py-2.5 bg-white/[0.04] border border-white/[0.08] rounded-xl text-white text-sm placeholder:text-white/15 focus:outline-none focus:border-[#7C3AED]/50 transition-colors resize-none h-20"
                />
              </div>

              <button
                onClick={requestReport}
                disabled={requestingReport}
                className="w-full py-3 text-sm font-semibold text-white bg-[#7C3AED] hover:bg-[#6b21a8] disabled:opacity-50 rounded-xl transition-all whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
              >
                {requestingReport ? (
                  <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />Requesting...</>
                ) : (
                  <><i className="ri-send-plane-line" />Send Request</>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function Dashboard() {
  return (
    <PortalProvider>
      <DashboardContent />
    </PortalProvider>
  );
}