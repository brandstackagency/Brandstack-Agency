import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export default function PortalLogin() {
  const [keyword, setKeyword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = keyword.trim();
    if (!trimmed) {
      setError('Please enter your access keyword');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const { data, error: dbErr } = await supabase
        .from('client_portals')
        .select('id, client_name, brand_name, slug, login_keyword')
        .eq('login_keyword', trimmed)
        .eq('status', 'active')
        .maybeSingle();

      if (dbErr || !data) {
        setError('Invalid keyword. Please check and try again.');
        setLoading(false);
        return;
      }

      // Store portal session
      sessionStorage.setItem('portal_id', data.id);
      sessionStorage.setItem('portal_client_name', data.client_name);
      sessionStorage.setItem('portal_brand_name', data.brand_name);
      sessionStorage.setItem('portal_slug', data.slug);

      const basePath = (window as any).__BASE_PATH__ || '';
      window.location.href = `${basePath}/portal/dashboard`;
    } catch {
      setError('Something went wrong. Please try again.');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0C0B11] flex items-center justify-center px-4 relative overflow-hidden">
      {/* Ambient glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full" style={{ background: 'radial-gradient(circle, rgba(124,58,237,0.08) 0%, transparent 70%)' }} />

      <div className="relative z-10 w-full max-w-md">
        {/* Branding */}
        <div className="text-center mb-10">
          <div className="w-14 h-14 mx-auto mb-5 rounded-2xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #6b21a8 0%, #7C3AED 100%)' }}>
            <i className="ri-stack-line text-white text-xl" />
          </div>
          <h1 className="font-editorial font-black text-white text-3xl mb-2">Client Portal</h1>
          <p className="text-white/30 text-sm">Enter your access keyword to view your dashboard</p>
        </div>

        {/* Login form */}
        <form onSubmit={handleLogin} className="space-y-4">
          <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-5">
            <div className="relative">
              <div className="absolute left-4 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg bg-white/[0.04] flex items-center justify-center">
                <i className="ri-key-2-line text-white/30 text-sm" />
              </div>
              <input
                type="text"
                value={keyword}
                onChange={(e) => { setKeyword(e.target.value); setError(''); }}
                placeholder="Enter your access keyword"
                autoFocus
                autoComplete="off"
                className="w-full pl-14 pr-4 py-4 bg-transparent text-white text-sm placeholder:text-white/15 focus:outline-none rounded-xl"
              />
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-2 px-4 py-3 bg-red-500/5 border border-red-500/10 rounded-xl">
              <i className="ri-error-warning-line text-red-400 text-sm" />
              <p className="text-red-400 text-xs">{error}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 text-white text-sm font-bold rounded-xl bg-[#7C3AED] hover:bg-[#6b21a8] disabled:opacity-50 disabled:cursor-not-allowed transition-all whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Verifying...
              </>
            ) : (
              <>
                <i className="ri-arrow-right-line" />
                Access Dashboard
              </>
            )}
          </button>
        </form>

        <p className="text-center text-white/10 text-[11px] mt-8">
          If you've lost your keyword, contact your agency representative.<br />
          <span className="text-white/5">Prefer a direct link? Ask your agency for your personalized portal URL.</span>
        </p>
      </div>
    </div>
  );
}