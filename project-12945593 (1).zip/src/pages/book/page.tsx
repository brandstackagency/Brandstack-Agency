import { useState } from 'react';
import Navbar from '@/pages/home/components/Navbar';
import Footer from '@/pages/home/components/Footer';

const services = [
  'GTM Launchpad',
  'SEG Framework',
  'Performance Marketing',
  'Marketing Audit',
  'Brand Strategy',
  'Not sure yet',
];

const budgets = [
  'Under $2,000',
  '$2,000 to $5,000',
  '$5,000 to $10,000',
  '$10,000 to $25,000',
  '$25,000+',
];

const timelines = [
  'ASAP',
  'Within 1 month',
  '1 to 3 months',
  '3 to 6 months',
  'Flexible',
];

type SubmitState = 'idle' | 'loading' | 'success' | 'error';

export default function BookPage() {
  const [submitState, setSubmitState] = useState<SubmitState>('idle');
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [charCount, setCharCount] = useState(0);

  const toggleService = (s: string) => {
    setSelectedServices((prev) =>
      prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]
    );
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (submitState === 'loading') return;

    const form = e.currentTarget;
    const data = new FormData(form);
    data.set('services', selectedServices.join(', '));

    const body = new URLSearchParams();
    data.forEach((value, key) => {
      body.append(key, value as string);
    });

    setSubmitState('loading');
    try {
      const res = await fetch('https://readdy.ai/api/form/d79sqbb2hsar0k5m0srg', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString(),
      });
      if (res.ok) {
        setSubmitState('success');
        form.reset();
        setSelectedServices([]);
        setCharCount(0);
      } else {
        setSubmitState('error');
      }
    } catch {
      setSubmitState('error');
    }
  };

  return (
    <div className="min-h-screen bg-[#0C0B11]">
      <Navbar />

      {/* Hero */}
      <section className="relative pt-40 pb-20 bg-[#100D18] overflow-hidden">
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)',
            backgroundSize: '48px 48px',
          }}
        />
        <div
          className="absolute inset-0 pointer-events-none"
          style={{ background: 'radial-gradient(ellipse 70% 60% at 50% 0%, rgba(124,58,237,0.22) 0%, transparent 70%)' }}
        />
        <div className="relative z-10 max-w-3xl mx-auto px-6 md:px-8 text-center">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-8 h-px bg-[#7C3AED]" />
            <span className="text-[#a855f7] text-xs font-semibold uppercase tracking-[0.2em]">
              Let&apos;s Work Together
            </span>
            <div className="w-8 h-px bg-[#7C3AED]" />
          </div>
          <h1 className="font-['Playfair_Display'] font-black text-white text-5xl lg:text-6xl mb-5 leading-tight">
            Book a Strategy Call
          </h1>
          <p className="text-white/50 text-lg leading-relaxed max-w-xl mx-auto">
            Tell us about your brand and goals. We&apos;ll come prepared with ideas, not just questions.
          </p>
        </div>
      </section>

      {/* Trust bar */}
      <div className="bg-[#08080C] border-b border-white/[0.06]">
        <div className="max-w-4xl mx-auto px-6 md:px-8 py-5 flex flex-wrap items-center justify-center gap-6 md:gap-10">
          {[
            { icon: 'ri-time-line', text: '30-min focused session' },
            { icon: 'ri-shield-check-line', text: 'No commitment required' },
            { icon: 'ri-calendar-check-line', text: 'Response within 24hrs' },
            { icon: 'ri-team-line', text: 'Senior strategist on the call' },
          ].map((item) => (
            <div key={item.text} className="flex items-center gap-2 text-sm text-white/40">
              <i className={`${item.icon} text-[#7C3AED] text-base`} />
              <span>{item.text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Form */}
      <section className="py-16 bg-[#0D0B14]">
        <div className="max-w-2xl mx-auto px-6 md:px-8">
          {submitState === 'success' ? (
            <div className="text-center py-20">
              <div className="w-16 h-16 flex items-center justify-center bg-gradient-to-br from-[#7C3AED] to-[#10B981] rounded-full mx-auto mb-6">
                <i className="ri-check-line text-white text-2xl" />
              </div>
              <h2 className="font-['Playfair_Display'] font-black text-white text-3xl mb-3">
                You&apos;re booked in!
              </h2>
              <p className="text-white/40 text-base leading-relaxed max-w-sm mx-auto">
                We&apos;ve received your request and will reach out within 24 hours to confirm your call time.
              </p>
              <button
                onClick={() => setSubmitState('idle')}
                className="mt-8 px-6 py-3 bg-white/10 text-white text-sm font-semibold rounded-full hover:bg-white/20 transition-all cursor-pointer whitespace-nowrap"
              >
                Submit Another Request
              </button>
            </div>
          ) : (
            <form
              data-readdy-form
              onSubmit={handleSubmit}
              className="bg-white/[0.04] rounded-2xl border border-white/[0.08] p-8 md:p-10 space-y-7"
            >
              {/* Name + Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">
                    Full Name <span className="text-[#a855f7]">*</span>
                  </label>
                  <input
                    type="text"
                    name="name"
                    required
                    placeholder="Jane Doe"
                    className="w-full px-4 py-3 text-sm bg-white/[0.05] border border-white/[0.08] rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#7C3AED]/30 focus:border-[#7C3AED]/50 transition-all placeholder:text-white/20"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">
                    Email Address <span className="text-[#a855f7]">*</span>
                  </label>
                  <input
                    type="email"
                    name="email"
                    required
                    placeholder="jane@brand.com"
                    className="w-full px-4 py-3 text-sm bg-white/[0.05] border border-white/[0.08] rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#7C3AED]/30 focus:border-[#7C3AED]/50 transition-all placeholder:text-white/20"
                  />
                </div>
              </div>

              {/* Brand + Role */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">
                    Brand / Company Name <span className="text-[#a855f7]">*</span>
                  </label>
                  <input
                    type="text"
                    name="brand"
                    required
                    placeholder="Acme Inc."
                    className="w-full px-4 py-3 text-sm bg-white/[0.05] border border-white/[0.08] rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#7C3AED]/30 focus:border-[#7C3AED]/50 transition-all placeholder:text-white/20"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">
                    Your Role
                  </label>
                  <input
                    type="text"
                    name="role"
                    placeholder="Founder, CMO, Marketing Lead..."
                    className="w-full px-4 py-3 text-sm bg-white/[0.05] border border-white/[0.08] rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#7C3AED]/30 focus:border-[#7C3AED]/50 transition-all placeholder:text-white/20"
                  />
                </div>
              </div>

              {/* Services */}
              <div>
                <label className="block text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">
                  What service are you interested in?
                </label>
                <div className="flex flex-wrap gap-2">
                  {services.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => toggleService(s)}
                      className={`px-4 py-2 rounded-full text-sm font-semibold border transition-all cursor-pointer whitespace-nowrap ${
                        selectedServices.includes(s)
                          ? 'bg-[#7C3AED] text-white border-[#7C3AED]'
                          : 'bg-white/[0.05] text-white/40 border-white/[0.08] hover:border-[#7C3AED]/40 hover:text-[#a855f7]'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
                <input type="hidden" name="services" value={selectedServices.join(', ')} />
              </div>

              {/* Budget */}
              <div>
                <label className="block text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">
                  Estimated Budget
                </label>
                <select
                  name="budget"
                  className="w-full px-4 py-3 text-sm bg-[#0C0B11] border border-white/[0.08] rounded-lg text-white/60 focus:outline-none focus:ring-2 focus:ring-[#7C3AED]/30 focus:border-[#7C3AED]/50 transition-all cursor-pointer"
                >
                  <option value="">Select a range...</option>
                  {budgets.map((b) => (
                    <option key={b} value={b}>{b}</option>
                  ))}
                </select>
              </div>

              {/* Timeline */}
              <div>
                <label className="block text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">
                  Preferred Timeline
                </label>
                <select
                  name="timeline"
                  className="w-full px-4 py-3 text-sm bg-[#0C0B11] border border-white/[0.08] rounded-lg text-white/60 focus:outline-none focus:ring-2 focus:ring-[#7C3AED]/30 focus:border-[#7C3AED]/50 transition-all cursor-pointer"
                >
                  <option value="">When do you want to start?</option>
                  {timelines.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>

              {/* Message */}
              <div>
                <label className="block text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">
                  Tell us about your brand &amp; goals
                </label>
                <textarea
                  name="message"
                  rows={5}
                  maxLength={500}
                  placeholder="What are you building? What's the challenge you're facing? What does success look like for you?"
                  onChange={(e) => setCharCount(e.target.value.length)}
                  className="w-full px-4 py-3 text-sm bg-white/[0.05] border border-white/[0.08] rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#7C3AED]/30 focus:border-[#7C3AED]/50 transition-all resize-none placeholder:text-white/20"
                />
                <p className="text-right text-xs text-white/25 mt-1">{charCount}/500</p>
              </div>

              {/* Referral */}
              <div>
                <label className="block text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">
                  How did you hear about us?
                </label>
                <input
                  type="text"
                  name="referral"
                  placeholder="Instagram, referral, Google..."
                  className="w-full px-4 py-3 text-sm bg-white/[0.05] border border-white/[0.08] rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#7C3AED]/30 focus:border-[#7C3AED]/50 transition-all placeholder:text-white/20"
                />
              </div>

              {submitState === 'error' && (
                <p className="text-red-400 text-sm text-center">
                  Something went wrong. Please try again or email us directly.
                </p>
              )}

              <button
                type="submit"
                disabled={submitState === 'loading'}
                className="w-full py-4 text-white text-sm font-bold rounded-full hover:opacity-90 transition-all duration-300 disabled:opacity-60 cursor-pointer whitespace-nowrap flex items-center justify-center gap-2"
                style={{
                  background: 'linear-gradient(135deg, #6b21a8 0%, #7C3AED 60%, #a855f7 100%)',
                  boxShadow: '0 4px 24px rgba(124,58,237,0.35)',
                }}
              >
                {submitState === 'loading' ? (
                  <>
                    <i className="ri-loader-4-line animate-spin text-base" />
                    Sending your request...
                  </>
                ) : (
                  <>
                    Book My Strategy Call
                    <i className="ri-arrow-right-line text-base" />
                  </>
                )}
              </button>

              <p className="text-center text-xs text-white/25 leading-relaxed">
                By submitting, you agree to be contacted by the Brandstack team. No spam, ever.
              </p>
            </form>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
