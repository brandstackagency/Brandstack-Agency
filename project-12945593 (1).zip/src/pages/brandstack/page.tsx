import React, { useEffect, useRef, useState, useCallback } from 'react';
import Navbar from '../home/components/Navbar';
import Footer from '../home/components/Footer';
import ScrollReveal from '../../components/feature/ScrollReveal';
import GridBackground from '../../components/feature/GridBackground';

interface StackLayer {
  id: string;
  label: string;
  color: string;
  icon: string;
  headline: string;
  description: string;
  items: string[];
  stat: string;
  statLabel: string;
}

const stackLayers: StackLayer[] = [
  {
    id: 'ideas',
    label: 'Ideas',
    color: '#9333ea',
    icon: 'ri-lightbulb-flash-line',
    headline: 'Every Stack Starts With a Spark.',
    description:
      'Before any strategy is written or a single campaign launched, there is an idea. We spend time in discovery, research, and deep listening to surface the insights that will anchor every decision downstream.',
    items: [
      'Brand discovery & stakeholder interviews',
      'Market research & competitor mapping',
      'Customer insight & persona development',
      'Creative brief & strategic hypotheses',
    ],
    stat: '100%',
    statLabel: 'of our strategies begin with deep research',
  },
  {
    id: 'strategy',
    label: 'Strategy',
    color: '#7C3AED',
    icon: 'ri-compass-3-line',
    headline: 'Stack the Blueprint Before You Build.',
    description:
      'Raw ideas need structure. We translate insights into a clear marketing strategy; positioning, messaging architecture, channel mapping, and growth timelines, designed to compound over quarters, not days.',
    items: [
      'Brand positioning & messaging framework',
      'Go-to-market channel strategy',
      'Content & campaign roadmaps',
      'Growth milestones & KPI framework',
    ],
    stat: '4-6',
    statLabel: 'weeks for a complete strategic blueprint',
  },
  {
    id: 'execution',
    label: 'Execution',
    color: '#6b21a8',
    icon: 'ri-rocket-line',
    headline: 'Launch With Precision, Not Hope.',
    description:
      'This is where the stack comes alive. Every campaign, asset, and touchpoint is deployed with precision. We handle creative production, paid media setup, and funnel mechanics so nothing is left to chance.',
    items: [
      'Campaign launch & paid media activation',
      'Creative production & asset rollout',
      'Funnel setup & conversion optimization',
      'Performance tracking & real-time monitoring',
    ],
    stat: '2.3x',
    statLabel: 'average performance uplift on first launch',
  },
  {
    id: 'creativity',
    label: 'Creativity',
    color: '#a855f7',
    icon: 'ri-palette-line',
    headline: 'Creative That Stacks on Culture.',
    description:
      'Creativity is not decoration. It is the connective tissue between strategy and audience response. We design bold, memorable creative that earns attention, drives engagement, and lives rent-free in the minds of your market.',
    items: [
      'Visual identity & art direction',
      'Copywriting that sells & storysells',
      'Social-first content systems',
      'Creative testing & iteration loops',
    ],
    stat: '3x',
    statLabel: 'higher engagement on concept-first creative',
  },
];

export default function BrandStackPage() {
  const [activeLayer, setActiveLayer] = useState<number | null>(null);
  const [hoveredLayer, setHoveredLayer] = useState<number | null>(null);
  const [isInView, setIsInView] = useState(false);
  const [revealedItems, setRevealedItems] = useState<number[]>([]);
  const heroRef = useRef<HTMLDivElement>(null);
  const sectionRefs = useRef<(HTMLDivElement | null)[]>([]);
  const stackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
        }
      },
      { threshold: 0.15 }
    );
    if (stackRef.current) observer.observe(stackRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isInView) return;
    const timers: ReturnType<typeof setTimeout>[] = [];
    stackLayers.forEach((_, layerIdx) => {
      stackLayers[layerIdx].items.forEach((__, itemIdx) => {
        const t = setTimeout(() => {
          setRevealedItems((prev) => [...prev, layerIdx * 100 + itemIdx]);
        }, 600 + layerIdx * 500 + itemIdx * 120);
        timers.push(t);
      });
    });
    return () => timers.forEach(clearTimeout);
  }, [isInView]);

  const handleLayerClick = useCallback((idx: number) => {
    setActiveLayer(idx);
    const el = sectionRefs.current[idx];
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, []);

  return (
    <div className="min-h-screen bg-[#08080C] overflow-x-hidden">
      <Navbar />

      <section
        ref={heroRef}
        className="relative pt-24 md:pt-32 lg:pt-40 pb-16 md:pb-24 overflow-hidden"
      >
        {/* Grid Background */}
        <div className="absolute inset-0 pointer-events-none">
          <GridBackground />
        </div>

        {/* Ambient glows */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[500px] bg-[#7C3AED]/[0.06] rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#6b21a8]/[0.05] rounded-full blur-3xl" />
          <div className="absolute top-20 right-10 w-28 h-28 border border-white/[0.03] rotate-12 rounded-lg" />
          <div className="absolute bottom-40 left-20 w-20 h-20 border border-white/[0.03] -rotate-6 rounded-xl" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-8 lg:px-16">
          <ScrollReveal direction="up">
            <div className="flex items-center gap-3 mb-5 md:mb-7">
              <div className="w-8 md:w-10 h-px bg-[#7C3AED]" />
              <span className="text-[#a855f7] text-[10px] md:text-xs font-semibold uppercase tracking-[0.2em]">
                How We Build Brands
              </span>
            </div>
          </ScrollReveal>

          <ScrollReveal direction="up" delay={80}>
            <h1
              className="font-editorial font-black text-white leading-[0.92] tracking-tight mb-6 md:mb-8 max-w-4xl"
              style={{ fontSize: 'clamp(2.4rem, 6vw, 5rem)' }}
            >
              The Brandstack
              <br />
              <span
                className="italic"
                style={{
                  background:
                    'linear-gradient(135deg, #6b21a8 0%, #7C3AED 60%, #a855f7 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              >
                Method.
              </span>
            </h1>
          </ScrollReveal>

          <ScrollReveal direction="up" delay={160}>
            <p className="text-white/40 text-sm md:text-base lg:text-lg leading-relaxed max-w-xl mb-12 md:mb-16">
              A brand is not built in a single move. It is a stack of aligned
              disciplines, layered in the right order, designed to work together
              as one cohesive growth system.
            </p>
          </ScrollReveal>

          {/* ── Interactive Folder Stack ── */}
          <div
            ref={stackRef}
            className="relative"
            style={{ perspective: '1400px' }}
          >
            {/* Central bloom behind the stack */}
            <div
              className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[400px] rounded-full pointer-events-none transition-all duration-700"
              style={{
                background: `radial-gradient(circle, ${stackLayers[hoveredLayer ?? 0].color}18 0%, transparent 65%)`,
                transition: 'background 0.6s ease',
              }}
            />

            <div className="flex flex-col items-center">
              {stackLayers.map((layer, i) => {
                const isHovered = hoveredLayer === i;
                const isAnyHovered = hoveredLayer !== null;
                const distFromHover = hoveredLayer !== null ? Math.abs(hoveredLayer - i) : 0;
                const activeBloomColor = stackLayers[hoveredLayer ?? activeLayer ?? 0].color;

                // Tightly aligned stack, only slight offsets
                // On hover, the hovered card lifts UP (-translateY) and the cards BELOW it peek out
                // by shifting DOWN slightly, creating a "peeking through" effect
                const hoverLift = isHovered ? -18 : 0;
                const peekShift = hoveredLayer !== null && i > hoveredLayer ? distFromHover * 8 : 0;
                const yOffset = hoverLift + peekShift;

                // Rotation for 3D depth, very subtle
                const rotateX = isHovered ? -4 : 2 + i * 1.2;

                // Scale, slight enlargement on hover
                const scale = isHovered ? 1.02 : 1 - i * 0.01;

                // Opacity: dim others when one is hovered
                const opacity = isAnyHovered
                  ? isHovered
                    ? 1
                    : Math.max(0.3, 1 - distFromHover * 0.2)
                  : 1;

                // Z-index: hovered on top, then reverse order
                const zIndex = isHovered ? 100 : stackLayers.length - i;

                // Tab lift, tab slides up when hovered
                const tabTranslateY = isHovered ? -4 : 0;

                // Shadow, deeper on hover
                const shadowY = isHovered ? 40 : 16;
                const shadowBlur = isHovered ? 80 : 30;
                const shadowColor = isHovered
                  ? `${activeBloomColor}20`
                  : 'rgba(0,0,0,0.4)';

                return (
                  <div
                    key={layer.id}
                    onMouseEnter={() => setHoveredLayer(i)}
                    onMouseLeave={() => setHoveredLayer(null)}
                    onClick={() => handleLayerClick(i)}
                    className="relative w-full max-w-3xl cursor-pointer will-change-transform"
                    style={{
                      transform: `translateY(${yOffset}px) rotateX(${rotateX}deg) scale(${scale})`,
                      opacity,
                      zIndex,
                      transition: 'transform 0.5s cubic-bezier(0.23, 1, 0.32, 1), opacity 0.45s ease, z-index 0s',
                      marginTop: i === 0 ? 0 : -4,
                      marginBottom: i === stackLayers.length - 1 ? 0 : -4,
                    }}
                  >
                    {/* Folder tab */}
                    <div
                      className="absolute -top-[26px] left-6 md:left-8 h-[26px] px-4 md:px-5 rounded-t-lg flex items-center gap-2 z-10"
                      style={{
                        backgroundColor: `${layer.color}18`,
                        border: `1px solid ${layer.color}45`,
                        borderBottom: 'none',
                        transform: `translateY(${tabTranslateY}px)`,
                        transition: 'transform 0.45s cubic-bezier(0.23, 1, 0.32, 1)',
                      }}
                    >
                      <i
                        className={`${layer.icon} text-sm md:text-base`}
                        style={{ color: layer.color }}
                      />
                      <span
                        className="text-[10px] md:text-xs font-bold uppercase tracking-wider"
                        style={{ color: layer.color }}
                      >
                        {layer.label}
                      </span>
                      <span
                        className="text-[10px] font-medium ml-1"
                        style={{ color: isHovered ? `${layer.color}70` : 'rgba(255,255,255,0.12)' }}
                      >
                        Layer {String(i + 1).padStart(2, '0')}
                      </span>
                    </div>

                    {/* Card body */}
                    <div
                      className="relative rounded-2xl border overflow-hidden paper-grain"
                      style={{
                        background: isHovered
                          ? `linear-gradient(145deg, rgba(255,255,255,0.07) 0%, rgba(255,255,255,0.015) 100%)`
                          : `linear-gradient(145deg, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0.01) 100%)`,
                        borderColor: isHovered
                          ? `${layer.color}55`
                          : `${layer.color}25`,
                        boxShadow: isHovered
                          ? `0 ${shadowY}px ${shadowBlur}px rgba(0,0,0,0.5), 0 0 0 1px ${layer.color}40, 0 0 60px ${layer.color}12`
                          : `0 ${shadowY}px ${shadowBlur}px ${shadowColor}, 0 0 0 1px rgba(255,255,255,0.04)`,
                        backdropFilter: 'blur(14px)',
                        transition:
                          'background 0.5s ease, border-color 0.5s ease, box-shadow 0.5s ease',
                      }}
                    >
                      {/* Paper grain */}
                      <div
                        className="absolute inset-0 pointer-events-none opacity-25 mix-blend-overlay"
                        style={{
                          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='5' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.06'/%3E%3C/svg%3E")`,
                          backgroundSize: '128px 128px',
                        }}
                      />

                      <div className="relative z-10 p-6 md:p-8 lg:p-10">
                        <div className="flex flex-col md:flex-row md:items-start gap-5 md:gap-8">
                          {/* Left: icon + number */}
                          <div className="flex-shrink-0 flex md:flex-col items-center md:items-start gap-4 md:gap-3">
                            <div
                              className="w-12 h-12 md:w-14 md:h-14 rounded-xl flex items-center justify-center transition-all duration-500"
                              style={{
                                background: isHovered
                                  ? `linear-gradient(135deg, ${layer.color}40 0%, ${layer.color}15 100%)`
                                  : `linear-gradient(135deg, ${layer.color}20 0%, ${layer.color}05 100%)`,
                                border: `1px solid ${isHovered ? `${layer.color}55` : `${layer.color}20`}`,
                              }}
                            >
                              <i
                                className={`${layer.icon} text-xl md:text-2xl`}
                                style={{ color: layer.color }}
                              />
                            </div>
                            <span
                              className="font-editorial font-black text-4xl md:text-5xl leading-none transition-colors duration-500"
                              style={{
                                color: isHovered
                                  ? `${layer.color}40`
                                  : 'rgba(255,255,255,0.06)',
                              }}
                            >
                              {String(i + 1).padStart(2, '0')}
                            </span>
                          </div>

                          {/* Right: content */}
                          <div className="flex-1">
                            <h2 className="font-editorial font-bold text-white text-xl md:text-2xl lg:text-3xl mb-3">
                              {layer.headline}
                            </h2>
                            <p className="text-white/40 text-sm md:text-base leading-relaxed mb-5 md:mb-6">
                              {layer.description}
                            </p>

                            {/* Animated item list */}
                            <ul className="space-y-2.5 md:space-y-3 mb-6">
                              {layer.items.map((item, itemIdx) => {
                                const key = i * 100 + itemIdx;
                                const isRevealed = revealedItems.includes(key);
                                return (
                                  <li
                                    key={itemIdx}
                                    className="flex items-start gap-3 transition-all duration-500"
                                    style={{
                                      opacity: isRevealed ? 1 : 0,
                                      transform: isRevealed
                                        ? 'translateX(0)'
                                        : 'translateX(-12px)',
                                    }}
                                  >
                                    <div
                                      className="w-1.5 h-1.5 rounded-full flex-shrink-0 mt-2"
                                      style={{ backgroundColor: layer.color }}
                                    />
                                    <span className="text-white/50 text-xs md:text-sm">
                                      {item}
                                    </span>
                                  </li>
                                );
                              })}
                            </ul>

                            {/* Stat badge */}
                            <div
                              className="inline-flex items-center gap-3 px-4 py-2.5 rounded-full transition-all duration-500"
                              style={{
                                backgroundColor: `${layer.color}12`,
                                border: `1px solid ${layer.color}30`,
                                opacity: isHovered ? 1 : 0.5,
                                transform: isHovered
                                  ? 'translateY(0)'
                                  : 'translateY(4px)',
                              }}
                            >
                              <span
                                className="font-editorial font-black text-lg"
                                style={{ color: layer.color }}
                              >
                                {layer.stat}
                              </span>
                              <span className="text-white/30 text-xs">
                                {layer.statLabel}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Shadow base under the stack */}
            <div
              className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-[320px] h-[24px] rounded-full pointer-events-none"
              style={{
                background:
                  'radial-gradient(ellipse, rgba(124,58,237,0.15) 0%, transparent 70%)',
                filter: 'blur(14px)',
              }}
            />
          </div>

          {/* Scroll hint */}
          <ScrollReveal direction="up" delay={300}>
            <p className="text-center text-white/20 text-xs mt-10 md:mt-14 tracking-wider">
              Hover to peek into a layer. Click to explore deeper.
            </p>
          </ScrollReveal>
        </div>
      </section>

      {/* ── Deep Dive Sections ── */}
      {stackLayers.map((layer, i) => (
        <section
          key={layer.id}
          ref={(el) => { sectionRefs.current[i] = el; }}
          className={`relative py-16 md:py-24 lg:py-28 ${i % 2 === 0 ? 'bg-[#0C0B11]' : 'bg-[#08080C]'}`}
        >
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <div
              className="absolute top-0 right-0 w-[500px] h-[400px] rounded-full blur-3xl"
              style={{ backgroundColor: `${layer.color}06` }}
            />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-8 lg:px-16">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
              {/* Left: folder graphic */}
              <ScrollReveal direction="up" delay={0}>
                <div className="relative">
                  <div
                    className="relative rounded-2xl border overflow-hidden paper-grain"
                    style={{
                      background:
                        'linear-gradient(145deg, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0.01) 100%)',
                      borderColor: `${layer.color}30`,
                      boxShadow: `0 20px 60px rgba(0,0,0,0.4), 0 0 0 1px ${layer.color}25`,
                    }}
                  >
                    <div
                      className="absolute inset-0 pointer-events-none opacity-20 mix-blend-overlay"
                      style={{
                        backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='5' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.06'/%3E%3C/svg%3E")`,
                        backgroundSize: '128px 128px',
                      }}
                    />

                    <div
                      className="absolute -top-[26px] left-6 h-[26px] px-4 rounded-t-lg flex items-center gap-2"
                      style={{
                        backgroundColor: `${layer.color}18`,
                        border: `1px solid ${layer.color}40`,
                        borderBottom: 'none',
                      }}
                    >
                      <i
                        className={`${layer.icon} text-sm`}
                        style={{ color: layer.color }}
                      />
                      <span
                        className="text-xs font-bold uppercase tracking-wider"
                        style={{ color: layer.color }}
                      >
                        {layer.label}
                      </span>
                    </div>

                    <div className="relative z-10 p-8 md:p-12">
                      <div className="flex items-center gap-2 mb-8">
                        <div className="flex-1 h-px bg-white/[0.06]" />
                        <div
                          className="w-10 h-1 rounded-full"
                          style={{ backgroundColor: layer.color }}
                        />
                      </div>

                      <div
                        className="font-editorial font-black text-7xl md:text-8xl lg:text-9xl leading-none mb-4"
                        style={{ color: `${layer.color}12` }}
                      >
                        {String(i + 1).padStart(2, '0')}
                      </div>

                      <div
                        className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6"
                        style={{
                          background: `linear-gradient(135deg, ${layer.color}25 0%, ${layer.color}10 100%)`,
                          border: `1px solid ${layer.color}30`,
                        }}
                      >
                        <i
                          className={`${layer.icon} text-2xl md:text-3xl`}
                          style={{ color: layer.color }}
                        />
                      </div>

                      <div className="flex items-end gap-3">
                        <span
                          className="font-editorial font-black text-4xl md:text-5xl"
                          style={{ color: layer.color }}
                        >
                          {layer.stat}
                        </span>
                        <span className="text-white/25 text-sm mb-1.5">
                          {layer.statLabel}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Decorative mini cards behind */}
                  {i > 0 && (
                    <div
                      className="absolute -bottom-3 -right-3 w-full h-full rounded-2xl border pointer-events-none"
                      style={{
                        background:
                          'linear-gradient(145deg, rgba(255,255,255,0.02) 0%, rgba(255,255,255,0.005) 100%)',
                        borderColor: `${stackLayers[i - 1].color}12`,
                        zIndex: -1,
                      }}
                    />
                  )}
                  {i > 1 && (
                    <div
                      className="absolute -bottom-6 -right-6 w-full h-full rounded-2xl border pointer-events-none"
                      style={{
                        background:
                          'linear-gradient(145deg, rgba(255,255,255,0.015) 0%, rgba(255,255,255,0.003) 100%)',
                        borderColor: `${stackLayers[i - 2].color}08`,
                        zIndex: -2,
                      }}
                    />
                  )}
                </div>
              </ScrollReveal>

              {/* Right: detail text */}
              <div>
                <ScrollReveal direction="up" delay={60}>
                  <div className="flex items-center gap-3 mb-5">
                    <div className="w-8 h-px" style={{ backgroundColor: layer.color }} />
                    <span
                      className="text-[10px] md:text-xs font-semibold uppercase tracking-[0.2em]"
                      style={{ color: layer.color }}
                    >
                      Layer {String(i + 1).padStart(2, '0')} / {layer.label}
                    </span>
                  </div>
                </ScrollReveal>

                <ScrollReveal direction="up" delay={100}>
                  <h2
                    className="font-editorial font-black text-white leading-tight mb-5 md:mb-6"
                    style={{ fontSize: 'clamp(1.8rem, 4vw, 3rem)' }}
                  >
                    {layer.headline}
                  </h2>
                </ScrollReveal>

                <ScrollReveal direction="up" delay={140}>
                  <p className="text-white/40 text-sm md:text-base leading-relaxed mb-8">
                    {layer.description}
                  </p>
                </ScrollReveal>

                <ScrollReveal direction="up" delay={180}>
                  <div className="space-y-3">
                    {layer.items.map((item, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-4 p-4 rounded-xl transition-all duration-300 hover:bg-white/[0.03] group"
                        style={{
                          border: '1px solid rgba(255,255,255,0.05)',
                        }}
                      >
                        <div
                          className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 transition-all duration-300 group-hover:scale-110"
                          style={{
                            background: `linear-gradient(135deg, ${layer.color}15 0%, ${layer.color}05 100%)`,
                            border: `1px solid ${layer.color}20`,
                          }}
                        >
                          <i
                            className="ri-check-line text-sm"
                            style={{ color: layer.color }}
                          />
                        </div>
                        <span className="text-white/55 text-sm md:text-base font-medium leading-relaxed">
                          {item}
                        </span>
                      </div>
                    ))}
                  </div>
                </ScrollReveal>

                {i < stackLayers.length - 1 && (
                  <ScrollReveal direction="up" delay={220}>
                    <div className="mt-8 md:mt-10">
                      <button
                        onClick={() => handleLayerClick(i + 1)}
                        className="inline-flex items-center gap-2 text-sm font-semibold transition-all duration-300 hover:gap-4 cursor-pointer whitespace-nowrap"
                        style={{ color: layer.color }}
                      >
                        <span>Next Layer: {stackLayers[i + 1].label}</span>
                        <i className="ri-arrow-down-line text-lg" />
                      </button>
                    </div>
                  </ScrollReveal>
                )}
              </div>
            </div>
          </div>
        </section>
      ))}

      {/* ── Summary: The Complete Stack ── */}
      <section className="relative py-20 md:py-28 lg:py-36 bg-[#0C0B11] overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-[#7C3AED]/[0.05] rounded-full blur-3xl" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-8 lg:px-16 text-center">
          <ScrollReveal direction="up">
            <div className="flex items-center justify-center gap-3 mb-5 md:mb-6">
              <div className="w-8 md:w-10 h-px bg-[#7C3AED]" />
              <span className="text-[#a855f7] text-[10px] md:text-xs font-semibold uppercase tracking-[0.2em]">
                The Full Stack
              </span>
              <div className="w-8 md:w-10 h-px bg-[#7C3AED]" />
            </div>
          </ScrollReveal>

          <ScrollReveal direction="up" delay={80}>
            <h2
              className="font-editorial font-black text-white leading-[0.95] mb-6 md:mb-8"
              style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}
            >
              Four Layers.{" "}
              <span
                className="italic"
                style={{
                  background:
                    'linear-gradient(135deg, #6b21a8 0%, #7C3AED 60%, #a855f7 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              >
                One Outcome.
              </span>
            </h2>
          </ScrollReveal>

          <ScrollReveal direction="up" delay={160}>
            <p className="text-white/35 text-sm md:text-base leading-relaxed max-w-2xl mx-auto mb-12 md:mb-16">
              When Ideas, Strategy, Execution, and Creativity are stacked in the
              right order, the result is not just a brand. It is a growth system.
            </p>
          </ScrollReveal>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5 max-w-5xl mx-auto">
            {stackLayers.map((layer, i) => (
              <ScrollReveal key={layer.id} direction="up" delay={i * 100}>
                <div
                  className="relative rounded-xl border overflow-hidden paper-grain p-5 md:p-6 text-left transition-all duration-300 hover:border-opacity-60 group"
                  style={{
                    background:
                      'linear-gradient(145deg, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0.01) 100%)',
                    borderColor: `${layer.color}25`,
                    boxShadow: '0 8px 30px rgba(0,0,0,0.3)',
                  }}
                >
                  <div
                    className="absolute inset-0 pointer-events-none opacity-20 mix-blend-overlay"
                    style={{
                      backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='5' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.06'/%3E%3C/svg%3E")`,
                      backgroundSize: '128px 128px',
                    }}
                  />

                  <div className="relative z-10">
                    <div className="flex items-center gap-2 mb-3">
                      <i
                        className={`${layer.icon} text-sm md:text-base`}
                        style={{ color: layer.color }}
                      />
                      <span
                        className="text-[10px] font-bold uppercase tracking-wider"
                        style={{ color: layer.color }}
                      >
                        {layer.label}
                      </span>
                    </div>
                    <span
                      className="font-editorial font-black text-3xl md:text-4xl"
                      style={{ color: `${layer.color}20` }}
                    >
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <p className="text-white/40 text-xs md:text-sm mt-3 leading-relaxed">
                      {layer.description.slice(0, 80)}...
                    </p>
                  </div>

                  <div
                    className="absolute bottom-0 left-0 right-0 h-1 rounded-b-xl transition-all duration-300 group-hover:h-1.5"
                    style={{ backgroundColor: `${layer.color}30` }}
                  />
                </div>
              </ScrollReveal>
            ))}
          </div>

          <ScrollReveal direction="up" delay={400}>
            <div className="mt-12 md:mt-16">
              <button
                onClick={() => {
                  if (typeof window !== 'undefined' && typeof (window as any).REACT_APP_NAVIGATE === 'function') {
                    (window as any).REACT_APP_NAVIGATE('/book');
                  }
                }}
                className="inline-flex items-center gap-3 text-white font-semibold py-3.5 md:py-4 px-8 md:px-10 text-sm md:text-base rounded-full hover:opacity-90 transition-all duration-300 hover:scale-105 whitespace-nowrap cursor-pointer"
                style={{
                  background:
                    'linear-gradient(135deg, #6b21a8 0%, #7C3AED 60%, #a855f7 100%)',
                  boxShadow: '0 4px 32px rgba(124,58,237,0.4)',
                }}
              >
                <span>Start Building Your Stack</span>
                <i className="ri-arrow-right-line text-lg" />
              </button>
            </div>
          </ScrollReveal>
        </div>
      </section>

      <Footer />
    </div>
  );
}