import { useState, useEffect } from 'react';
import Navbar from '../home/components/Navbar';
import Footer from '../home/components/Footer';
import ScrollReveal from '../../components/feature/ScrollReveal';
import DustParticles from '../../components/feature/DustParticles';

const retainerTiers = [
  {
    id: 'gtm',
    anchor: 'gtm-launchpad',
    name: 'GTM Launchpad Retainer',
    headline: 'Make the First Move Count.',
    description: 'Launch strategy built around positioning, messaging, and channel sequencing. For brands entering the market or relaunching, giving them clarity, confidence, and a roadmap that turns launch into momentum.',
    monthlyPrice: 'NGN 1,000,000',
    setupFee: 'NGN 250,000',
    icon: 'ri-rocket-line',
    color: '#7C3AED',
    gradient: 'from-[#6b21a8] via-[#7C3AED] to-[#8b5cf6]',
    strategy: [
      'Target audience definition and research',
      'Brand positioning strategy',
      'Messaging framework development',
      'Strategic roadmap, sign-off before execution starts',
    ],
    brand: [
      'Logo and mark (new or refinement)',
      'Basic visual system (colors, type, core templates)',
    ],
    digital: [
      '5-page website',
      'Google Business setup, basic SEO/analytics',
    ],
    content: [
      'Channel strategy and selection',
      'Social media content (copy + design)',
      '30-day content plan, monthly calendar',
    ],
    performance: [
      'One core paid channel (single campaign focus)',
      'Basic conversion tracking setup',
    ],
    data: [
      'Monthly performance report + one strategy call',
    ],
    bestFor: 'New businesses, product launches, service launches, brand relaunches.',
  },
  {
    id: 'seg-growth',
    anchor: 'seg-growth',
    name: 'SEG Growth Retainer',
    headline: 'Control the Board. Control the Outcome.',
    description: 'Strategy + Execution = Growth. Full marketing strategy plus execution support plus performance refinement. For brands ready to scale with strategic clarity and consistent execution.',
    monthlyPrice: 'NGN 1,750,000',
    setupFee: 'NGN 437,500',
    icon: 'ri-line-chart-line',
    color: '#9333ea',
    gradient: 'from-[#7C3AED] via-[#9333ea] to-[#a855f7]',
    strategy: [
      'Full marketing strategy development',
      'Market and competitor positioning',
      'Messaging framework',
      'Bi-weekly strategy calls',
    ],
    brand: [
      'Full brand identity system',
      'Guidelines and asset library',
    ],
    digital: [
      '10-15 page website',
      'CMS for blogs/listings',
      'SEO foundation built out',
    ],
    content: [
      'Full content production across channels (copy, design, short-form video direction)',
      'Professional copywriting',
      'Community management',
      'Campaign direction and creative oversight',
    ],
    performance: [
      'Multi-channel paid (Google + Meta minimum)',
      'Lead funnels built and tracked',
      'Email marketing integrated with campaigns',
    ],
    data: [
      'Competitor and market monitoring built into reporting',
      'Campaign-level performance tracking and refinement',
    ],
    bestFor: 'Growing brands, businesses feeling scattered, companies stuck in inconsistent growth.',
  },
  {
    id: 'seg-full',
    anchor: 'seg-full',
    name: 'SEG Full Scale Retainer',
    subtitle: 'Fractional CMO',
    headline: 'Calculated Moves. Measurable Wins.',
    description: 'Everything in SEG Growth, delivered at embedded, always-on intensity, plus full-funnel performance marketing engineered for ROI. For brands ready to scale with measurable returns and a strategic partner thinking about the business, not just the marketing.',
    monthlyPrice: 'NGN 3,000,000',
    setupFee: 'NGN 750,000',
    icon: 'ri-vip-crown-line',
    color: '#a855f7',
    gradient: 'from-[#9333ea] via-[#a855f7] to-[#c084fc]',
    strategy: [
      'Full brand strategy, weekly strategic involvement across the business',
      'Cross-functional input (positioning, partnerships, team structure where relevant)',
      'Budget and spend advisory',
    ],
    brand: [
      'Premium identity and campaign system, ongoing evolution',
      'Art direction for photo/film, style frameworks',
    ],
    digital: [
      'High-performance website, built for conversion, not just presence',
      'Ongoing UX/CRO iteration',
    ],
    content: [
      'Full creative direction across every touchpoint',
      'Social and content engine, always-on production',
    ],
    performance: [
      'Lead generation campaigns across all channels',
      'Conversion optimization, app install campaigns where relevant',
      'Sales growth initiatives',
      'Funnel automation',
      'ROI tracking and reporting, continuous, not monthly snapshot',
    ],
    data: [
      'Reporting and optimization as a continuous loop',
      'Priority turnaround on all requests',
    ],
    bestFor: 'Brands ready to scale with measurable ROI, businesses with proven product-market fit, founders who want a strategic partner embedded in the business.',
  },
];

const categoryLabels: Record<string, string> = {
  strategy: 'Strategy',
  brand: 'Brand & Identity',
  digital: 'Digital',
  content: 'Content & Social',
  performance: 'Performance Marketing',
  data: 'Data & Reporting',
};

const categoryIcons: Record<string, string> = {
  strategy: 'ri-lightbulb-line',
  brand: 'ri-palette-line',
  digital: 'ri-code-s-slash-line',
  content: 'ri-camera-lens-line',
  performance: 'ri-bar-chart-grouped-line',
  data: 'ri-pie-chart-line',
};

const quickRef = [
  { offer: 'Marketing Audit', price: 'NGN 200,000', commitment: 'One-time' },
  { offer: 'GTM Launchpad Retainer', price: 'NGN 1,000,000/mo + NGN 250,000 setup', commitment: '4 months min' },
  { offer: 'SEG Growth Retainer', price: 'NGN 1,750,000/mo + NGN 437,500 setup', commitment: '4 months min' },
  { offer: 'SEG Full Scale Retainer', price: 'NGN 3,000,000/mo + NGN 750,000 setup', commitment: '4 months min' },
];

const PricingPage = () => {
  const [activeTier, setActiveTier] = useState<string | null>(null);

  const safeNavigate = (path: string) => {
    if (typeof window !== 'undefined' && typeof (window as any).REACT_APP_NAVIGATE === 'function') {
      (window as any).REACT_APP_NAVIGATE(path);
    }
  };

  useEffect(() => {
    const hash = window.location.hash;
    if (hash) {
      setTimeout(() => {
        const el = document.querySelector(hash);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 400);
    }
  }, []);

  return (
    <div className="min-h-screen bg-[#0C0B11]">
      <Navbar />

      {/* ===== HERO ===== */}
      <section className="relative pt-40 pb-24 overflow-hidden">
        <DustParticles />
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[450px] bg-[#7C3AED]/[0.08] rounded-full blur-3xl" />
          <div
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage: `linear-gradient(to right, #fff 1px, transparent 1px), linear-gradient(to bottom, #fff 1px, transparent 1px)`,
              backgroundSize: '60px 60px',
            }}
          />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 lg:px-16">
          <div className="text-center max-w-4xl mx-auto">
            <ScrollReveal direction="up">
              <div className="flex items-center justify-center gap-3 mb-6">
                <div className="w-10 h-px bg-[#7C3AED]" />
                <span className="text-[#a855f7] text-xs font-semibold uppercase tracking-[0.2em]">Pricing</span>
                <div className="w-10 h-px bg-[#7C3AED]" />
              </div>
            </ScrollReveal>

            <ScrollReveal direction="up" delay={80}>
              <h1
                className="font-editorial font-black leading-[0.95] tracking-tight text-white mb-6"
                style={{ fontSize: 'clamp(3rem, 7vw, 6rem)' }}
              >
                Services &{' '}
                <span
                  className="italic"
                  style={{
                    background: 'linear-gradient(135deg, #6b21a8 0%, #7C3AED 60%, #a855f7 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                  }}
                >
                  Pricing
                </span>
              </h1>
            </ScrollReveal>

            <ScrollReveal direction="up" delay={160}>
              <p className="text-lg text-white/35 leading-relaxed max-w-2xl mx-auto">
                Strategic Marketing That Moves Markets
              </p>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* ===== MARKETING AUDIT: ENTRY OFFER ===== */}
      <section className="relative py-8 bg-[#0C0B11]">
        <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 lg:px-16">
          <ScrollReveal direction="up">
            <div className="text-center mb-12">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#7C3AED]/10 border border-[#7C3AED]/20 mb-5">
                <i className="ri-search-line text-sm text-[#a855f7]" />
                <span className="text-[#a855f7] text-xs font-semibold uppercase tracking-[0.15em]">Entry Offer</span>
              </div>
            </div>
          </ScrollReveal>

          <ScrollReveal direction="up" delay={40}>
            <div
              className="relative rounded-3xl border border-white/[0.06] overflow-hidden max-w-4xl mx-auto"
              style={{
                background: 'linear-gradient(145deg, rgba(124,58,237,0.06) 0%, rgba(124,58,237,0.01) 100%)',
              }}
            >
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#6b21a8] via-[#7C3AED] to-[#a855f7]" />

              <div className="p-8 lg:p-12">
                <div className="flex flex-col lg:flex-row gap-8 lg:gap-12">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-11 h-11 rounded-xl flex items-center justify-center"
                        style={{ background: 'linear-gradient(135deg, #7C3AED25, #7C3AED08)', border: '1px solid #7C3AED30' }}>
                        <i className="ri-search-line text-lg text-[#a855f7]" />
                      </div>
                      <div>
                        <h2 className="font-editorial font-black text-white text-2xl">Marketing Audit</h2>
                        <p className="text-white/40 text-sm italic mt-0.5">&ldquo;Clarity Before the Next Move.&rdquo;</p>
                      </div>
                    </div>

                    <p className="text-white/50 text-sm leading-relaxed mb-6">
                      For brands not ready to commit to a retainer but who need clarity before deciding what&apos;s next.
                      This is also the discovery phase every retainer client goes through, offered standalone for prospects
                      who want to see how we think before they commit.
                    </p>

                    <div className="space-y-3">
                      {[
                        'Comprehensive marketing review',
                        'Performance analysis and insights',
                        'Gap identification and diagnosis',
                        'Actionable recommendations',
                        'Priority roadmap for improvements',
                      ].map((item, i) => (
                        <div key={i} className="flex items-start gap-3">
                          <div className="flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center mt-0.5"
                            style={{ background: 'linear-gradient(135deg, #7C3AED60, #a855f7)' }}>
                            <i className="ri-check-line text-white text-[10px]" />
                          </div>
                          <span className="text-white/45 text-sm">{item}</span>
                        </div>
                      ))}
                    </div>

                    <div className="mt-6 p-4 rounded-xl border border-[#7C3AED]/15" style={{ background: '#7C3AED08' }}>
                      <div className="flex items-start gap-2.5">
                        <i className="ri-star-fill text-sm mt-0.5 text-[#a855f7]" />
                        <div>
                          <span className="font-bold text-white/60 text-[10px] uppercase tracking-wider">Best For: </span>
                          <span className="text-white/35 text-xs">Brands stuck at a plateau, founders or CEOs confused about performance, teams needing direction before committing to a full engagement.</span>
                        </div>
                      </div>
                    </div>

                    {/* CTA Buttons */}
                    <div className="mt-8 flex flex-wrap gap-3">
                      <button
                        onClick={() => safeNavigate('/book')}
                        className="inline-flex items-center gap-2 px-6 py-3 text-white text-sm font-semibold rounded-full hover:opacity-90 transition-all duration-300 hover:scale-105 whitespace-nowrap cursor-pointer"
                        style={{
                          background: 'linear-gradient(135deg, #6b21a8 0%, #7C3AED 60%, #a855f7 100%)',
                          boxShadow: '0 4px 20px rgba(124,58,237,0.35)',
                        }}
                      >
                        <i className="ri-calendar-check-line" />
                        Book Discovery Call
                      </button>
                      <button
                        onClick={() => safeNavigate('/contact')}
                        className="inline-flex items-center gap-2 px-6 py-3 border border-white/[0.12] text-white/60 text-sm font-semibold rounded-full hover:border-[#7C3AED]/40 hover:text-white/90 transition-all duration-300 whitespace-nowrap cursor-pointer"
                      >
                        <i className="ri-mail-send-line" />
                        Send Brand Brief
                      </button>
                    </div>
                  </div>

                  <div className="lg:w-[280px] flex-shrink-0">
                    <div className="rounded-2xl border border-white/[0.06] p-6 text-center h-full flex flex-col justify-center"
                      style={{ background: 'linear-gradient(180deg, rgba(124,58,237,0.08) 0%, rgba(124,58,237,0.02) 100%)' }}>
                      <span className="text-white/30 text-xs uppercase tracking-widest mb-2">Price</span>
                      <div className="font-editorial font-black text-white text-4xl mb-1">NGN 200,000</div>
                      <span className="text-white/30 text-xs">One-time</span>

                      <div className="mt-5 pt-5 border-t border-white/[0.05]">
                        <div className="flex items-start gap-2 text-left">
                          <i className="ri-information-line text-sm mt-0.5 text-[#a855f7]/60" />
                          <p className="text-white/30 text-xs leading-relaxed">
                            If the client signs a retainer within 30 days of the audit, the audit fee is credited toward their setup fee.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* ===== RETAINER TIERS ===== */}
      <section className="relative py-16 bg-[#0D0B14]">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 right-0 w-[500px] h-[500px] bg-[#7C3AED]/[0.04] rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 left-0 w-[400px] h-[400px] bg-[#a855f7]/[0.03] rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 lg:px-16">
          <ScrollReveal direction="up">
            <div className="text-center mb-4">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#7C3AED]/10 border border-[#7C3AED]/20 mb-5">
                <i className="ri-stack-line text-sm text-[#a855f7]" />
                <span className="text-[#a855f7] text-xs font-semibold uppercase tracking-[0.15em]">Retainer Tiers</span>
              </div>
              <h2 className="font-editorial font-black text-white text-3xl lg:text-4xl mb-3">
                Every Tier Runs on the Same System
              </h2>
              <p className="text-white/35 text-sm max-w-2xl mx-auto leading-relaxed">
                Strategy, Brand & Identity, Digital, Content & Social, Performance Marketing, and Data & Reporting.
                What changes is depth and involvement, not what&apos;s included. All retainers require a 4-month minimum commitment.
              </p>
            </div>
          </ScrollReveal>

          <div className="space-y-8 mt-12">
            {retainerTiers.map((tier, index) => {
              const isActive = activeTier === tier.id;
              const categories = ['strategy', 'brand', 'digital', 'content', 'performance', 'data'] as const;

              return (
                <ScrollReveal key={tier.id} direction="up" delay={index * 80}>
                  <div
                    id={tier.anchor}
                    onMouseEnter={() => setActiveTier(tier.id)}
                    onMouseLeave={() => setActiveTier(null)}
                    className="relative rounded-3xl border border-white/[0.06] overflow-hidden transition-all duration-500"
                    style={{
                      background: isActive
                        ? 'linear-gradient(145deg, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0.01) 100%)'
                        : 'linear-gradient(145deg, rgba(255,255,255,0.02) 0%, rgba(255,255,255,0.005) 100%)',
                      transform: isActive ? 'translateY(-4px)' : 'translateY(0)',
                      boxShadow: isActive
                        ? `0 20px 60px -8px ${tier.color}18, 0 4px 20px -4px rgba(0,0,0,0.3)`
                        : '0 2px 12px -2px rgba(0,0,0,0.15)',
                    }}
                  >
                    {/* Top accent bar */}
                    <div className={`h-1 w-full bg-gradient-to-r ${tier.gradient}`} />

                    <div className="p-8 lg:p-10">
                      {/* Header */}
                      <div className="flex flex-col lg:flex-row lg:items-start gap-6 lg:gap-10 mb-8">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-3">
                            <div className="w-12 h-12 rounded-xl flex items-center justify-center"
                              style={{ background: `linear-gradient(135deg, ${tier.color}25, ${tier.color}08)`, border: `1px solid ${tier.color}30` }}>
                              <i className={`${tier.icon} text-xl`} style={{ color: tier.color }} />
                            </div>
                            <div>
                              <div className="flex items-center gap-2 flex-wrap">
                                <h3 className="font-editorial font-black text-white text-xl lg:text-2xl">
                                  TIER {index + 1}: {tier.name}
                                </h3>
                              </div>
                              {tier.subtitle && (
                                <span className="text-[#a855f7] font-semibold text-xs uppercase tracking-wider">{tier.subtitle}</span>
                              )}
                            </div>
                          </div>

                          <p className="font-editorial font-bold text-white/60 text-lg mb-1">&ldquo;{tier.headline}&rdquo;</p>
                          <p className="text-white/40 text-sm leading-relaxed">{tier.description}</p>
                        </div>

                        {/* Price card */}
                        <div className="lg:w-[260px] flex-shrink-0">
                          <div className="rounded-2xl border border-white/[0.06] p-5 text-center"
                            style={{ background: `linear-gradient(180deg, ${tier.color}14 0%, ${tier.color}04 100%)` }}>
                            <span className="text-white/30 text-[10px] uppercase tracking-widest">Monthly</span>
                            <div className="font-editorial font-black text-white text-3xl mt-1">{tier.monthlyPrice}</div>
                            <span className="text-white/25 text-xs">/ month</span>

                            <div className="mt-3 pt-3 border-t border-white/[0.05]">
                              <span className="text-white/25 text-[10px] uppercase tracking-widest">Setup Fee</span>
                              <div className="font-editorial font-bold text-white/60 text-lg">{tier.setupFee}</div>
                              <span className="text-white/20 text-[10px] italic">one-time fee</span>
                            </div>

                            <div className="mt-3 pt-3 border-t border-white/[0.05]">
                              <span className="text-white/25 text-xs">4-month minimum</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Category grid */}
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {categories.map((cat) => {
                          const items = (tier as any)[cat] as string[];
                          return (
                            <div key={cat}
                              className="rounded-xl p-5 border transition-colors duration-300"
                              style={{
                                borderColor: isActive ? `${tier.color}25` : 'rgba(255,255,255,0.04)',
                                background: isActive ? `${tier.color}06` : 'transparent',
                              }}>
                              <div className="flex items-center gap-2 mb-3">
                                <div className="w-7 h-7 rounded-lg flex items-center justify-center"
                                  style={{ background: `${tier.color}18` }}>
                                  <i className={`${categoryIcons[cat]} text-xs`} style={{ color: tier.color }} />
                                </div>
                                <span className="text-white/55 font-semibold text-xs uppercase tracking-wider">{categoryLabels[cat]}</span>
                              </div>
                              <ul className="space-y-1.5">
                                {items.map((item: string, i: number) => (
                                  <li key={i} className="flex items-start gap-2">
                                    <span className="text-white/20 text-[10px] mt-1">&#x2022;</span>
                                    <span className="text-white/35 text-xs leading-relaxed">{item}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          );
                        })}
                      </div>

                      {/* Best for */}
                      <div className="mt-6 p-4 rounded-xl border"
                        style={{ borderColor: `${tier.color}18`, background: `${tier.color}06` }}>
                        <div className="flex items-start gap-2.5">
                          <i className="ri-star-fill text-sm mt-0.5 flex-shrink-0" style={{ color: tier.color }} />
                          <div>
                            <span className="font-bold text-white/60 text-[10px] uppercase tracking-wider">Best For: </span>
                            <span className="text-white/35 text-xs">{tier.bestFor}</span>
                          </div>
                        </div>
                      </div>

                      {/* CTA Buttons */}
                      <div className="mt-6 flex flex-wrap gap-3">
                        <button
                          onClick={() => safeNavigate('/book')}
                          className="inline-flex items-center gap-2 px-5 py-2.5 text-white text-sm font-semibold rounded-full hover:opacity-90 transition-all duration-300 hover:scale-105 whitespace-nowrap cursor-pointer"
                          style={{
                            background: `linear-gradient(135deg, ${tier.color}80 0%, ${tier.color} 100%)`,
                            boxShadow: `0 4px 16px ${tier.color}30`,
                          }}
                        >
                          <i className="ri-calendar-check-line" />
                          Book Discovery Call
                        </button>
                        <button
                          onClick={() => safeNavigate('/contact')}
                          className="inline-flex items-center gap-2 px-5 py-2.5 border border-white/[0.12] text-white/60 text-sm font-semibold rounded-full hover:border-[#7C3AED]/40 hover:text-white/90 transition-all duration-300 whitespace-nowrap cursor-pointer"
                        >
                          <i className="ri-mail-send-line" />
                          Send Brand Brief
                        </button>
                      </div>
                    </div>
                  </div>
                </ScrollReveal>
              );
            })}
          </div>
        </div>
      </section>

      {/* ===== QUICK REFERENCE TABLE ===== */}
      <section className="relative py-16 bg-[#0C0B11]">
        <div className="relative z-10 max-w-4xl mx-auto px-6 md:px-10 lg:px-16">
          <ScrollReveal direction="up">
            <div className="text-center mb-10">
              <h2 className="font-editorial font-black text-white text-2xl lg:text-3xl mb-2">Quick Reference</h2>
              <p className="text-white/30 text-sm">All pricing and commitment details at a glance.</p>
            </div>
          </ScrollReveal>

          <ScrollReveal direction="up" delay={60}>
            <div className="rounded-2xl border border-white/[0.06] overflow-hidden"
              style={{ background: 'linear-gradient(145deg, rgba(255,255,255,0.025) 0%, rgba(255,255,255,0.008) 100%)' }}>
              {/* Header row */}
              <div className="grid grid-cols-3 px-6 py-4 border-b border-white/[0.04]"
                style={{ background: 'rgba(124,58,237,0.06)' }}>
                <span className="text-[#a855f7] text-xs font-semibold uppercase tracking-wider">Offer</span>
                <span className="text-[#a855f7] text-xs font-semibold uppercase tracking-wider">Price</span>
                <span className="text-[#a855f7] text-xs font-semibold uppercase tracking-wider text-right">Commitment</span>
              </div>

              {quickRef.map((row, i) => (
                <div key={i}
                  className={`grid grid-cols-3 px-6 py-4 transition-colors duration-200 ${
                    i !== quickRef.length - 1 ? 'border-b border-white/[0.03]' : ''
                  }`}
                  style={{ background: i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.01)' }}>
                  <span className="text-white/60 text-sm font-medium">{row.offer}</span>
                  <span className="text-white/40 text-sm">{row.price}</span>
                  <span className="text-white/30 text-sm text-right">{row.commitment}</span>
                </div>
              ))}
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* ===== BOTTOM CTA ===== */}
      <section className="relative py-24 bg-[#0D0B14] overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-[#7C3AED]/[0.08] rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-6 md:px-10 lg:px-16 text-center">
          <ScrollReveal direction="up">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-[#7C3AED]/10 mb-8 border border-[#7C3AED]/20">
              <i className="ri-question-line text-2xl text-[#a855f7]" />
            </div>

            <h2
              className="font-editorial font-black text-white mb-6 leading-[0.95]"
              style={{ fontSize: 'clamp(2.2rem, 4vw, 3.5rem)' }}
            >
              Not Sure Which Tier<br />
              <span
                className="italic"
                style={{
                  background: 'linear-gradient(135deg, #6b21a8 0%, #7C3AED 60%, #a855f7 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              >
                Is Right for You?
              </span>
            </h2>

            <p className="text-base text-white/40 mb-10 leading-relaxed max-w-2xl mx-auto">
              Book a discovery call and we will assess your stage, understand your goals, and recommend the perfect tier to move your brand forward.
            </p>

            <button
              onClick={() => safeNavigate('/book')}
              className="inline-flex items-center gap-3 text-white font-semibold py-4 px-10 rounded-full hover:opacity-90 transition-all duration-300 hover:scale-105 whitespace-nowrap cursor-pointer"
              style={{
                background: 'linear-gradient(135deg, #6b21a8 0%, #7C3AED 60%, #a855f7 100%)',
                boxShadow: '0 4px 24px rgba(124,58,237,0.35)',
              }}
            >
              <span>Book Your Discovery Call</span>
              <i className="ri-arrow-right-line text-lg" />
            </button>

            <p className="text-white/20 mt-6 text-sm">
              Free 30-minute consultation. No commitment required.
            </p>
          </ScrollReveal>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default PricingPage;