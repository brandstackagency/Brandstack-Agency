import { useState, useRef, useEffect } from 'react';
import Navbar from '../home/components/Navbar';

interface MediaItem {
  id: string;
  type: 'image' | 'video';
  url: string;
  name: string;
  size: number;
  assignedSection: string;
  uploadedAt: number;
}

const SECTION_OPTIONS = [
  { value: '', label: 'Unassigned' },
  { value: 'hero', label: 'Hero Section' },
  { value: 'logo', label: 'Site Logo' },
  { value: 'who-we-are', label: 'Who We Are' },
  { value: 'philosophy', label: 'Philosophy' },
  { value: 'project-ridima', label: 'Project: Ridima' },
  { value: 'project-announce-africa', label: 'Project: Announce Africa' },
  { value: 'project-jazzy-burger', label: 'Project: Jazzy Burger' },
  { value: 'project-elite-stans', label: 'Project: Elite Stans' },
  { value: 'client-logo-1', label: 'Client Logo 1' },
  { value: 'client-logo-2', label: 'Client Logo 2' },
  { value: 'client-logo-3', label: 'Client Logo 3' },
  { value: 'client-logo-4', label: 'Client Logo 4' },
  { value: 'client-logo-5', label: 'Client Logo 5' },
  { value: 'testimonial-1', label: 'Testimonial 1' },
  { value: 'testimonial-2', label: 'Testimonial 2' },
  { value: 'testimonial-3', label: 'Testimonial 3' },
];

export default function UploadPage() {
  const [activeTab, setActiveTab] = useState<'images' | 'videos'>('images');
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSection, setFilterSection] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load media items from localStorage
  useEffect(() => {
    const stored = localStorage.getItem('mediaManager');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setMediaItems(parsed);
      } catch (e) {
        console.error('Failed to parse media items:', e);
      }
    }
  }, []);

  // Save media items to localStorage
  useEffect(() => {
    if (mediaItems.length > 0) {
      localStorage.setItem('mediaManager', JSON.stringify(mediaItems));
    }
  }, [mediaItems]);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files);
    processFiles(files);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      processFiles(files);
    }
  };

  const processFiles = (files: File[]) => {
    const validFiles = files.filter((file) => {
      if (activeTab === 'images') {
        return file.type.startsWith('image/');
      } else {
        return file.type.startsWith('video/');
      }
    });

    const newItems: MediaItem[] = validFiles.map((file) => ({
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: activeTab,
      url: URL.createObjectURL(file),
      name: file.name,
      size: file.size,
      assignedSection: '',
      uploadedAt: Date.now(),
    }));

    setMediaItems((prev) => [...newItems, ...prev]);
  };

  const handleSectionChange = (itemId: string, section: string) => {
    setMediaItems((prev) =>
      prev.map((item) =>
        item.id === itemId ? { ...item, assignedSection: section } : item
      )
    );
  };

  const handleCopyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    // Could add a toast notification here
  };

  const handleRemoveItem = (itemId: string) => {
    setMediaItems((prev) => prev.filter((item) => item.id !== itemId));
    setSelectedItems((prev) => {
      const newSet = new Set(prev);
      newSet.delete(itemId);
      return newSet;
    });
  };

  const handleBulkDelete = () => {
    if (selectedItems.size === 0) return;
    if (confirm(`Delete ${selectedItems.size} selected items?`)) {
      setMediaItems((prev) => prev.filter((item) => !selectedItems.has(item.id)));
      setSelectedItems(new Set());
    }
  };

  const handleSelectItem = (itemId: string) => {
    setSelectedItems((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(itemId)) {
        newSet.delete(itemId);
      } else {
        newSet.add(itemId);
      }
      return newSet;
    });
  };

  const handleSelectAll = () => {
    const filtered = getFilteredItems();
    if (selectedItems.size === filtered.length) {
      setSelectedItems(new Set());
    } else {
      setSelectedItems(new Set(filtered.map((item) => item.id)));
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const getFilteredItems = () => {
    return mediaItems.filter((item) => {
      const matchesTab = item.type === activeTab;
      const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesFilter = !filterSection || item.assignedSection === filterSection;
      return matchesTab && matchesSearch && matchesFilter;
    });
  };

  const filteredItems = getFilteredItems();
  const imageCount = mediaItems.filter((item) => item.type === 'images').length;
  const videoCount = mediaItems.filter((item) => item.type === 'videos').length;

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <main className="pt-24 pb-20">
        <div className="max-w-7xl mx-auto px-6 md:px-8 lg:px-16">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-black mb-4">
              Media Manager
            </h1>
            <p className="text-base md:text-lg text-black/60 max-w-2xl mx-auto">
              Upload, organize, and assign images and videos to different sections of your site.
            </p>
          </div>

          {/* Tabs */}
          <div className="flex items-center justify-center gap-2 mb-8">
            <button
              onClick={() => setActiveTab('images')}
              className={`px-6 py-3 rounded-full font-medium transition-all duration-300 whitespace-nowrap ${
                activeTab === 'images'
                  ? 'bg-black text-white'
                  : 'bg-black/5 text-black/60 hover:bg-black/10'
              }`}
            >
              <i className="ri-image-line mr-2"></i>
              Images ({imageCount})
            </button>
            <button
              onClick={() => setActiveTab('videos')}
              className={`px-6 py-3 rounded-full font-medium transition-all duration-300 whitespace-nowrap ${
                activeTab === 'videos'
                  ? 'bg-black text-white'
                  : 'bg-black/5 text-black/60 hover:bg-black/10'
              }`}
            >
              <i className="ri-video-line mr-2"></i>
              Videos ({videoCount})
            </button>
          </div>

          {/* Upload Zone */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`relative border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all duration-300 mb-8 ${
              isDragging
                ? 'border-black bg-black/5'
                : 'border-black/10 hover:border-black/20 bg-white'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept={activeTab === 'images' ? 'image/*' : 'video/*'}
              onChange={handleFileInput}
              className="hidden"
            />

            <div className="flex flex-col items-center gap-4">
              <div className="w-16 h-16 flex items-center justify-center rounded-full bg-black/5">
                <i
                  className={`${
                    activeTab === 'images' ? 'ri-image-add-line' : 'ri-video-add-line'
                  } text-3xl text-black/40`}
                ></i>
              </div>
              <div>
                <p className="text-lg font-semibold text-black mb-1">
                  {isDragging
                    ? `Drop your ${activeTab} here`
                    : `Drag & drop ${activeTab} here`}
                </p>
                <p className="text-sm text-black/50">or click to browse from your device</p>
              </div>
            </div>
          </div>

          {/* Filters and Actions */}
          {filteredItems.length > 0 && (
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              {/* Search */}
              <div className="flex-1 relative">
                <i className="ri-search-line absolute left-4 top-1/2 -translate-y-1/2 text-black/40"></i>
                <input
                  type="text"
                  placeholder="Search by filename..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 border border-black/10 rounded-xl focus:outline-none focus:border-black/30 transition-colors"
                />
              </div>

              {/* Filter by Section */}
              <select
                value={filterSection}
                onChange={(e) => setFilterSection(e.target.value)}
                className="px-4 py-3 border border-black/10 rounded-xl focus:outline-none focus:border-black/30 transition-colors cursor-pointer"
              >
                <option value="">All Sections</option>
                {SECTION_OPTIONS.slice(1).map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>

              {/* Bulk Actions */}
              <div className="flex gap-2">
                <button
                  onClick={handleSelectAll}
                  className="px-4 py-3 border border-black/10 rounded-xl hover:bg-black/5 transition-colors whitespace-nowrap"
                >
                  {selectedItems.size === filteredItems.length ? 'Deselect All' : 'Select All'}
                </button>
                {selectedItems.size > 0 && (
                  <button
                    onClick={handleBulkDelete}
                    className="px-4 py-3 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-colors whitespace-nowrap"
                  >
                    <i className="ri-delete-bin-line mr-2"></i>
                    Delete ({selectedItems.size})
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Media Grid */}
          {filteredItems.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredItems.map((item) => (
                <div
                  key={item.id}
                  className={`bg-white border rounded-2xl overflow-hidden transition-all duration-300 ${
                    selectedItems.has(item.id)
                      ? 'border-black shadow-lg'
                      : 'border-black/10 hover:border-black/20'
                  }`}
                >
                  {/* Thumbnail */}
                  <div className="relative aspect-video bg-black/5">
                    {item.type === 'image' ? (
                      <img
                        src={item.url}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <video src={item.url} className="w-full h-full object-cover" />
                    )}

                    {/* Checkbox */}
                    <button
                      onClick={() => handleSelectItem(item.id)}
                      className="absolute top-3 left-3 w-6 h-6 flex items-center justify-center rounded-md bg-white border-2 border-black/20 hover:border-black transition-colors cursor-pointer"
                    >
                      {selectedItems.has(item.id) && (
                        <i className="ri-check-line text-sm text-black"></i>
                      )}
                    </button>

                    {/* Remove Button */}
                    <button
                      onClick={() => handleRemoveItem(item.id)}
                      className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center rounded-full bg-red-500 text-white hover:bg-red-600 transition-colors cursor-pointer"
                    >
                      <i className="ri-close-line text-lg"></i>
                    </button>
                  </div>

                  {/* Info */}
                  <div className="p-4 space-y-3">
                    {/* File Name & Size */}
                    <div>
                      <p className="text-sm font-medium text-black truncate" title={item.name}>
                        {item.name}
                      </p>
                      <p className="text-xs text-black/40">{formatFileSize(item.size)}</p>
                    </div>

                    {/* Section Assignment */}
                    <select
                      value={item.assignedSection}
                      onChange={(e) => handleSectionChange(item.id, e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-black/10 rounded-lg focus:outline-none focus:border-black/30 transition-colors cursor-pointer"
                    >
                      {SECTION_OPTIONS.map((option) => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>

                    {/* Copy URL Button */}
                    <button
                      onClick={() => handleCopyUrl(item.url)}
                      className="w-full px-3 py-2 text-sm bg-black/5 hover:bg-black/10 rounded-lg transition-colors whitespace-nowrap"
                    >
                      <i className="ri-file-copy-line mr-2"></i>
                      Copy URL
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <div className="w-20 h-20 flex items-center justify-center rounded-full bg-black/5 mx-auto mb-4">
                <i
                  className={`${
                    activeTab === 'images' ? 'ri-image-line' : 'ri-video-line'
                  } text-4xl text-black/20`}
                ></i>
              </div>
              <p className="text-lg text-black/40">
                {searchQuery || filterSection
                  ? 'No items match your filters'
                  : `No ${activeTab} uploaded yet`}
              </p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}