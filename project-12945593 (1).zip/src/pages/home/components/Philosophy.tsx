import React from 'react';
import ScrollReveal from '../../../components/feature/ScrollReveal';

export default function Philosophy() {
  return (
    <section className="relative py-32 md:py-40 lg:py-48 bg-gradient-to-br from-[#0A0A0F] via-[#0f0a1a] to-[#0A0A0F] overflow-hidden">
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#7c3aed]/20 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-[#a855f7]/15 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />

      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(to right, white 1px, transparent 1px), linear-gradient(to bottom, white 1px, transparent 1px)`,
          backgroundSize: '60px 60px',
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-8 lg:px-16">
        <ScrollReveal direction="up">
          <div className="flex items-center justify-center gap-3 mb-12">
            <div className="w-12 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent" />
            <span className="text-white/50 text-xs font-semibold uppercase tracking-[0.3em]">
              The Thinking
            </span>
            <div className="w-12 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent" />
          </div>
        </ScrollReveal>

        <ScrollReveal direction="up" delay={100}>
          <h2
            className="font-editorial font-black text-white text-center leading-[0.92] tracking-tight mb-8"
            style={{ fontSize: 'clamp(3rem, 7vw, 7rem)' }}
          >
            Strategy Is Not
            <br />
            <span
              className="italic"
              style={{
                background: 'linear-gradient(135deg, #7c3aed 0%, #a855f7 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              Optional.
            </span>
          </h2>
        </ScrollReveal>

        <ScrollReveal direction="up" delay={200}>
          <p className="text-white/55 text-lg md:text-xl text-center max-w-3xl mx-auto leading-relaxed mb-16">
            Every brand that dominates its market got there through deliberate, structured thinking. Not luck. Not noise. Clarity.
          </p>
        </ScrollReveal>

        <div className="grid md:grid-cols-3 gap-8 md:gap-10 lg:gap-12 mt-20">
          {[
            {
              icon: 'ri-focus-3-line',
              gradient: 'from-[#7c3aed] to-[#5B2DFF]',
              title: 'Strategic Focus',
              text: 'Every campaign, every creative, every decision is part of a larger strategic framework designed to move your brand forward with intention.',
              label: 'LAYER 01',
              tabColor: '#a855f7',
            },
            {
              icon: 'ri-line-chart-line',
              gradient: 'from-[#5B2DFF] to-[#7c3aed]',
              title: 'Long-Term Vision',
              text: 'We build sustainable growth engines that compound over time. Not viral moments. Not shortcuts. Lasting brand equity that scales.',
              label: 'LAYER 02',
              tabColor: '#7C3AED',
            },
            {
              icon: 'ri-gamepad-line',
              gradient: 'from-[#7c3aed] to-[#a855f7]',
              title: 'Calculated Execution',
              text: 'We anticipate market shifts, competitor moves, and audience behavior. Every action is deliberate. Every outcome is measured.',
              label: 'LAYER 03',
              tabColor: '#9333ea',
            },
          ].map((pillar, i) => (
            <ScrollReveal key={i} direction="up" delay={280 + i * 80}>
              <div className="relative group">
                <div className={`absolute inset-0 bg-gradient-to-br ${pillar.gradient} opacity-10 rounded-2xl blur-xl group-hover:blur-2xl transition-all duration-500`} />

                {/* Folder tab */}
                <div
                  className="absolute -top-[26px] left-5 z-20 h-[26px] px-3 rounded-t-lg flex items-center gap-2 transition-all duration-300 group-hover:-top-[28px]"
                  style={{
                    backgroundColor: `${pillar.tabColor}12`,
                    border: `1px solid ${pillar.tabColor}30`,
                    borderBottom: 'none',
                  }}
                >
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: pillar.tabColor }} />
                  <span className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: pillar.tabColor }}>
                    {pillar.label}
                  </span>
                </div>

                <div className="relative bg-white/[0.04] backdrop-blur-sm border border-white/[0.08] rounded-2xl p-8 hover:bg-white/[0.07] hover:border-white/[0.14] transition-all duration-300">
                  <div className={`w-14 h-14 rounded-full bg-gradient-to-br ${pillar.gradient} flex items-center justify-center mb-6`}>
                    <i className={`${pillar.icon} text-white text-2xl`}></i>
                  </div>
                  <h3 className="text-white text-xl md:text-2xl font-bold mb-4">{pillar.title}</h3>
                  <p className="text-white/50 text-base leading-relaxed">{pillar.text}</p>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>

        <ScrollReveal direction="up" delay={520}>
          <div className="mt-20 text-center">
            <div className="inline-block border-l-4 border-[#7C3AED] pl-6 py-2 bg-white/[0.03] backdrop-blur-sm rounded-r-xl">
              <p className="text-white/70 text-lg md:text-xl font-editorial italic leading-relaxed">
                "The brands that win are the ones that think before they act."
              </p>
              <div className="flex items-center gap-3 mt-4 justify-end">
                <div className="w-8 h-px bg-white/20" />
                <span className="text-white/30 text-xs uppercase tracking-widest">
                  Brandstack Agency
                </span>
              </div>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
