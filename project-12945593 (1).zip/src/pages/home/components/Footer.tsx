import React from 'react';
import EditableLogo from '../../../components/feature/EditableLogo';

export default function Footer() {
  const navigate = (path: string) => {
    if (
      typeof window !== 'undefined' &&
      typeof (window as any).REACT_APP_NAVIGATE === 'function'
    ) {
      (window as any).REACT_APP_NAVIGATE(path);
    }
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="relative bg-[#08080C] border-t border-white/[0.06] overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(to right, #fff 1px, transparent 1px), linear-gradient(to bottom, #fff 1px, transparent 1px)`,
          backgroundSize: '48px 48px',
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-8 lg:px-16 py-12 md:py-16 lg:py-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-8 md:gap-12 mb-12 md:mb-16">
          <div className="lg:col-span-4 flex flex-col">
            <div className="mb-4 md:mb-6">
              <EditableLogo
                className="text-xl md:text-2xl"
                alt="Brandstack Agency"
                variant="dark"
              />
            </div>
            <p className="text-white/35 text-xs md:text-sm leading-relaxed mb-auto max-w-sm">
              Strategic marketing for brands that refuse to blend in. We position, launch, and scale businesses with precision and purpose.
            </p>
            <div className="flex items-center gap-3 mt-6">
              {['ri-linkedin-fill', 'ri-twitter-x-fill', 'ri-instagram-fill'].map((icon, i) => (
                <a
                  key={i}
                  href="#"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 md:w-10 md:h-10 rounded-full bg-white/5 hover:bg-gradient-to-r hover:from-[#6b21a8] hover:via-[#7C3AED] hover:to-[#a855f7] flex items-center justify-center transition-all duration-300 group cursor-pointer"
                >
                  <i className={`${icon} text-base md:text-lg text-white/30 group-hover:text-white transition-colors`}></i>
                </a>
              ))}
            </div>
          </div>

          <div className="lg:col-span-2 flex flex-col">
            <h4 className="font-semibold text-sm md:text-base text-white/80 mb-4 md:mb-6">Pricing</h4>
            <ul className="space-y-2 md:space-y-3">
              {[
                { label: 'Marketing Audit', slug: '/pricing' },
                { label: 'GTM Launchpad', slug: '/pricing#gtm-launchpad' },
                { label: 'SEG Growth', slug: '/pricing#seg-growth' },
                { label: 'SEG Full Scale', slug: '/pricing#seg-full' },
              ].map((item) => (
                <li key={item.slug}>
                  <button
                    onClick={() => navigate(item.slug)}
                    className="text-white/35 hover:text-[#a855f7] text-xs md:text-sm transition-colors cursor-pointer text-left"
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-2 flex flex-col">
            <h4 className="font-semibold text-sm md:text-base text-white/80 mb-4 md:mb-6">Company</h4>
            <ul className="space-y-2 md:space-y-3">
              {[
                { label: 'About Us', path: '/brandstack' },
                { label: 'Projects', path: '/projects' },
                { label: 'Contact', path: '/contact' },
              ].map((item) => (
                <li key={item.path}>
                  <button
                    onClick={() => navigate(item.path)}
                    className="text-white/35 hover:text-[#a855f7] text-xs md:text-sm transition-colors cursor-pointer text-left"
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-4 flex flex-col">
            <h4 className="font-semibold text-sm md:text-base text-white/80 mb-4 md:mb-6">Get in Touch</h4>
            <ul className="space-y-2 md:space-y-3 mb-auto">
              <li className="flex items-start gap-2">
                <i className="ri-mail-line text-[#7C3AED] text-base md:text-lg mt-0.5 flex-shrink-0"></i>
                <a
                  href="mailto:brandstackagency@gmail.com"
                  className="text-white/35 hover:text-[#a855f7] text-xs md:text-sm transition-colors cursor-pointer"
                >
                  brandstackagency@gmail.com
                </a>
              </li>
              <li className="flex items-start gap-2">
                <i className="ri-phone-line text-[#7C3AED] text-base md:text-lg mt-0.5 flex-shrink-0"></i>
                <a
                  href="tel:+2348025588157"
                  className="text-white/35 hover:text-[#a855f7] text-xs md:text-sm transition-colors cursor-pointer"
                >
                  +234 802 558 8157
                </a>
              </li>
            </ul>
            <button
              onClick={() => scrollToSection('contact')}
              className="mt-6 px-6 py-2.5 md:py-3 bg-gradient-to-r from-[#6b21a8] via-[#7C3AED] to-[#a855f7] text-white text-xs md:text-sm font-semibold rounded-full hover:opacity-90 transition-all duration-300 hover:scale-105 whitespace-nowrap cursor-pointer self-start"
            >
              Book a Call
            </button>
          </div>
        </div>

        <div className="pt-6 md:pt-8 border-t border-white/[0.06] flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/25 text-xs md:text-sm text-center sm:text-left">
            &copy; 2024 Brandstack Agency. All rights reserved.
          </p>
          <div className="flex items-center gap-4 md:gap-6">
            <button className="text-white/25 hover:text-[#a855f7] text-xs md:text-sm transition-colors cursor-pointer whitespace-nowrap">
              Privacy Policy
            </button>
            <button className="text-white/25 hover:text-[#a855f7] text-xs md:text-sm transition-colors cursor-pointer whitespace-nowrap">
              Terms of Service
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
