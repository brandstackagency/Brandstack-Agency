import { useEffect, useRef } from 'react';
import ScrollReveal from '../../../components/feature/ScrollReveal';
import { getAllProjects } from '../../../data/projects';

export default function FeaturedProjects() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    let animFrame: number;
    let t = 0;
    const resize = () => { canvas.width = canvas.offsetWidth; canvas.height = canvas.offsetHeight; };
    resize();
    window.addEventListener('resize', resize);
    const blobs = [
      { x: 0.1, y: 0.2, r: 0.3, color: 'rgba(124,58,237,0.12)' },
      { x: 0.9, y: 0.7, r: 0.35, color: 'rgba(168,85,247,0.08)' },
    ];
    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      blobs.forEach((b, i) => {
        const ox = Math.sin(t * 0.0003 + i * 1.5) * 0.06;
        const oy = Math.cos(t * 0.0004 + i * 1.1) * 0.05;
        const gx = (b.x + ox) * canvas.width;
        const gy = (b.y + oy) * canvas.height;
        const gr = b.r * Math.max(canvas.width, canvas.height);
        const grad = ctx.createRadialGradient(gx, gy, 0, gx, gy, gr);
        grad.addColorStop(0, b.color);
        grad.addColorStop(1, 'transparent');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(gx, gy, gr, 0, Math.PI * 2);
        ctx.fill();
      });
      t++;
      animFrame = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(animFrame); window.removeEventListener('resize', resize); };
  }, []);

  // Get first 4 projects from centralized data
  const allProjects = getAllProjects();
  const projects = allProjects.slice(0, 4).map(project => ({
    name: project.title,
    industry: project.category,
    service: project.services[0] === 'gtm' ? 'GTM Strategy' : project.services[0] === 'seg' ? 'SEG Framework' : project.services[0] === 'performance' ? 'Performance Marketing' : 'Marketing Audit',
    result: project.metrics[0]?.label + ': ' + project.metrics[0]?.value,
    image: project.image,
    color: project.color,
    slug: project.slug,
  }));

  const navigateToProjects = () => {
    if (typeof window !== 'undefined' && typeof (window as any).REACT_APP_NAVIGATE === 'function') {
      (window as any).REACT_APP_NAVIGATE('/projects');
    }
  };

  return (
    <section className="relative bg-[#08080C] overflow-hidden py-28">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none z-0"
        style={{ filter: 'blur(60px)' }}
      />
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none z-10"
        style={{
          backgroundImage: 'linear-gradient(rgba(0,0,0,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.3) 1px, transparent 1px)',
          backgroundSize: '48px 48px',
        }}
      />

      <div className="relative z-20 max-w-7xl mx-auto px-8 lg:px-16">
        <div className="flex items-center justify-between mb-16">
          <ScrollReveal direction="up" delay={0}>
            <div>
              <h2
                className="font-editorial font-black text-white leading-[0.95] tracking-tight"
                style={{ fontSize: 'clamp(2.5rem, 4.5vw, 5rem)' }}
              >
                Featured<br />
                <span
                  className="italic"
                  style={{
                    background: 'linear-gradient(135deg, #7c3aed 0%, #5B2DFF 50%, #00b4aa 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                  }}
                >
                  Projects.
                </span>
              </h2>
            </div>
          </ScrollReveal>

          <ScrollReveal direction="left" delay={120}>
            <button
              onClick={navigateToProjects}
              className="hidden lg:flex items-center gap-2 px-6 py-3 border border-white/10 text-white/40 text-sm font-semibold rounded-full hover:border-[#7C3AED] hover:text-[#a855f7] transition-all duration-300 whitespace-nowrap cursor-pointer"
            >
              View All Campaigns <i className="ri-arrow-right-line"></i>
            </button>
          </ScrollReveal>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-10">
          {projects.map((project, index) => (
            <ScrollReveal key={index} direction="up" delay={index * 100} threshold={0.08}>
              <div
                onClick={() => {
                  if (typeof window !== 'undefined' && typeof (window as any).REACT_APP_NAVIGATE === 'function') {
                    (window as any).REACT_APP_NAVIGATE('/projects');
                  }
                }}
                className="group relative rounded-2xl overflow-hidden cursor-pointer"
                style={{ height: index % 2 === 0 ? '420px' : '380px' }}
              >
                <img
                  src={project.image}
                  alt={project.name}
                  width="800"
                  height="600"
                  loading="lazy"
                  decoding="async"
                  className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                <div
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  style={{ background: `linear-gradient(135deg, ${project.color}40 0%, transparent 60%)` }}
                />
                <div className="absolute top-5 left-5">
                  <span
                    className="px-3 py-1.5 text-white text-xs font-semibold rounded-full border"
                    style={{
                      background: `${project.color}50`,
                      backdropFilter: 'blur(8px)',
                      borderColor: `${project.color}80`,
                    }}
                  >
                    {project.service}
                  </span>
                </div>

                {/* Subtle featured indicator */}
                <div className="absolute top-20 left-5 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                  <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: project.color }} />
                  <span className="text-white/50 text-[10px] font-semibold uppercase tracking-[0.15em]">Featured Work</span>
                </div>

                {/* Folder tab detail at top-right */}
                <div
                  className="absolute -top-[18px] right-5 h-[18px] px-2.5 rounded-t-md flex items-center gap-1.5 z-20 opacity-0 group-hover:opacity-100 transition-all duration-300 group-hover:-top-[20px]"
                  style={{
                    backgroundColor: `${project.color}20`,
                    border: `1px solid ${project.color}40`,
                    borderBottom: 'none',
                  }}
                >
                  <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: project.color }} />
                  <span className="text-[9px] font-semibold uppercase tracking-widest" style={{ color: project.color }}>
                    PROJECT
                  </span>
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-7">
                  <p className="text-white/50 text-xs uppercase tracking-widest mb-1">{project.industry}</p>
                  <h3 className="font-editorial font-black text-white text-2xl mb-2">{project.name}</h3>
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-px" style={{ background: project.color }}></div>
                    <p className="text-white/70 text-sm">{project.result}</p>
                  </div>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>

        <ScrollReveal direction="up" delay={0}>
          <div className="flex lg:hidden justify-center">
            <button
              onClick={navigateToProjects}
              className="px-8 py-3.5 text-white font-semibold rounded-full transition-all duration-300 whitespace-nowrap cursor-pointer"
              style={{ background: 'linear-gradient(135deg, #5B2DFF 0%, #4A1FE6 100%)', boxShadow: '0 4px 20px rgba(91,45,255,0.35)' }}
            >
              View All Campaigns
            </button>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}