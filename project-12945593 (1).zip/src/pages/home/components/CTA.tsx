import React from 'react';
import ScrollReveal from '../../../components/feature/ScrollReveal';

export default function CTA() {
  const scrollToBooking = () => {
    const bookingSection = document.getElementById('booking-form');
    if (bookingSection) {
      bookingSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative py-20 md:py-28 lg:py-32 overflow-hidden bg-gradient-to-br from-[#6b21a8] via-[#7C3AED] to-[#9333ea]">
      <div className="absolute inset-0 opacity-30">
        <div
          className="absolute inset-0 animate-pulse"
          style={{
            background: 'radial-gradient(circle at 30% 50%, rgba(255,255,255,0.15) 0%, transparent 50%)',
          }}
        />
      </div>

      <div
        className="absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage: `linear-gradient(to right, white 1px, transparent 1px), linear-gradient(to bottom, white 1px, transparent 1px)`,
          backgroundSize: '60px 60px',
        }}
      />

      <div className="relative z-10 max-w-5xl mx-auto px-6 md:px-8 lg:px-16 text-center">
        <ScrollReveal direction="up">
          <p className="text-white/70 text-sm md:text-base font-medium uppercase tracking-[0.2em] mb-6">
            Ready to Make Your Move?
          </p>
        </ScrollReveal>

        <ScrollReveal direction="up" delay={100}>
          <p className="text-white/80 text-base md:text-lg leading-relaxed max-w-2xl mx-auto mb-10">
            Let's turn your brand into a strategic powerhouse. Book a session with us and discover how we can elevate your growth.
          </p>
        </ScrollReveal>

        <ScrollReveal direction="up" delay={200}>
          <button
            onClick={scrollToBooking}
            className="group relative inline-flex items-center gap-3 px-10 py-4 bg-white text-[#7C3AED] rounded-full font-bold text-base md:text-lg hover:bg-white/95 transition-all duration-300 hover:scale-105 hover:shadow-2xl whitespace-nowrap"
          >
            <span>Book a Strategy Session</span>
            <i className="ri-arrow-right-line text-xl group-hover:translate-x-1 transition-transform duration-300"></i>
          </button>
        </ScrollReveal>
      </div>
    </section>
  );
}
