import React from 'react';
import ScrollReveal from '../../../components/feature/ScrollReveal';

const testimonials = [
  {
    quote: "Brandstack didn't just help us launch, they helped us own our category. Their strategic clarity and execution speed are unmatched.",
    author: 'Sarah Chen',
    role: 'Founder & CEO',
    company: 'Lumina Health',
    image: 'https://readdy.ai/api/search-image?query=professional%20asian%20woman%20ceo%20in%20modern%20office%20wearing%20business%20casual%20attire%20confident%20smile%20natural%20lighting%20corporate%20headshot%20portrait%20photography&width=400&height=400&seq=testimonial-sarah-chen&orientation=squarish',
  },
  {
    quote: "We tried three agencies before Brandstack. They were the first to actually understand our market and deliver results that mattered.",
    author: 'Marcus Rodriguez',
    role: 'CMO',
    company: 'Vertex AI',
    image: 'https://readdy.ai/api/search-image?query=professional%20hispanic%20male%20marketing%20executive%20in%20tech%20startup%20office%20modern%20workspace%20confident%20expression%20natural%20lighting%20corporate%20headshot%20portrait%20photography&width=400&height=400&seq=testimonial-marcus-rodriguez&orientation=squarish',
  },
  {
    quote: "Their SEG Framework transformed how we think about content and growth. We've 3x'd our pipeline in six months.",
    author: 'Emily Watson',
    role: 'VP of Marketing',
    company: 'CloudScale',
    image: 'https://readdy.ai/api/search-image?query=professional%20caucasian%20woman%20marketing%20executive%20in%20contemporary%20office%20space%20confident%20professional%20attire%20natural%20lighting%20corporate%20headshot%20portrait%20photography&width=400&height=400&seq=testimonial-emily-watson&orientation=squarish',
  },
];

export default function Testimonials() {
  return (
    <section className="relative py-16 md:py-24 lg:py-32 overflow-hidden" style={{ background: 'linear-gradient(160deg, #f5f0ff 0%, #fdfcff 40%, #f8f4ff 100%)' }}>
      {/* Purple ambient orbs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-20 -left-20 w-[500px] h-[500px] bg-[#7C3AED]/[0.06] rounded-full blur-3xl" />
        <div className="absolute -bottom-20 -right-20 w-[400px] h-[400px] bg-[#a855f7]/[0.05] rounded-full blur-3xl" />
      </div>
      {/* Grid background */}
      <div
        className="absolute inset-0 opacity-[0.025]"
        style={{
          backgroundImage: `
            linear-gradient(to right, #7C3AED 1px, transparent 1px),
            linear-gradient(to bottom, #7C3AED 1px, transparent 1px)
          `,
          backgroundSize: '48px 48px',
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-8 lg:px-16">
        {/* Section Header */}
        <div className="text-center mb-12 md:mb-16 lg:mb-20">
          <ScrollReveal direction="up">
            <div className="flex items-center justify-center gap-3 mb-4 md:mb-6">
              <div className="w-8 md:w-10 h-px bg-[#5B2DFF]" />
              <span className="text-[#5B2DFF] text-[10px] md:text-xs font-semibold uppercase tracking-[0.2em]">
                Client Stories
              </span>
              <div className="w-8 md:w-10 h-px bg-[#5B2DFF]" />
            </div>
          </ScrollReveal>

          <ScrollReveal direction="up" delay={80}>
            <h2
              className="font-editorial font-black leading-[0.95] tracking-tight text-[#0D0D0D] mb-4 md:mb-6"
              style={{ fontSize: 'clamp(2rem, 6vw, 4.5rem)' }}
            >
              Trusted by Brands That Move Markets
            </h2>
          </ScrollReveal>

          <ScrollReveal direction="up" delay={160}>
            <p className="text-black/50 text-sm md:text-base leading-relaxed max-w-2xl mx-auto">
              Don't take our word for it. Here's what our clients have to say about working with Brandstack.
            </p>
          </ScrollReveal>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {testimonials.map((testimonial, index) => (
            <ScrollReveal key={index} direction="up" delay={index * 80}>
              <div className="group relative bg-[#F8F7F4] rounded-2xl p-6 md:p-8 border border-black/[0.06] hover:border-[#5B2DFF]/30 transition-all duration-300 hover:shadow-lg hover:shadow-[#5B2DFF]/10">
                {/* Quote mark */}
                <div className="mb-6">
                  <i className="ri-double-quotes-l text-4xl md:text-5xl text-[#5B2DFF]/20"></i>
                </div>

                {/* Quote */}
                <p className="text-black/70 text-sm md:text-base leading-relaxed mb-6 md:mb-8">
                  {testimonial.quote}
                </p>

                {/* Author */}
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 md:w-14 md:h-14 rounded-full overflow-hidden flex-shrink-0">
                    <img
                      src={testimonial.image}
                      alt={testimonial.author}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <div className="font-semibold text-sm md:text-base text-[#0D0D0D]">
                      {testimonial.author}
                    </div>
                    <div className="text-xs md:text-sm text-black/50">
                      {testimonial.role}, {testimonial.company}
                    </div>
                  </div>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}