import React from 'react';

export default function MarqueeTicker() {
  const keywords = [
    'Strategy',
    'Growth',
    'Performance',
    'Positioning',
    'Clarity',
    'Execution',
    'ROI',
    'Campaigns',
    'Branding',
    'Analytics',
    'Launch',
    'Scale',
  ];

  const repeatedKeywords = [...keywords, ...keywords, ...keywords];

  return (
    <section className="relative py-6 bg-[#08080C] overflow-hidden border-y border-white/[0.04]">
      <div className="flex whitespace-nowrap animate-marquee">
        {repeatedKeywords.map((keyword, index) => (
          <React.Fragment key={index}>
            <span
              className="inline-block px-8 text-base md:text-lg font-bold uppercase tracking-wider"
              style={{
                color: index % 2 === 0 ? 'rgba(255,255,255,0.7)' : '#a855f7',
              }}
            >
              {keyword}
            </span>
            <span className="inline-block px-4 text-[#7C3AED] text-xl">•</span>
          </React.Fragment>
        ))}
      </div>
    </section>
  );
}
