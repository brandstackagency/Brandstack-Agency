import React, { useState } from 'react';

export default function BookingForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');

    try {
      const formBody = new URLSearchParams();
      Object.entries(formData).forEach(([key, value]) => {
        formBody.append(key, value);
      });

      const response = await fetch('https://readdy.ai/api/form/d6gk77b7ks76vrd3kund', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formBody.toString(),
      });

      if (response.ok) {
        setSubmitStatus('success');
        setFormData({ name: '', email: '', company: '', phone: '', message: '' });
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="relative py-20 md:py-28 bg-[#0C0B11] overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-[#7C3AED]/[0.08] rounded-full blur-3xl" />
      </div>
      <div className="relative z-10 max-w-2xl mx-auto px-6 md:px-8">
        <div className="text-center mb-10">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-8 h-px bg-[#7C3AED]" />
            <span className="text-[#a855f7] text-xs font-semibold uppercase tracking-[0.2em]">Book a Call</span>
            <div className="w-8 h-px bg-[#7C3AED]" />
          </div>
          <h2 className="font-editorial font-black text-white text-3xl md:text-4xl mb-3">
            Start the Conversation
          </h2>
          <p className="text-white/40 text-sm leading-relaxed">
            Tell us about your brand. We respond within 24 hours.
          </p>
        </div>

        <form
          id="booking-form"
          data-readdy-form
          onSubmit={handleSubmit}
          className="w-full bg-white/[0.04] backdrop-blur-sm rounded-2xl p-6 md:p-8 lg:p-10 border border-white/[0.08]"
        >
          <div className="space-y-4 md:space-y-5">
            <div>
              <label htmlFor="name" className="block text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">
                Full Name *
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 text-sm bg-white/[0.05] border border-white/[0.08] rounded-lg text-white placeholder-white/20 focus:outline-none focus:ring-2 focus:ring-[#7C3AED]/40 focus:border-[#7C3AED]/50 transition-all"
                placeholder="John Doe"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">
                Email Address *
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 text-sm bg-white/[0.05] border border-white/[0.08] rounded-lg text-white placeholder-white/20 focus:outline-none focus:ring-2 focus:ring-[#7C3AED]/40 focus:border-[#7C3AED]/50 transition-all"
                placeholder="john@company.com"
              />
            </div>

            <div>
              <label htmlFor="company" className="block text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">
                Company Name
              </label>
              <input
                type="text"
                id="company"
                name="company"
                value={formData.company}
                onChange={handleChange}
                className="w-full px-4 py-3 text-sm bg-white/[0.05] border border-white/[0.08] rounded-lg text-white placeholder-white/20 focus:outline-none focus:ring-2 focus:ring-[#7C3AED]/40 focus:border-[#7C3AED]/50 transition-all"
                placeholder="Your Company"
              />
            </div>

            <div>
              <label htmlFor="phone" className="block text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">
                Phone Number
              </label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="w-full px-4 py-3 text-sm bg-white/[0.05] border border-white/[0.08] rounded-lg text-white placeholder-white/20 focus:outline-none focus:ring-2 focus:ring-[#7C3AED]/40 focus:border-[#7C3AED]/50 transition-all"
                placeholder="+1 (555) 000-0000"
              />
            </div>

            <div>
              <label htmlFor="message" className="block text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">
                Tell us about your project *
              </label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                required
                maxLength={500}
                rows={4}
                className="w-full px-4 py-3 text-sm bg-white/[0.05] border border-white/[0.08] rounded-lg text-white placeholder-white/20 focus:outline-none focus:ring-2 focus:ring-[#7C3AED]/40 focus:border-[#7C3AED]/50 transition-all resize-none"
                placeholder="Share your goals, challenges, and what you're looking to achieve..."
              />
              <div className="text-xs text-white/20 mt-1">
                {formData.message.length}/500 characters
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full px-6 py-3.5 md:py-4 text-white text-sm md:text-base font-semibold rounded-full transition-all duration-300 hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap cursor-pointer"
              style={{
                background: 'linear-gradient(135deg, #6b21a8 0%, #7C3AED 60%, #a855f7 100%)',
                boxShadow: '0 4px 24px rgba(124,58,237,0.35)',
              }}
            >
              {isSubmitting ? 'Sending...' : 'Book Your Discovery Call'}
            </button>

            {submitStatus === 'success' && (
              <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg text-green-400 text-sm text-center">
                Thank you! We'll be in touch within 24 hours.
              </div>
            )}
            {submitStatus === 'error' && (
              <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm text-center">
                Something went wrong. Please try again or email us directly.
              </div>
            )}
          </div>
        </form>
      </div>
    </section>
  );
}
