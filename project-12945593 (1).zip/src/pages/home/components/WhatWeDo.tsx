export default function WhatWeDo() {
  const capabilities = [
    {
      icon: 'ri-lightbulb-line',
      title: 'Strategic Positioning',
      description: 'We define how your brand should be perceived in the market and build messaging that resonates.',
    },
    {
      icon: 'ri-line-chart-line',
      title: 'Growth Systems',
      description: 'We design scalable marketing frameworks that compound over time, not one-off campaigns.',
    },
    {
      icon: 'ri-rocket-line',
      title: 'Campaign Execution',
      description: 'We launch and manage high-performance campaigns across multiple channels with precision.',
    },
    {
      icon: 'ri-bar-chart-box-line',
      title: 'Performance Optimization',
      description: 'We track, analyze, and refine every campaign to maximize ROI and eliminate waste.',
    },
  ];

  const navigateToServices = () => {
    if (window.REACT_APP_NAVIGATE) {
      window.REACT_APP_NAVIGATE('/pricing');
    }
  };

  return (
    <section className="py-24 bg-[#F8F7F4] relative overflow-hidden">
      {/* Subtle grid */}
      <div className="absolute inset-0 opacity-[0.04]">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid-what" x="0" y="0" width="60" height="60" patternUnits="userSpaceOnUse">
              <path d="M 60 0 L 0 0 0 60" fill="none" stroke="#5B2DFF" strokeWidth="1"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid-what)"/>
        </svg>
      </div>

      {/* Soft glow orbs */}
      <div className="absolute top-20 left-10 w-96 h-96 bg-[#5B2DFF]/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#5B2DFF]/5 rounded-full blur-3xl"></div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-[#0D0D0D] mb-6">
            What We <span className="text-[#5B2DFF]">Do</span>
          </h2>
          <p className="text-xl text-black/45 max-w-3xl mx-auto">
            We build structured marketing systems that drive measurable growth
          </p>
        </div>

        {/* Capabilities Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {capabilities.map((capability, index) => (
            <div
              key={index}
              className="bg-white border border-black/[0.07] rounded-2xl p-8 hover:border-[#5B2DFF]/40 transition-all duration-300 group shadow-sm hover:shadow-md"
            >
              <div className="w-14 h-14 bg-[#5B2DFF]/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-[#5B2DFF]/15 transition-all duration-300">
                <i className={`${capability.icon} text-3xl text-[#5B2DFF]`}></i>
              </div>
              <h3 className="text-2xl font-bold text-[#0D0D0D] mb-4">
                {capability.title}
              </h3>
              <p className="text-black/50 leading-relaxed">
                {capability.description}
              </p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <button
            onClick={navigateToServices}
            className="px-8 py-4 text-white text-lg font-bold rounded-full hover:opacity-90 transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-105 transform"
            style={{
              background: 'linear-gradient(135deg, #5B2DFF 0%, #4A1FE6 100%)',
              boxShadow: '0 4px 24px rgba(91,45,255,0.35)',
            }}
          >
            Explore Our Services
          </button>
        </div>
      </div>
    </section>
  );
}
