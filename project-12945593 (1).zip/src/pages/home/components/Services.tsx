import React, { useState } from 'react';
import ScrollReveal from '../../../components/feature/ScrollReveal';

const services = [
  {
    number: '01',
    title: 'Go-To-Market Launchpad',
    description: 'Full-stack launch strategy for new brands entering competitive markets.',
    features: [
      'Market positioning and competitive analysis',
      'Brand messaging and identity framework',
      'Multi-channel launch campaigns',
      'Performance tracking and optimization',
    ],
    slug: 'gtm-launchpad',
    tabColor: '#a855f7',
    tabIcon: 'ri-rocket-line',
    folderLabel: 'LAUNCH',
  },
  {
    number: '02',
    title: 'SEG Framework',
    description: 'Strategic, Editorial, Growth-focused marketing for established brands.',
    features: [
      'Content strategy and editorial planning',
      'Thought leadership positioning',
      'Organic and paid growth integration',
      'Brand storytelling at scale',
    ],
    slug: 'seg-framework',
    tabColor: '#7C3AED',
    tabIcon: 'ri-line-chart-line',
    folderLabel: 'GROWTH',
  },
  {
    number: '03',
    title: 'Performance Marketing',
    description: 'Data-driven campaigns designed to convert and scale profitably.',
    features: [
      'Paid media strategy (Meta, Google, LinkedIn)',
      'Conversion rate optimization',
      'Attribution modeling and analytics',
      'Creative testing and iteration',
    ],
    slug: 'performance-marketing',
    tabColor: '#9333ea',
    tabIcon: 'ri-bar-chart-box-line',
    folderLabel: 'PERFORM',
  },
  {
    number: '04',
    title: 'Marketing Audit',
    description: 'Comprehensive analysis of your current marketing stack and strategy.',
    features: [
      'Full-funnel performance review',
      'Tech stack and tool optimization',
      'Competitive benchmarking',
      'Actionable roadmap and recommendations',
    ],
    slug: 'marketing-audit',
    tabColor: '#6b21a8',
    tabIcon: 'ri-search-line',
    folderLabel: 'AUDIT',
  },
];

export default function Services() {
  const [hoveredService, setHoveredService] = useState<number | null>(null);

  const navigate = (path: string) => {
    if (
      typeof window !== 'undefined' &&
      typeof (window as any).REACT_APP_NAVIGATE === 'function'
    ) {
      (window as any).REACT_APP_NAVIGATE(path);
    }
  };

  const handleBookService = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate('/pricing');
  };

  return (
    <section className="relative py-16 md:py-24 lg:py-32 bg-[#0C0B11] overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-[#7C3AED]/[0.06] rounded-full blur-3xl -translate-y-1/2 translate-x-1/3" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#a855f7]/[0.04] rounded-full blur-3xl translate-y-1/2 -translate-x-1/3" />
      </div>
      <div
        className="absolute inset-0 opacity-[0.025]"
        style={{
          backgroundImage: `linear-gradient(to right, #7C3AED 1px, transparent 1px), linear-gradient(to bottom, #7C3AED 1px, transparent 1px)`,
          backgroundSize: '48px 48px',
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-8 lg:px-16">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6 lg:gap-12 mb-12 md:mb-16 lg:mb-20">
          <ScrollReveal direction="up">
            <div>
              <div className="flex items-center gap-3 mb-4 md:mb-6">
                <div className="w-8 md:w-10 h-px bg-[#7C3AED]" />
                <span className="text-[#a855f7] text-[10px] md:text-xs font-semibold uppercase tracking-[0.2em]">
                  Our Services
                </span>
              </div>
              <h2
                className="font-editorial font-black leading-[0.95] tracking-tight text-white"
                style={{ fontSize: 'clamp(2rem, 6vw, 4.5rem)' }}
              >
                Strategic Systems<br />
                That <span
                  className="italic"
                  style={{
                    background: 'linear-gradient(135deg, #6b21a8 0%, #7C3AED 60%, #a855f7 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                  }}
                >
                  Scale.
                </span>
              </h2>
            </div>
          </ScrollReveal>

          <ScrollReveal direction="up" delay={80}>
            <p className="text-white/40 text-sm md:text-base leading-relaxed max-w-md lg:pb-2">
              We design marketing frameworks that compound over time. No fluff. No guesswork. Just structured growth systems built for performance.
            </p>
          </ScrollReveal>
        </div>

        <div className="space-y-0">
          {services.map((service, index) => {
            const isHovered = hoveredService === index;
            return (
              <ScrollReveal key={service.slug} direction="up" delay={index * 60}>
                <div
                  onClick={() => navigate('/pricing')}
                  onMouseEnter={() => setHoveredService(index)}
                  onMouseLeave={() => setHoveredService(null)}
                  className="group relative cursor-pointer transition-all duration-400"
                >
                  {/* Folder tab badge at left */}
                  <div
                    className="absolute left-0 top-1/2 -translate-y-1/2 z-10 flex items-center gap-1.5 px-3 py-1.5 rounded-r-lg transition-all duration-300"
                    style={{
                      backgroundColor: isHovered ? `${service.tabColor}15` : `${service.tabColor}08`,
                      border: `1px solid ${isHovered ? `${service.tabColor}40` : `${service.tabColor}20`}`,
                      borderLeft: 'none',
                      transform: `translateY(-50%) translateX(${isHovered ? 0 : '-4px'})`,
                      opacity: isHovered ? 1 : 0.5,
                    }}
                  >
                    <i className={`${service.tabIcon} text-xs`} style={{ color: service.tabColor }} />
                    <span className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: service.tabColor }}>
                      {service.folderLabel}
                    </span>
                  </div>

                  <div
                    className="border-t border-white/[0.06] last:border-b py-8 md:py-10 lg:py-12 transition-all duration-400 pl-20 md:pl-24"
                    style={{
                      background: isHovered
                        ? 'linear-gradient(90deg, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0.01) 40%, transparent 100%)'
                        : 'transparent',
                    }}
                  >
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-8 lg:gap-12">
                      <div className="hidden lg:block lg:col-span-1">
                        <span
                          className="font-editorial font-black text-4xl md:text-5xl transition-colors duration-300"
                          style={{
                            color: isHovered ? `${service.tabColor}30` : 'rgba(255,255,255,0.06)',
                          }}
                        >
                          {service.number}
                        </span>
                      </div>

                      <div className="lg:col-span-5">
                        <h3 className="font-editorial font-black text-2xl md:text-3xl lg:text-4xl text-white mb-3 md:mb-4 group-hover:text-[#a855f7] transition-colors duration-300">
                          {service.title}
                        </h3>
                        <p className="text-white/40 text-sm md:text-base leading-relaxed">
                          {service.description}
                        </p>
                      </div>

                      <div className="lg:col-span-4">
                        <ul className="space-y-2 md:space-y-3">
                          {service.features.map((feature, idx) => (
                            <li key={idx} className="flex items-start gap-3">
                              <i className="ri-check-line text-[#7C3AED] text-lg md:text-xl mt-0.5 flex-shrink-0"></i>
                              <span className="text-white/40 text-xs md:text-sm leading-relaxed">
                                {feature}
                              </span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="lg:col-span-2 flex lg:items-center lg:justify-end">
                        <button
                          onClick={handleBookService}
                          className="flex items-center gap-2 text-[#a855f7] text-sm md:text-base font-semibold group-hover:gap-4 transition-all duration-300 whitespace-nowrap cursor-pointer"
                        >
                          See Pricing
                          <i className="ri-arrow-right-line text-lg md:text-xl"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </ScrollReveal>
            );
          })}
        </div>

        <ScrollReveal direction="up" delay={240}>
          <div className="flex justify-center mt-12 md:mt-16">
            <button
              onClick={() => navigate('/pricing')}
              className="px-6 md:px-8 py-3 md:py-4 border border-white/10 text-white/40 text-sm md:text-base font-semibold rounded-full hover:border-[#7C3AED] hover:text-[#a855f7] transition-all duration-300 whitespace-nowrap cursor-pointer"
            >
              View All Pricing
            </button>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
