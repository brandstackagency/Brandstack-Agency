import React from 'react';
import ScrollReveal from '../../../components/feature/ScrollReveal';
import EditableText from '../../../components/feature/EditableText';

export default function WhoWeAre() {
  return (
    <section className="relative py-20 md:py-28 lg:py-32 bg-white overflow-hidden">
      {/* Subtle grid background */}
      <div
        className="absolute inset-0 opacity-[0.02]"
        style={{
          backgroundImage: `
            linear-gradient(to right, #000 1px, transparent 1px),
            linear-gradient(to bottom, #000 1px, transparent 1px)
          `,
          backgroundSize: '48px 48px',
        }}
      />

      <div className="relative z-10 max-w-6xl mx-auto px-6 md:px-8 lg:px-16">
        {/* Section Header */}
        <ScrollReveal direction="up">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-px bg-gradient-to-r from-[#7c3aed] to-[#00b4aa]" />
            <span className="text-[#5B2DFF] text-xs font-semibold uppercase tracking-[0.2em]">
              Who We Are
            </span>
          </div>
        </ScrollReveal>

        <ScrollReveal direction="up" delay={100}>
          <h2
            className="font-editorial font-black text-[#0D0D0D] leading-[0.95] tracking-tight mb-16"
            style={{ fontSize: 'clamp(2.5rem, 5vw, 4.5rem)' }}
          >
            <EditableText id="who-we-are-title" defaultValue="We're Not Just Marketers." />
            <br />
            <span
              className="italic"
              style={{
                background: 'linear-gradient(135deg, #7c3aed 0%, #5B2DFF 50%, #00b4aa 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              <EditableText id="who-we-are-title-accent" defaultValue="We're Strategists." />
            </span>
          </h2>
        </ScrollReveal>

        {/* Rich Copy Blocks */}
        <div className="grid md:grid-cols-2 gap-12 md:gap-16 lg:gap-20">
          {/* Block 1 */}
          <ScrollReveal direction="up" delay={200}>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br from-[#7c3aed] to-[#5B2DFF] flex items-center justify-center">
                  <i className="ri-lightbulb-flash-line text-white text-xl"></i>
                </div>
                <div>
                  <h3 className="text-xl md:text-2xl font-bold text-[#0D0D0D] mb-3">
                    <EditableText id="who-block-1-title" defaultValue="Strategic Thinkers First" />
                  </h3>
                  <p className="text-black/60 text-base leading-relaxed">
                    <EditableText
                      id="who-block-1-text"
                      defaultValue="We don't just execute campaigns. We architect growth strategies. Every move we make is calculated, data-driven, and designed to position your brand three steps ahead of the competition."
                    />
                  </p>
                </div>
              </div>
            </div>
          </ScrollReveal>

          {/* Block 2 */}
          <ScrollReveal direction="up" delay={280}>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br from-[#5B2DFF] to-[#00b4aa] flex items-center justify-center">
                  <i className="ri-team-line text-white text-xl"></i>
                </div>
                <div>
                  <h3 className="text-xl md:text-2xl font-bold text-[#0D0D0D] mb-3">
                    <EditableText id="who-block-2-title" defaultValue="Built for African Brands" />
                  </h3>
                  <p className="text-black/60 text-base leading-relaxed">
                    <EditableText
                      id="who-block-2-text"
                      defaultValue="We understand the unique challenges and opportunities of the African market. From Lagos to Nairobi, we've helped brands break through noise, build communities, and scale with precision."
                    />
                  </p>
                </div>
              </div>
            </div>
          </ScrollReveal>

          {/* Block 3 */}
          <ScrollReveal direction="up" delay={360}>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br from-[#00b4aa] to-[#7c3aed] flex items-center justify-center">
                  <i className="ri-rocket-line text-white text-xl"></i>
                </div>
                <div>
                  <h3 className="text-xl md:text-2xl font-bold text-[#0D0D0D] mb-3">
                    <EditableText id="who-block-3-title" defaultValue="Results-Obsessed" />
                  </h3>
                  <p className="text-black/60 text-base leading-relaxed">
                    <EditableText
                      id="who-block-3-text"
                      defaultValue="We measure success in metrics that matter: revenue growth, customer retention, brand equity. Our clients don't just get campaigns. They get measurable, sustainable growth."
                    />
                  </p>
                </div>
              </div>
            </div>
          </ScrollReveal>

          {/* Block 4 */}
          <ScrollReveal direction="up" delay={440}>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br from-[#7c3aed] to-[#00b4aa] flex items-center justify-center">
                  <i className="ri-compass-3-line text-white text-xl"></i>
                </div>
                <div>
                  <h3 className="text-xl md:text-2xl font-bold text-[#0D0D0D] mb-3">
                    <EditableText id="who-block-4-title" defaultValue="Your Growth Partners" />
                  </h3>
                  <p className="text-black/60 text-base leading-relaxed">
                    <EditableText
                      id="who-block-4-text"
                      defaultValue="We're not vendors, we're partners in your success. When you win, we win. That's why we invest deeply in understanding your business, your audience, and your ambitions."
                    />
                  </p>
                </div>
              </div>
            </div>
          </ScrollReveal>
        </div>

        {/* Bottom Statement */}
        <ScrollReveal direction="up" delay={520}>
          <div className="mt-16 pt-12 border-t border-black/10">
            <p className="text-center text-lg md:text-xl text-black/70 leading-relaxed max-w-3xl mx-auto">
              <EditableText
                id="who-bottom-statement"
                defaultValue="We're BrandStack Africa, a team of strategists, creatives, and growth hackers who believe that every brand has the potential to dominate its market. We just help you get there faster."
              />
            </p>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}