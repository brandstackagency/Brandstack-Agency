import React from 'react';
import ScrollReveal from '../../../components/feature/ScrollReveal';
import DustParticles from '../../../components/feature/DustParticles';

const stats = [
  { value: '120+', label: 'Brands Launched' },
  { value: '3.8x', label: 'Avg. ROI Delivered' },
  { value: '$40M+', label: 'Revenue Generated' },
  { value: '98%', label: 'Client Retention' },
];

export default function Hero() {
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const navigateToProjects = () => {
    if (
      typeof window !== 'undefined' &&
      typeof (window as any).REACT_APP_NAVIGATE === 'function'
    ) {
      (window as any).REACT_APP_NAVIGATE('/projects');
    }
  };

  return (
    <section className="relative min-h-screen bg-[#0C0B11] overflow-hidden flex items-center">
      {/* Grain texture overlay */}
      <div
        className="absolute inset-0 opacity-[0.04] pointer-events-none z-10"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 512 512' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")`,
          backgroundRepeat: 'repeat',
          backgroundSize: '200px 200px',
          mixBlendMode: 'overlay',
        }}
      />

      {/* Dust particles atmosphere */}
      <DustParticles />

      {/* Ambient glow orbs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-[#7C3AED]/[0.12] rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-[#a855f7]/[0.08] rounded-full blur-3xl" />
        <div className="absolute top-20 left-10 w-24 h-24 md:w-32 md:h-32 border border-white/[0.05] rotate-45 rounded-lg" />
        <div className="absolute top-40 right-10 md:right-20 w-20 h-20 md:w-24 md:h-24 border border-white/[0.05] rotate-12" />
        <div className="absolute bottom-20 left-1/4 w-32 h-32 md:w-40 md:h-40 border border-white/[0.04] rounded-full" />

        {/* Folder stack mini accent */}
        <div className="absolute top-24 right-8 md:right-16 lg:right-24 hidden lg:block" style={{ perspective: '600px' }}>
          {[0, 1, 2, 3].map((i) => {
            const colors = ['#a855f7', '#7C3AED', '#6b21a8', '#9333ea'];
            return (
              <div
                key={i}
                className="absolute w-20 h-14 rounded-lg border"
                style={{
                  background: 'linear-gradient(145deg, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0.01) 100%)',
                  borderColor: `${colors[i]}20`,
                  transform: `translate3d(${i * 6}px, ${i * 5}px, ${i * 8}px) rotate(${-8 + i * 5}deg)`,
                  transformOrigin: 'bottom center',
                  boxShadow: i === 3 ? `0 8px 24px rgba(124,58,237,0.15)` : '0 4px 12px rgba(0,0,0,0.3)',
                }}
              >
                <div
                  className="absolute -top-[14px] left-3 h-[14px] px-2 rounded-t-md"
                  style={{
                    backgroundColor: `${colors[i]}12`,
                    border: `1px solid ${colors[i]}25`,
                    borderBottom: 'none',
                  }}
                >
                  <div className="w-3 h-[2px] rounded-full mt-1" style={{ backgroundColor: colors[i] }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Grid */}
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `linear-gradient(to right, #fff 1px, transparent 1px), linear-gradient(to bottom, #fff 1px, transparent 1px)`,
          backgroundSize: '60px 60px',
        }}
      />

      <div className="relative z-20 max-w-7xl mx-auto px-6 md:px-8 lg:px-16 py-12 md:py-16 lg:py-24">
        <ScrollReveal direction="up" delay={80}>
          <h1
            className="font-editorial font-black leading-[0.92] tracking-tight text-white mb-6 md:mb-8"
            style={{ fontSize: 'clamp(2.5rem, 8vw, 7rem)' }}
          >
            We Build Brands That
            <br />
            <span
              className="italic"
              style={{
                background: 'linear-gradient(135deg, #9333ea 0%, #7C3AED 50%, #a855f7 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              Move Markets.
            </span>
          </h1>
        </ScrollReveal>

        <ScrollReveal direction="up" delay={160}>
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 md:gap-8 mb-10 md:mb-12">
            <p className="text-white/40 text-sm md:text-base lg:text-lg leading-relaxed max-w-xl">
              A performance-driven marketing agency that helps ambitious brands launch, scale, and dominate their markets through strategic clarity and flawless execution.
            </p>
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <button
                onClick={() => scrollToSection('contact')}
                className="px-6 md:px-8 py-3 md:py-3.5 text-white text-sm md:text-base font-bold rounded-full transition-all duration-300 whitespace-nowrap cursor-pointer hover:scale-105"
                style={{
                  background: 'linear-gradient(135deg, #6b21a8 0%, #7C3AED 60%, #a855f7 100%)',
                  boxShadow: '0 4px 28px rgba(124,58,237,0.45)',
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 8px 40px rgba(124,58,237,0.6)';
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 4px 28px rgba(124,58,237,0.45)';
                }}
              >
                Book a Discovery Call
              </button>
              <button
                onClick={navigateToProjects}
                className="px-6 md:px-8 py-3 md:py-3.5 border-2 border-white/10 text-white/60 text-sm md:text-base font-semibold rounded-full hover:border-[#7C3AED] hover:text-[#a855f7] transition-all duration-300 whitespace-nowrap cursor-pointer"
              >
                View Our Work
              </button>
            </div>
          </div>
        </ScrollReveal>

        <ScrollReveal direction="up" delay={240}>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 pt-8 md:pt-10 border-t border-white/[0.06]">
            {stats.map((stat, index) => (
              <div key={index} className="text-left">
                <div className="font-editorial font-black text-2xl md:text-3xl lg:text-4xl text-white mb-1">
                  {stat.value}
                </div>
                <div className="text-white/30 text-xs md:text-sm font-medium uppercase tracking-wider">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
