import React, { useState, useEffect } from 'react';
import EditableLogo from '../../../components/feature/EditableLogo';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navigate = (path: string) => {
    if (
      typeof window !== 'undefined' &&
      typeof (window as any).REACT_APP_NAVIGATE === 'function'
    ) {
      (window as any).REACT_APP_NAVIGATE(path);
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-[#0C0B11]/95 backdrop-blur-md border-b border-white/[0.06]'
            : 'bg-transparent'
        }`}
      >
        <div className="px-6 md:px-10 lg:px-16">
          <div className="flex items-center justify-between h-16 md:h-18">
            <button
              onClick={() => navigate('/')}
              className="flex items-center cursor-pointer"
            >
              <EditableLogo
                className="text-lg font-black transition-all duration-300"
                alt="Brandstack Agency"
                variant="dark"
              />
            </button>

            <div className="hidden md:flex items-center gap-7">
              <button
                onClick={() => navigate('/pricing')}
                className="text-sm font-medium text-white/50 hover:text-white transition-colors cursor-pointer whitespace-nowrap"
              >
                Pricing
              </button>
              <button
                onClick={() => navigate('/projects')}
                className="text-sm font-medium text-white/50 hover:text-white transition-colors cursor-pointer whitespace-nowrap"
              >
                Projects
              </button>
              <button
                onClick={() => navigate('/brandstack')}
                className="text-sm font-medium text-white/50 hover:text-white transition-colors cursor-pointer whitespace-nowrap"
              >
                About Us
              </button>
              <button
                onClick={() => navigate('/contact')}
                className="text-sm font-medium text-white/50 hover:text-white transition-colors cursor-pointer whitespace-nowrap"
              >
                Contact
              </button>
              <button
                onClick={() => navigate('/book')}
                className="px-5 py-2 bg-gradient-to-r from-[#6b21a8] via-[#7C3AED] to-[#a855f7] text-white text-sm font-semibold rounded-full hover:opacity-90 transition-all duration-300 hover:scale-105 whitespace-nowrap cursor-pointer"
              >
                Book a Call
              </button>
            </div>

            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden w-9 h-9 flex items-center justify-center cursor-pointer"
              aria-label="Toggle menu"
            >
              <div className="w-5 h-3.5 flex flex-col justify-between">
                <span className={`w-full h-0.5 bg-white transition-all duration-300 ${isMobileMenuOpen ? 'rotate-45 translate-y-1.5' : ''}`} />
                <span className={`w-full h-0.5 bg-white transition-all duration-300 ${isMobileMenuOpen ? 'opacity-0' : ''}`} />
                <span className={`w-full h-0.5 bg-white transition-all duration-300 ${isMobileMenuOpen ? '-rotate-45 -translate-y-2' : ''}`} />
              </div>
            </button>
          </div>
        </div>
      </nav>

      <div
        className={`fixed inset-0 bg-[#0C0B11] z-40 md:hidden transition-all duration-300 ${
          isMobileMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        style={{ top: '64px' }}
      >
        <div className="flex flex-col items-center justify-center h-full gap-8 px-6">
          <button onClick={() => navigate('/pricing')} className="text-2xl font-semibold text-white/80 hover:text-white transition-colors cursor-pointer">Pricing</button>
          <button onClick={() => navigate('/projects')} className="text-2xl font-semibold text-white/80 hover:text-white transition-colors cursor-pointer">Projects</button>
          <button onClick={() => navigate('/brandstack')} className="text-2xl font-semibold text-white/80 hover:text-white transition-colors cursor-pointer">About Us</button>
          <button onClick={() => navigate('/contact')} className="text-2xl font-semibold text-white/80 hover:text-white transition-colors cursor-pointer">Contact</button>
          <button
            onClick={() => navigate('/book')}
            className="px-8 py-4 bg-gradient-to-r from-[#6b21a8] via-[#7C3AED] to-[#a855f7] text-white text-lg font-semibold rounded-full hover:opacity-90 transition-all duration-300 whitespace-nowrap cursor-pointer mt-4"
          >
            Book a Call
          </button>
        </div>
      </div>
    </>
  );
}
