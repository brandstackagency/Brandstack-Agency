import { useEffect, useState } from 'react';
import ScrollReveal from '../../../components/feature/ScrollReveal';
import { useEditMode } from '../../../contexts/EditModeContext';
import { getAllProjects, getBrandLogo } from '../../../data/projects';

export default function ClientLogos() {
  const { isEditMode } = useEditMode();

  const allProjects = getAllProjects();
  const brands = allProjects.map(project => ({
    id: project.slug,
    name: project.title,
    slug: project.slug,
  }));

  const [brandLogos, setBrandLogos] = useState<Record<string, string>>({});

  useEffect(() => {
    const loadLogos = () => {
      const logos: Record<string, string> = {};
      brands.forEach((brand) => {
        const logo = getBrandLogo(brand.slug);
        if (logo) {
          logos[brand.slug] = logo;
        }
      });
      setBrandLogos(logos);
    };

    loadLogos();

    const handleStorageChange = (e: StorageEvent) => {
      if (e.key?.startsWith('brand-logo-')) {
        loadLogos();
      }
    };

    window.addEventListener('storage', handleStorageChange);
    const interval = setInterval(loadLogos, 500);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
    };
  }, []);

  return (
    <section className="relative py-16 md:py-20 lg:py-24 bg-[#08080C] overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.02]"
        style={{
          backgroundImage: `linear-gradient(to right, #fff 1px, transparent 1px), linear-gradient(to bottom, #fff 1px, transparent 1px)`,
          backgroundSize: '48px 48px',
        }}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-8 lg:px-16">
        <ScrollReveal direction="up">
          <div className="text-center mb-12 md:mb-16">
            <p className="text-white/25 text-xs md:text-sm font-medium uppercase tracking-wider mb-3">
              Brands That Trust Us
            </p>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white">
              Trusted by Leading Brands
            </h2>
          </div>
        </ScrollReveal>

        <ScrollReveal direction="up" delay={100}>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6 md:gap-8 items-center">
            {brands.map((brand) => (
              <div
                key={brand.id}
                className="flex items-center justify-center p-6 md:p-8 border border-white/[0.05] rounded-xl bg-white/[0.02] hover:border-white/[0.1] hover:bg-white/[0.04] transition-all duration-300 group"
              >
                {brandLogos[brand.slug] ? (
                  <div className="w-full h-20 md:h-24 flex items-center justify-center">
                    <img
                      src={brandLogos[brand.slug]}
                      alt={`${brand.name} logo`}
                      width="200"
                      height="96"
                      loading="lazy"
                      decoding="async"
                      className="max-w-full max-h-full w-auto h-auto object-contain grayscale opacity-40 group-hover:grayscale-0 group-hover:opacity-80 transition-all duration-300"
                    />
                  </div>
                ) : (
                  <div className="w-full h-20 md:h-24 flex items-center justify-center">
                    <span className="text-white/20 group-hover:text-white/50 text-base md:text-lg font-bold transition-colors duration-300">
                      {brand.name}
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
