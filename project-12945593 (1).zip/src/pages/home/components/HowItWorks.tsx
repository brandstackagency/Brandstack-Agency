import React, { useState } from 'react';
import ScrollReveal from '../../../components/feature/ScrollReveal';

const steps = [
  {
    number: '01',
    title: 'Discovery',
    description: 'We dive deep into your business, market, and goals to understand what success looks like.',
    icon: 'ri-search-line',
    tabColor: '#a855f7',
  },
  {
    number: '02',
    title: 'Strategy',
    description: 'We build a custom marketing roadmap tailored to your brand, audience, and growth stage.',
    icon: 'ri-lightbulb-line',
    tabColor: '#7C3AED',
  },
  {
    number: '03',
    title: 'Execution',
    description: 'We launch campaigns, create content, and activate channels with precision and speed.',
    icon: 'ri-rocket-line',
    tabColor: '#6b21a8',
  },
  {
    number: '04',
    title: 'Optimization',
    description: 'We track, test, and refine continuously to maximize ROI and scale what works.',
    icon: 'ri-line-chart-line',
    tabColor: '#9333ea',
  },
];

export default function HowItWorks() {
  const [hoveredStep, setHoveredStep] = useState<number | null>(null);

  return (
    <section className="relative py-16 md:py-24 lg:py-32 bg-[#08080C] overflow-hidden">
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-[#7C3AED]/[0.05] rounded-full blur-3xl" />
      </div>
      <div className="absolute top-20 right-10 w-32 h-32 md:w-40 md:h-40 border border-white/[0.04] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-20 left-10 w-24 h-24 md:w-32 md:h-32 border border-white/[0.04] rotate-12 pointer-events-none"></div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-8 lg:px-16">
        <div className="text-center mb-12 md:mb-16 lg:mb-20">
          <ScrollReveal direction="up">
            <div className="flex items-center justify-center gap-3 mb-4 md:mb-6">
              <div className="w-8 md:w-10 h-px bg-[#7C3AED]" />
              <span className="text-[#a855f7] text-[10px] md:text-xs font-semibold uppercase tracking-[0.2em]">
                Our Process
              </span>
              <div className="w-8 md:w-10 h-px bg-[#7C3AED]" />
            </div>
          </ScrollReveal>

          <ScrollReveal direction="up" delay={80}>
            <h2
              className="font-editorial font-black leading-[0.95] tracking-tight text-white mb-4 md:mb-6"
              style={{ fontSize: 'clamp(2rem, 6vw, 4.5rem)' }}
            >
              Simple. Structured.<br />
              <span
                className="italic"
                style={{
                  background: 'linear-gradient(135deg, #6b21a8 0%, #7C3AED 60%, #a855f7 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              >
                Strategic.
              </span>
            </h2>
          </ScrollReveal>

          <ScrollReveal direction="up" delay={160}>
            <p className="text-white/40 text-sm md:text-base leading-relaxed max-w-2xl mx-auto">
              Our proven 4-step framework ensures every campaign is built on strategy, executed with precision, and optimized for maximum impact.
            </p>
          </ScrollReveal>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {steps.map((step, index) => {
            const isHovered = hoveredStep === index;
            return (
              <ScrollReveal key={step.number} direction="up" delay={index * 80}>
                <div
                  onMouseEnter={() => setHoveredStep(index)}
                  onMouseLeave={() => setHoveredStep(null)}
                  className="group relative cursor-pointer will-change-transform"
                  style={{
                    transform: isHovered ? 'translateY(-8px)' : 'translateY(0)',
                    transition: 'transform 0.45s cubic-bezier(0.23, 1, 0.32, 1)',
                  }}
                >
                  {/* Folder tab at top */}
                  <div
                    className="absolute -top-[26px] left-4 md:left-5 z-20 h-[26px] px-4 rounded-t-lg flex items-center gap-2"
                    style={{
                      backgroundColor: isHovered ? `${step.tabColor}22` : `${step.tabColor}10`,
                      border: `1px solid ${isHovered ? `${step.tabColor}50` : `${step.tabColor}28`}`,
                      borderBottom: 'none',
                      transform: isHovered ? 'translateY(-3px)' : 'translateY(0)',
                      transition: 'transform 0.4s cubic-bezier(0.23, 1, 0.32, 1), background-color 0.5s ease, border-color 0.5s ease',
                    }}
                  >
                    <i className={`${step.icon} text-sm`} style={{ color: step.tabColor }} />
                    <span
                      className="text-[10px] md:text-xs font-semibold uppercase tracking-wider"
                      style={{ color: step.tabColor }}
                    >
                      {step.title}
                    </span>
                  </div>

                  {/* Card body */}
                  <div
                    className="relative rounded-2xl p-6 md:p-8 border overflow-hidden paper-grain"
                    style={{
                      background: isHovered
                        ? 'linear-gradient(145deg, rgba(255,255,255,0.06) 0%, rgba(255,255,255,0.015) 100%)'
                        : 'linear-gradient(145deg, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.01) 100%)',
                      borderColor: isHovered ? `${step.tabColor}40` : 'rgba(255,255,255,0.06)',
                      boxShadow: isHovered
                        ? `0 24px 60px rgba(0,0,0,0.45), 0 0 0 1px ${step.tabColor}25`
                        : '0 10px 36px rgba(0,0,0,0.35)',
                      transition: 'background 0.5s ease, border-color 0.5s ease, box-shadow 0.5s ease',
                    }}
                  >
                    {/* Paper grain overlay */}
                    <div
                      className="absolute inset-0 pointer-events-none z-[1] opacity-20 mix-blend-overlay"
                      style={{
                        backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='5' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.06'/%3E%3C/svg%3E")`,
                        backgroundSize: '128px 128px',
                      }}
                    />
                    {/* Top accent line */}
                    <div className="flex items-center gap-2 mb-5 md:mb-6">
                      <div className="w-full h-px bg-white/[0.06]" />
                      <div
                        className="w-8 h-1 rounded-full flex-shrink-0"
                        style={{ backgroundColor: step.tabColor }}
                      />
                    </div>

                    {/* Step number */}
                    <div
                      className="font-editorial font-black text-5xl md:text-6xl leading-none mb-4 transition-colors duration-400"
                      style={{ color: isHovered ? `${step.tabColor}12` : 'rgba(255,255,255,0.03)' }}
                    >
                      {step.number}
                    </div>

                    {/* Icon */}
                    <div
                      className="w-12 h-12 md:w-14 md:h-14 rounded-full flex items-center justify-center mb-4 md:mb-5"
                      style={{
                        background: isHovered
                          ? `linear-gradient(135deg, ${step.tabColor}35 0%, ${step.tabColor}15 100%)`
                          : `linear-gradient(135deg, ${step.tabColor}15 0%, ${step.tabColor}05 100%)`,
                        border: `1px solid ${isHovered ? `${step.tabColor}45` : `${step.tabColor}18`}`,
                        transition: 'background 0.5s ease, border-color 0.5s ease',
                      }}
                    >
                      <i
                        className={`${step.icon} text-2xl md:text-3xl transition-transform duration-300 ${isHovered ? 'scale-110' : 'scale-100'}`}
                        style={{ color: step.tabColor }}
                      />
                    </div>

                    <h3 className="font-editorial font-black text-xl md:text-2xl text-white mb-3 md:mb-4">
                      {step.title}
                    </h3>
                    <p className="text-white/40 text-xs md:text-sm leading-relaxed">
                      {step.description}
                    </p>

                    {/* Bottom dots */}
                    <div className="mt-5 flex items-center gap-1.5">
                      {[...Array(4 - index)].map((_, dotIdx) => (
                        <div
                          key={dotIdx}
                          className="w-1.5 h-1.5 rounded-full"
                          style={{ backgroundColor: `${step.tabColor}${30 + dotIdx * 12}` }}
                        />
                      ))}
                      <div className="flex-1" />
                      <span className="text-white/15 text-[10px] font-medium uppercase tracking-widest">
                        Step {step.number}
                      </span>
                    </div>
                  </div>
                </div>
              </ScrollReveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
