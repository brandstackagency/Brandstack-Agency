import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import MarqueeTicker from './components/MarqueeTicker';
import Services from './components/Services';
import Philosophy from './components/Philosophy';
import FeaturedProjects from './components/FeaturedProjects';
import CTA from './components/CTA';
import FolderStack from '../../components/feature/FolderStack';
import BookingForm from './components/BookingForm';
import Footer from './components/Footer';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-[#0C0B11]">
      <Navbar />
      <Hero />
      <MarqueeTicker />
      <Services />
      <Philosophy />
      <FeaturedProjects />
      <CTA />
      <FolderStack />
      <BookingForm />
      <Footer />
    </div>
  );
}