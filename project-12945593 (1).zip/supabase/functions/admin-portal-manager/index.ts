import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const body = await req.json();
    const { action } = body;

    // Create auth user + portal
    if (action === "create_client") {
      const { email, password, client_name, brand_name, slug, description, accent_color } = body;

      if (!email || !password || !client_name || !brand_name || !slug) {
        return new Response(JSON.stringify({ error: "Missing required fields" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Create auth user
      const { data: authUser, error: authError } = await supabaseClient.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
      });

      if (authError) {
        return new Response(JSON.stringify({ error: `Auth error: ${authError.message}` }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Create portal linked to auth user
      const { data: portal, error: portalError } = await supabaseClient
        .from("client_portals")
        .insert({
          user_id: authUser.user.id,
          client_name,
          brand_name,
          slug,
          description: description || "",
          accent_color: accent_color || "#7C3AED",
          status: "active",
        })
        .select("id, client_name, brand_name, slug")
        .single();

      if (portalError) {
        // Cleanup auth user if portal creation fails
        await supabaseClient.auth.admin.deleteUser(authUser.user.id);
        return new Response(JSON.stringify({ error: `Portal error: ${portalError.message}` }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      return new Response(JSON.stringify({
        success: true,
        portal,
        message: `Client ${client_name} created successfully. Login: ${email}`,
      }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Update project progress
    if (action === "update_project_progress") {
      const { project_id, progress, status } = body;
      if (!project_id) {
        return new Response(JSON.stringify({ error: "Missing project_id" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const updates: any = {};
      if (progress !== undefined) updates.progress = progress;
      if (status) updates.status = status;

      await supabaseClient.from("portal_projects").update(updates).eq("id", project_id);

      return new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Invalid action" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (err) {
    console.error("Admin portal error:", err);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
